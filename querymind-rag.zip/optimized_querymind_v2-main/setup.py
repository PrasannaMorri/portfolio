"""
Run this script to set up the project in one go.
Usage: python setup.py
"""
import subprocess
import sys
import os

def run(cmd):
    print(f"\n>>> {cmd}")
    result = subprocess.run(cmd, shell=True)
    return result.returncode == 0

print("=" * 60)
print("RAG System — Automated Setup")
print("=" * 60)

# Copy .env
if not os.path.exists(".env"):
    os.system("copy .env.example .env" if os.name == "nt" else "cp .env.example .env")
    print("\n✅ .env created — edit DATABASE_URL if needed")

# Install packages in correct order
print("\n📦 Installing packages...")
run("pip install numpy==1.24.3")
run("pip install scipy==1.10.1")
run("pip install scikit-learn==1.3.0")
run("pip install torch==2.3.0 --index-url https://download.pytorch.org/whl/cpu")
run("pip install -r requirements.txt")

# Create upload dir
os.makedirs("uploads", exist_ok=True)
os.makedirs("chroma_store", exist_ok=True)
print("\n✅ Directories created")

# Seed database
print("\n🌱 Seeding database...")
run("python -m app.db.seed")

print("\n" + "=" * 60)
print("✅ Setup complete!")
print("\nStart the system:")
print("  Terminal 1: uvicorn app.main:app --reload --port 8000")
print("  Terminal 2: streamlit run frontend/app.py --server.port 8501")
print("\nOpen: http://localhost:8501")
print("Login: user / user123")
print("=" * 60)
