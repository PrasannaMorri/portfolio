import pandas as pd
from sqlalchemy import create_engine

# Load CSV
df = pd.read_csv('company_employees_1000.csv')
print(f"CSV loaded: {len(df)} rows, {len(df.columns)} columns")

# Connect to PostgreSQL
engine = create_engine('postgresql://postgres:rag_pass@localhost:5433/rag_text2sql_db')

# Insert into database
df.to_sql('employees', engine, if_exists='replace', index=False)
print(f"Inserted {len(df)} rows into employees table!")