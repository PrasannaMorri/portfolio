# General Purpose RAG System

> Upload any document → Ask questions in plain English → Get direct answers with citations

---

## Features

| Feature | Description |
|---------|-------------|
| Multi-format upload | PDF, CSV, TXT, DOCX |
| Hybrid RAG | BM25 sparse + ChromaDB dense + RRF fusion |
| LLM options | Local HuggingFace or Groq via API key |
| Document QA | Answers with source citations |
| Text2SQL | Natural language → PostgreSQL queries |
| Auto summarize | One-click document summary |
| Key info extraction | Auto-extract names, dates, numbers |
| Query history | All queries saved with latency metrics |
| JWT auth | Role-based access control |
| Redis cache | Repeated queries return instantly |

---

## Quick Start

### Step 1 — Copy config
```bash
cp .env.example .env
# Edit .env — set DATABASE_URL to your PostgreSQL connection
```

### Step 2 — Install packages
```bash
pip install numpy==1.24.3 scipy==1.10.1 scikit-learn==1.3.0
pip install torch==2.3.0 --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
```

### Step 3 — Seed database
```bash
python -m app.db.seed
```

### Step 4 — Start backend (Terminal 1)
```bash
uvicorn app.main:app --reload --port 8000
```

### Step 5 — Start frontend (Terminal 2)
```bash
streamlit run frontend/app.py --server.port 8501
```

### Step 6 — Open browser
- **http://localhost:8501** → Streamlit UI
- **http://localhost:8000/docs** → Swagger API

---

## Login
| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | Full access |
| user | user123 | Standard access |

---

## How to use

1. Sign in → go to **Documents** tab
2. Upload a PDF/CSV/TXT/DOCX file
3. Go to **Ask** tab → type any question
4. System automatically detects if you want document QA or SQL
5. Get answer with source citations

---

## Architecture

```
Upload → Parse → Chunk → Embed → ChromaDB + BM25
Query  → Hybrid retrieval (RRF) → Prompt augmentation
       → Local LLM → Answer with citations → Cache
```

## Model options (.env)

| Model | RAM | Speed | Quality |
|-------|-----|-------|---------|
| google/flan-t5-base | 1 GB | Fast | Good |
| google/flan-t5-large | 3 GB | Medium | Better |
| mistralai/Mistral-7B-Instruct-v0.2 | 14 GB | Slow CPU | Best |

### Groq option

Set these values in `.env` if you want stronger answer quality than the local CPU model:

```bash
LLM_BACKEND=groq
GROQ_API_KEY=your_groq_api_key
GROQ_MODEL=llama-3.3-70b-versatile
```

### If uploaded documents show `0` indexed chunks

Use the `Repair search index` button in the Library tab. The backend will rebuild Chroma from the stored document chunks in the relational database, so you do not need to re-upload the files.
