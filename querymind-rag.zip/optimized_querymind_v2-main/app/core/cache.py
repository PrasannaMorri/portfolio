import hashlib
import json
from typing import Any, Optional
from app.core.config import get_settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)
settings = get_settings()
_redis_client = None


def get_redis():
    global _redis_client
    if _redis_client is None and settings.enable_cache:
        try:
            import redis
            _redis_client = redis.from_url(settings.redis_url, decode_responses=True)
            _redis_client.ping()
        except Exception:
            _redis_client = None
    return _redis_client


def make_cache_key(prefix, *args):
    raw = json.dumps(args, sort_keys=True)
    digest = hashlib.sha256(raw.encode()).hexdigest()[:16]
    return f"{prefix}:{digest}"


def cache_get(key):
    client = get_redis()
    if not client:
        return None
    try:
        value = client.get(key)
        if value:
            return json.loads(value)
    except Exception:
        pass
    return None


def cache_set(key, value, ttl=None):
    client = get_redis()
    if not client:
        return
    try:
        client.setex(
            key,
            ttl or settings.cache_ttl_seconds,
            json.dumps(value, default=str)
        )
    except Exception:
        pass
    