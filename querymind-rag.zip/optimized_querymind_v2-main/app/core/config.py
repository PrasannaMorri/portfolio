from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    # LLM
    llm_backend: str = "huggingface"
    hf_model_name: str = "google/flan-t5-base"
    hf_device: str = "cpu"
    hf_max_new_tokens: int = 600       # ↑ was 300 — needed for longer answers
    hf_temperature: float = 0.1

    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    openai_base_url: str = ""
    openai_temperature: float = 0.0

    groq_api_key: str = ""
    groq_model: str = "llama-3.3-70b-versatile"
    groq_base_url: str = "https://api.groq.com/openai/v1"
    groq_temperature: float = 0.1
    llm_request_timeout_seconds: int = 60

    # Database
    database_url: str = "postgresql://postgres:rag_pass@localhost:5433/rag_system_db"

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    cache_ttl_seconds: int = 300
    enable_cache: bool = False

    # Auth
    secret_key: str = "changethiskey"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    # RAG — optimized defaults
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    chroma_persist_dir: str = "./chroma_store"
    top_k_results: int = 7             # ↑ was 5 — more retrieval candidates
    hybrid_alpha: float = 0.55         # slightly dense-weighted
    chunk_size: int = 400              # ↓ was 512 — tighter chunks for precision
    chunk_overlap: int = 80            # ↑ was 50 — more sentence overlap

    overview_chunk_count: int = 4
    rag_repair_batch_size: int = 64

    # App
    upload_dir: str = "./uploads"
    app_env: str = "development"
    log_level: str = "INFO"
    allowed_origins: str = "http://localhost:8501"
    max_upload_size_mb: int = 50

    @property
    def cors_origins(self) -> List[str]:
        return [o.strip() for o in self.allowed_origins.split(",")]

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
