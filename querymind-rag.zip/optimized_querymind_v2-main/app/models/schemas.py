from pydantic import BaseModel, Field
from typing import Any, List, Optional, Dict
from datetime import datetime


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class DocumentUploadResponse(BaseModel):
    id: int
    filename: str
    file_type: str
    file_size: int
    chunk_count: int
    status: str
    summary: Optional[str] = None


class DocumentInfo(BaseModel):
    id: int
    filename: str
    file_type: str
    file_size: int
    chunk_count: int
    status: str
    summary: Optional[str] = None
    created_at: Optional[datetime] = None


class RetrievedChunkSchema(BaseModel):
    content: str
    score: float
    source: str
    page: int = 0


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=2000)
    mode: str = Field(default="rag", description="rag | sql | auto")
    doc_ids: Optional[List[int]] = None
    top_k: int = Field(default=5, ge=1, le=20)
    use_cache: bool = True

    class Config:
        json_schema_extra = {
            "example": {
                "question": "What are the main findings in the document?",
                "mode": "rag",
                "top_k": 5,
            }
        }


class QueryResponse(BaseModel):
    question: str
    answer: str
    mode: str
    sql: Optional[str] = None
    result: Optional[List[Dict[str, Any]]] = None
    retrieved_chunks: List[RetrievedChunkSchema] = []
    sources: List[str] = []
    cached: bool = False
    latency_ms: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class SummarizeRequest(BaseModel):
    doc_id: int


class SummarizeResponse(BaseModel):
    doc_id: int
    filename: str
    summary: str


class ExtractRequest(BaseModel):
    doc_id: int


class ExtractResponse(BaseModel):
    doc_id: int
    filename: str
    key_info: str


class ReindexRequest(BaseModel):
    doc_ids: Optional[List[int]] = None


class ReindexResponse(BaseModel):
    reindexed_chunks: int
    total_chunks: int


class HealthResponse(BaseModel):
    status: str
    version: str
    services: dict
    document_count: int
    chunk_count: int
