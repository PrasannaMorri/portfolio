"""
Database Chat API routes — "Talk to Your Database"

POST /db-chat/connect          → connect to a database
POST /db-chat/connect-sqlite   → connect via SQLite file upload
GET  /db-chat/schema           → get schema of connected DB
GET  /db-chat/schema-summary   → get human-readable schema summary
POST /db-chat/query            → natural language → SQL → execute → NL answer
POST /db-chat/sql              → execute raw SQL directly
GET  /db-chat/status           → connection status
POST /db-chat/disconnect       → disconnect
"""
import os
import uuid
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from pydantic import BaseModel, Field

from app.core.security import get_current_user
from app.core.logging_config import get_logger
from app.services.database_chat_service import (
    connect_database, disconnect_database, get_connection,
    is_connected, generate_sql_for_db, execute_sql_on_db,
    generate_nl_answer, recommend_chart, get_schema_summary,
)

logger = get_logger(__name__)
router = APIRouter(prefix="/db-chat", tags=["Database Chat"])

SQLITE_UPLOAD_DIR = "./uploads/sqlite"
os.makedirs(SQLITE_UPLOAD_DIR, exist_ok=True)


# ── Pydantic models ───────────────────────────────────────────────────────────

class ConnectRequest(BaseModel):
    db_type: str = Field(..., description="postgresql or sqlite")
    host: str = "localhost"
    port: int = 5432
    database: str = ""
    username: str = ""
    password: str = ""

    class Config:
        json_schema_extra = {
            "example": {
                "db_type": "postgresql",
                "host": "localhost",
                "port": 5432,
                "database": "my_database",
                "username": "postgres",
                "password": "mypassword",
            }
        }


class NLQueryRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=1000)
    top_k: int = Field(default=100, ge=1, le=500)

    class Config:
        json_schema_extra = {
            "example": {"question": "How many customers placed orders last month?"}
        }


class RawSQLRequest(BaseModel):
    sql: str = Field(..., min_length=6)


class NLQueryResponse(BaseModel):
    question: str
    sql: str
    answer: str
    rows: List[Dict[str, Any]]
    row_count: int
    chart: Dict[str, Any]
    latency_ms: float


# ── Helper: session id from username ─────────────────────────────────────────

def _session_id(user: dict) -> str:
    return f"dbchat_{user['username']}"


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/connect")
async def connect(req: ConnectRequest, current_user: dict = Depends(get_current_user)):
    """Connect to a PostgreSQL database."""
    if req.db_type not in ("postgresql", "sqlite"):
        raise HTTPException(status_code=400, detail="db_type must be 'postgresql' or 'sqlite'")

    session_id = _session_id(current_user)
    result = connect_database(
        session_id=session_id,
        db_type=req.db_type,
        host=req.host,
        port=req.port,
        database=req.database,
        username=req.username,
        password=req.password,
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/connect-sqlite")
async def connect_sqlite(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
):
    """Upload a SQLite .db file and connect to it."""
    if not file.filename.endswith((".db", ".sqlite", ".sqlite3")):
        raise HTTPException(status_code=400, detail="Only .db / .sqlite / .sqlite3 files are supported")

    content = await file.read()
    safe_name = f"{uuid.uuid4().hex}_{file.filename}"
    file_path = os.path.join(SQLITE_UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        f.write(content)

    session_id = _session_id(current_user)
    result = connect_database(
        session_id=session_id,
        db_type="sqlite",
        sqlite_path=file_path,
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.get("/schema")
async def get_schema(current_user: dict = Depends(get_current_user)):
    """Get the full schema of the connected database."""
    session_id = _session_id(current_user)
    conn = get_connection(session_id)
    if not conn:
        raise HTTPException(status_code=400, detail="No database connected. Use /db-chat/connect first.")

    schema = conn["schema"]
    total_cols = sum(t["column_count"] for t in schema.values())
    total_rows = sum(t["row_count"] for t in schema.values())

    return {
        "database": conn["database"],
        "db_type": conn["db_type"],
        "schema": schema,
        "table_count": len(schema),
        "total_columns": total_cols,
        "total_rows": total_rows,
        "tables": list(schema.keys()),
    }


@router.get("/schema-summary")
async def get_schema_summary_route(current_user: dict = Depends(get_current_user)):
    """Get human-readable schema summary: tables, columns, rows per table."""
    session_id = _session_id(current_user)
    if not is_connected(session_id):
        raise HTTPException(status_code=400, detail="No database connected.")
    summary = get_schema_summary(session_id)
    return {"summary": summary}


@router.post("/query", response_model=NLQueryResponse)
async def nl_query(req: NLQueryRequest, current_user: dict = Depends(get_current_user)):
    """
    Natural language → SQL → execute → natural language answer + chart.
    This is the main endpoint for talking to your database.
    """
    import time
    t0 = time.perf_counter()

    session_id = _session_id(current_user)
    if not is_connected(session_id):
        raise HTTPException(status_code=400, detail="No database connected. Use /db-chat/connect first.")

    # 1. Generate SQL
    sql, sql_err = generate_sql_for_db(session_id, req.question)
    if sql_err:
        raise HTTPException(status_code=400, detail=f"SQL generation failed: {sql_err}")

    # 2. Execute SQL
    rows, exec_err = execute_sql_on_db(session_id, sql)
    if exec_err:
        raise HTTPException(status_code=400, detail=f"SQL execution failed: {exec_err}")

    # 3. Generate natural language answer
    answer = generate_nl_answer(req.question, rows)

    # 4. Recommend chart
    chart = recommend_chart(req.question, rows, sql=sql)

    latency = round((time.perf_counter() - t0) * 1000, 2)
    logger.info("DB Chat query", user=current_user["username"], latency_ms=latency, rows=len(rows))

    return NLQueryResponse(
        question=req.question,
        sql=sql,
        answer=answer,
        rows=rows,
        row_count=len(rows),
        chart=chart,
        latency_ms=latency,
    )


@router.post("/sql")
async def run_raw_sql(req: RawSQLRequest, current_user: dict = Depends(get_current_user)):
    """Execute a raw SQL query directly (SELECT only)."""
    session_id = _session_id(current_user)
    if not is_connected(session_id):
        raise HTTPException(status_code=400, detail="No database connected.")

    rows, err = execute_sql_on_db(session_id, req.sql)
    if err:
        raise HTTPException(status_code=400, detail=err)
    return {"sql": req.sql, "rows": rows, "row_count": len(rows)}


@router.get("/status")
async def connection_status(current_user: dict = Depends(get_current_user)):
    """Check if a database is connected."""
    session_id = _session_id(current_user)
    conn = get_connection(session_id)
    if not conn:
        return {"connected": False}

    schema = conn["schema"]
    total_cols = sum(t["column_count"] for t in schema.values())
    total_rows = sum(t["row_count"] for t in schema.values())

    return {
        "connected": True,
        "database": conn["database"],
        "db_type": conn["db_type"],
        "table_count": len(schema),
        "total_columns": total_cols,
        "total_rows": total_rows,
        "tables": list(schema.keys()),
    }


@router.post("/disconnect")
async def disconnect(current_user: dict = Depends(get_current_user)):
    """Disconnect from the current database."""
    session_id = _session_id(current_user)
    success = disconnect_database(session_id)
    return {"disconnected": success}
