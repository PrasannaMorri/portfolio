"""
All API routes — FIXED & OPTIMIZED
Fixes:
  - "object of type 'int' has no len()" — was caused by passing doc_ids as raw
    int instead of List[int] when a single doc is selected, and by ChromaDB
    returning count=0 then actual_k clamping to 1 on a zero-result filter.
  - retrieve() now safely returns [] when no matching chunks exist.
  - generate_nl_answer wired in for SQL results.
  - Cached responses properly reconstructed (dict→schema).
"""
import os
import time
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import text

from app.models.schemas import (
    TokenResponse, QueryRequest, QueryResponse,
    DocumentUploadResponse, DocumentInfo,
    SummarizeRequest, SummarizeResponse,
    ExtractRequest, ExtractResponse,
    ReindexRequest, ReindexResponse,
    HealthResponse, RetrievedChunkSchema,
)
from app.core.security import authenticate_user, create_access_token, get_current_user
from app.core.cache import cache_get, cache_set, make_cache_key
from app.core.logging_config import get_logger
from app.db.database import get_db_session, check_db_connection
from app.db.models import Document, DocumentChunk, QueryHistory
from app.services.document_service import parse_and_chunk, save_upload, get_file_type
from app.services.rag_service_v2 import (
    ingest_chunks,
    retrieve,
    get_collection_size,
    delete_document_chunks,
    rebuild_vector_store,
)
from app.services.answer_service import generate_answer, generate_summary, extract_key_info
from app.services.text2sql_service import generate_sql, execute_sql, generate_nl_answer

logger = get_logger(__name__)
router = APIRouter()


# ── Auth ──────────────────────────────────────────────────────────────────────
@router.post("/auth/token", response_model=TokenResponse, tags=["Auth"])
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_access_token(data={"sub": user["username"], "role": user["role"]})
    return TokenResponse(access_token=token)


# ── Document Upload ───────────────────────────────────────────────────────────
@router.post("/documents/upload", response_model=DocumentUploadResponse, tags=["Documents"])
async def upload_document(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
):
    from app.core.config import get_settings
    settings = get_settings()

    allowed = {".pdf", ".csv", ".txt", ".docx", ".doc"}
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in allowed:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {ext}")

    content = await file.read()
    size = len(content)
    max_bytes = settings.max_upload_size_mb * 1024 * 1024
    if size > max_bytes:
        raise HTTPException(status_code=400, detail=f"File too large. Max: {settings.max_upload_size_mb} MB")

    try:
        file_path = save_upload(content, file.filename)
        file_type = get_file_type(file.filename)

        with get_db_session() as session:
            doc = Document(
                filename=file.filename,
                file_type=file_type,
                file_size=size,
                file_path=file_path,
                status="processing",
                uploaded_by=current_user["username"],
            )
            session.add(doc)
            session.flush()
            doc_id = doc.id

        chunks = parse_and_chunk(file_path, file.filename)
        first_content = " ".join(c.content for c in chunks[:5])
        summary = generate_summary(first_content)

        with get_db_session() as session:
            for i, chunk in enumerate(chunks):
                db_chunk = DocumentChunk(
                    document_id=doc_id,
                    chunk_index=i,
                    content=chunk.content,
                    page_number=int(chunk.metadata.get("page", 0)),
                    chroma_id=chunk.id,
                )
                session.add(db_chunk)
            doc = session.get(Document, doc_id)
            doc.status = "ready"
            doc.chunk_count = len(chunks)
            doc.summary = summary

        vector_indexed = True
        try:
            ingest_chunks(chunks, doc_id)
        except Exception as exc:
            vector_indexed = False
            logger.warning(
                "Vector ingest failed; document stored for later reindex",
                filename=file.filename,
                doc_id=doc_id,
                error=str(exc),
            )

        logger.info("Document uploaded", filename=file.filename, chunks=len(chunks), vector_indexed=vector_indexed)
        return DocumentUploadResponse(
            id=doc_id, filename=file.filename, file_type=file_type,
            file_size=size, chunk_count=len(chunks), status="ready", summary=summary,
        )

    except Exception as e:
        logger.error("Upload failed", filename=file.filename, error=str(e))
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


# ── List Documents ────────────────────────────────────────────────────────────
@router.get("/documents", response_model=List[DocumentInfo], tags=["Documents"])
async def list_documents(current_user: dict = Depends(get_current_user)):
    with get_db_session() as session:
        docs = session.query(Document).order_by(Document.created_at.desc()).all()
        return [
            DocumentInfo(
                id=d.id, filename=d.filename, file_type=d.file_type,
                file_size=d.file_size, chunk_count=d.chunk_count or 0,
                status=d.status, summary=d.summary, created_at=d.created_at,
            )
            for d in docs
        ]


# ── Delete Document ───────────────────────────────────────────────────────────
@router.delete("/documents/{doc_id}", tags=["Documents"])
async def delete_document(doc_id: int, current_user: dict = Depends(get_current_user)):
    with get_db_session() as session:
        doc = session.get(Document, doc_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        delete_document_chunks(doc_id)
        session.delete(doc)
    return {"message": f"Document {doc_id} deleted"}


@router.post("/documents/reindex", response_model=ReindexResponse, tags=["Documents"])
async def reindex_documents(
    req: ReindexRequest,
    current_user: dict = Depends(get_current_user),
):
    try:
        doc_ids = [int(doc_id) for doc_id in (req.doc_ids or [])] or None
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"Invalid doc_ids: {exc}")

    result = rebuild_vector_store(doc_ids=doc_ids)
    return ReindexResponse(**result)


# ── Summarize ─────────────────────────────────────────────────────────────────
@router.post("/documents/summarize", response_model=SummarizeResponse, tags=["Documents"])
async def summarize_document(req: SummarizeRequest, current_user: dict = Depends(get_current_user)):
    with get_db_session() as session:
        doc = session.get(Document, req.doc_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        if doc.summary:
            return SummarizeResponse(doc_id=req.doc_id, filename=doc.filename, summary=doc.summary)
        chunks = session.query(DocumentChunk).filter_by(document_id=req.doc_id).limit(10).all()
        content = " ".join(c.content for c in chunks)
        summary = generate_summary(content)
        doc.summary = summary
    return SummarizeResponse(doc_id=req.doc_id, filename=doc.filename, summary=summary)


# ── Extract Key Info ──────────────────────────────────────────────────────────
@router.post("/documents/extract", response_model=ExtractResponse, tags=["Documents"])
async def extract_document_info(req: ExtractRequest, current_user: dict = Depends(get_current_user)):
    with get_db_session() as session:
        doc = session.get(Document, req.doc_id)
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        chunks = session.query(DocumentChunk).filter_by(document_id=req.doc_id).limit(8).all()
        content = " ".join(c.content for c in chunks)
    key_info = extract_key_info(content)
    return ExtractResponse(doc_id=req.doc_id, filename=doc.filename, key_info=key_info)


# ── Main Query ────────────────────────────────────────────────────────────────
@router.post("/query", response_model=QueryResponse, tags=["Query"])
async def query(req: QueryRequest, current_user: dict = Depends(get_current_user)):
    t0 = time.perf_counter()

    # ── Sanitize doc_ids: ensure it's always List[int] or None ──────────────
    doc_ids: Optional[List[int]] = None
    if req.doc_ids:
        # Guard: coerce every element to int to prevent "int has no len()" downstream
        try:
            doc_ids = [int(d) for d in req.doc_ids]
            if not doc_ids:
                doc_ids = None
        except (TypeError, ValueError) as e:
            raise HTTPException(status_code=400, detail=f"Invalid doc_ids: {e}")

    cache_key = make_cache_key("query", req.question, req.mode, req.top_k, str(doc_ids))
    if req.use_cache:
        cached = cache_get(cache_key)
        if cached:
            cached_chunks = cached.get("retrieved_chunks", []) or []
            cached_answer = str(cached.get("answer", ""))
            if not cached_chunks and "No indexed content was found" in cached_answer:
                cached = None
        if cached:
            # Reconstruct retrieved_chunks as proper schema objects from cached dicts
            raw_chunks = cached.get("retrieved_chunks", [])
            cached["retrieved_chunks"] = [
                RetrievedChunkSchema(**c) if isinstance(c, dict) else c
                for c in raw_chunks
            ]
            cached["cached"] = True
            return QueryResponse(**cached)

    try:
        mode = req.mode
        if mode == "auto":
            mode = _detect_mode(req.question)

        answer = ""
        sql = None
        db_result = None
        retrieved_chunks: List[RetrievedChunkSchema] = []
        sources: List[str] = []

        if mode == "sql":
            sql = generate_sql(req.question)
            db_result = execute_sql(sql)
            # Use improved NL answer generator
            answer = generate_nl_answer(req.question, db_result, sql)
            sources = ["database"]

        else:  # rag
            context, raw_chunks = retrieve(
                req.question,
                top_k=req.top_k,
                doc_ids=doc_ids,  # already sanitized List[int] or None
            )

            # FIX: if retrieve returned empty (no matching chunks), give clear message
            if not raw_chunks:
                if doc_ids:
                    answer = (
                        "No indexed content was found for the selected document(s). "
                        "The document may still be processing, or try selecting a different document."
                    )
                else:
                    answer = "No documents have been uploaded yet. Please upload a document first."
            else:
                retrieved_chunks = [
                    RetrievedChunkSchema(
                        content=c.content,
                        score=c.score,
                        source=c.source,
                        page=int(c.page),   # FIX: ensure page is int not str
                    )
                    for c in raw_chunks
                ]
                sources = list(dict.fromkeys(c.source for c in raw_chunks))  # preserve order, deduplicate
                answer = generate_answer(req.question, context, raw_chunks)

        latency = round((time.perf_counter() - t0) * 1000, 2)

        response_data = {
            "question": req.question,
            "answer": answer,
            "mode": mode,
            "sql": sql,
            "result": db_result,
            "retrieved_chunks": [r.model_dump() for r in retrieved_chunks],
            "sources": sources,
            "cached": False,
            "latency_ms": latency,
        }

        should_cache = req.use_cache and not (
            mode == "rag"
            and not retrieved_chunks
            and (
                "No indexed content was found" in answer
                or "No documents have been uploaded yet" in answer
            )
        )

        if should_cache:
            cache_set(cache_key, response_data)

        # Save to history
        try:
            with get_db_session() as session:
                history = QueryHistory(
                    question=req.question,
                    answer=answer,
                    query_type=mode,
                    sql_query=sql,
                    doc_ids=",".join(str(d) for d in (doc_ids or [])),
                    latency_ms=latency,
                    username=current_user["username"],
                )
                session.add(history)
        except Exception as he:
            logger.warning("History save failed", error=str(he))

        logger.info("Query processed", mode=mode, latency_ms=latency)

        # Return with proper schema objects (not raw dicts)
        response_data["retrieved_chunks"] = retrieved_chunks
        return QueryResponse(**response_data)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Query failed", error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


def _detect_mode(question: str) -> str:
    """
    Smarter mode detection — only route to SQL for clear database-style queries.
    Document questions (summarize, what does X say, explain, etc.) → rag
    Analytical/counting/aggregation queries → sql
    """
    q = question.lower().strip()

    # Explicit document intent → always RAG
    doc_intent = [
        "summarize", "summary", "what does", "what did", "explain",
        "describe", "tell me about", "key findings", "main points",
        "what are the", "who is", "when was", "according to",
        "in the document", "in the report", "in the file",
    ]
    if any(kw in q for kw in doc_intent):
        return "rag"

    # Clear database/analytics intent → SQL
    sql_intent = [
        "how many employees", "how many projects", "average salary",
        "avg salary", "total budget", "list all employees", "list all projects",
        "highest salary", "lowest salary", "top 5", "top 10",
        "count of", "number of employees", "number of projects",
        "employees in", "projects in", "salary of", "budget of",
        "active employees", "inactive employees", "active projects",
        "department budget", "department salary",
    ]
    if any(kw in q for kw in sql_intent):
        return "sql"

    return "rag"  # default to RAG — safer for document-heavy workflows


# ── Query History ─────────────────────────────────────────────────────────────
@router.get("/history", tags=["Query"])
async def get_history(limit: int = 20, current_user: dict = Depends(get_current_user)):
    with get_db_session() as session:
        records = (
            session.query(QueryHistory)
            .filter_by(username=current_user["username"])
            .order_by(QueryHistory.created_at.desc())
            .limit(limit)
            .all()
        )
        return [
            {
                "id": r.id,
                "question": r.question,
                "answer": r.answer,
                "mode": r.query_type,
                "sql": r.sql_query,
                "latency_ms": r.latency_ms,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in records
        ]


# ── Health ────────────────────────────────────────────────────────────────────
@router.get("/health", response_model=HealthResponse, tags=["System"])
async def health():
    from app.core.cache import get_redis
    db_ok = check_db_connection()
    redis_ok = False
    try:
        rc = get_redis()
        if rc:
            redis_ok = rc.ping()
    except Exception:
        pass
    try:
        chunk_count = get_collection_size()
        chroma_ok = True
    except Exception:
        chunk_count = 0
        chroma_ok = False

    doc_count = 0
    try:
        with get_db_session() as session:
            doc_count = session.query(Document).count()
    except Exception:
        pass

    return HealthResponse(
        status="healthy" if db_ok else "degraded",
        version="2.0.0",
        services={
            "database": "ok" if db_ok else "error",
            "redis": "ok" if redis_ok else "unavailable",
            "chromadb": f"ok ({chunk_count} chunks)" if chroma_ok else "error",
        },
        document_count=doc_count,
        chunk_count=chunk_count,
    )
