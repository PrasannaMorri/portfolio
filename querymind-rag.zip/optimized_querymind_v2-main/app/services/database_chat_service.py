"""
Database Chat Service — "Talk to Your Database"

Features:
  1. Connect to any PostgreSQL / SQLite database
  2. Auto-extract full schema (tables, columns, types, PKs, FKs, row counts)
  3. Generate SQL from natural language using DAIL-SQL style prompts
  4. Execute SQL safely (SELECT only + guardrails)
  5. Generate rich natural language answer from results
  6. Recommend chart type automatically
  7. Store connection configs per user session
"""
from __future__ import annotations
import re
import json
from typing import Any, Dict, List, Optional, Tuple
from sqlalchemy import create_engine, text, inspect, MetaData
from app.core.logging_config import get_logger
from app.services.llm_service import call_llm, clean_sql_output
from app.services.tabular_presenter import (
    answer_is_low_quality,
    build_results_preview,
    build_tabular_fallback_answer,
    choose_label_column,
    choose_metric_column,
    format_value,
    make_json_safe,
    recommend_chart as build_chart_spec,
)

logger = get_logger(__name__)

# ── In-memory connection store (keyed by session token) ───────────────────────
_connections: Dict[str, Dict] = {}

FORBIDDEN_KEYWORDS = [
    "drop","delete","update","insert","alter","truncate",
    "create","grant","revoke","exec","xp_","--","/*","pg_",
    "information_schema","copy","into outfile",
]


# ── Connection management ─────────────────────────────────────────────────────

def connect_database(
    session_id: str,
    db_type: str,
    host: str = "localhost",
    port: int = 5432,
    database: str = "",
    username: str = "",
    password: str = "",
    sqlite_path: str = "",
) -> Dict[str, Any]:
    """Connect to a database, extract schema, store connection."""
    try:
        if db_type == "sqlite":
            url = f"sqlite:///{sqlite_path}"
        else:
            url = f"postgresql://{username}:{password}@{host}:{port}/{database}"

        engine = create_engine(
            url,
            pool_pre_ping=True,
            connect_args={"connect_timeout": 10} if db_type != "sqlite" else {},
        )
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        schema = _extract_schema(engine)

        _connections[session_id] = {
            "engine": engine,
            "schema": schema,
            "db_type": db_type,
            "database": database or sqlite_path,
            "url": url,
        }

        logger.info("Database connected", session=session_id[:8], db=database or sqlite_path)
        return {
            "success": True,
            "database": database or sqlite_path,
            "db_type": db_type,
            "tables": list(schema.keys()),
            "table_count": len(schema),
            "schema": schema,
        }

    except Exception as e:
        logger.error("Database connection failed", error=str(e))
        return {"success": False, "error": str(e)}


def disconnect_database(session_id: str) -> bool:
    if session_id in _connections:
        try:
            _connections[session_id]["engine"].dispose()
        except Exception:
            pass
        del _connections[session_id]
        return True
    return False


def get_connection(session_id: str) -> Optional[Dict]:
    return _connections.get(session_id)


def is_connected(session_id: str) -> bool:
    return session_id in _connections


# ── Schema extraction ─────────────────────────────────────────────────────────

def _extract_schema(engine) -> Dict[str, Any]:
    """Extract full schema: tables, columns, types, PKs, FKs, row counts."""
    schema = {}
    try:
        inspector = inspect(engine)
        table_names = inspector.get_table_names()

        for table_name in table_names:
            columns = []
            for col in inspector.get_columns(table_name):
                columns.append({
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col.get("nullable", True),
                    "default": str(col.get("default", "") or ""),
                })

            pks = inspector.get_pk_constraint(table_name).get("constrained_columns", [])
            fks = []
            for fk in inspector.get_foreign_keys(table_name):
                fks.append({
                    "columns": fk["constrained_columns"],
                    "ref_table": fk["referred_table"],
                    "ref_columns": fk["referred_columns"],
                })

            row_count = 0
            try:
                with engine.connect() as conn:
                    result = conn.execute(text(f'SELECT COUNT(*) FROM "{table_name}"'))
                    row_count = result.scalar() or 0
            except Exception:
                pass

            sample_rows = []
            try:
                with engine.connect() as conn:
                    result = conn.execute(text(f'SELECT * FROM "{table_name}" LIMIT 3'))
                    cols = list(result.keys())
                    for row in result:
                        sample_rows.append(dict(zip(cols, [str(v) if v is not None else "" for v in row])))
            except Exception:
                pass

            schema[table_name] = {
                "columns": columns,
                "column_count": len(columns),
                "primary_keys": pks,
                "foreign_keys": fks,
                "row_count": int(row_count),
                "sample_rows": sample_rows,
            }

        logger.info("Schema extracted", tables=len(schema))
    except Exception as e:
        logger.error("Schema extraction failed", error=str(e))

    return schema


def get_schema_summary(session_id: str) -> str:
    """Return a human-readable schema summary: tables, columns, rows."""
    conn = get_connection(session_id)
    if not conn:
        return "No database connected."
    schema = conn["schema"]
    if not schema:
        return "No tables found."

    total_tables = len(schema)
    total_cols = sum(t["column_count"] for t in schema.values())
    total_rows = sum(t["row_count"] for t in schema.values())

    lines = [
        f"Database: {conn['database']} ({conn['db_type'].upper()})",
        f"Overview: {total_tables} tables, {total_cols} columns, {total_rows:,} total rows",
        "",
    ]
    for tname, tinfo in schema.items():
        col_names = ", ".join(c["name"] for c in tinfo["columns"])
        lines.append(
            f"• {tname}: {tinfo['row_count']:,} rows × {tinfo['column_count']} columns  [{col_names}]"
        )
        if tinfo["foreign_keys"]:
            for fk in tinfo["foreign_keys"]:
                lines.append(f"    FK: {fk['columns']} → {fk['ref_table']}.{fk['ref_columns']}")

    return "\n".join(lines)


def _schema_to_prompt(schema: Dict[str, Any]) -> str:
    """Convert schema dict to Code Representation format for LLM prompt."""
    lines = []
    for table, info in schema.items():
        cols = ", ".join(
            f"{c['name']} {c['type']}{'  PK' if c['name'] in info['primary_keys'] else ''}"
            for c in info["columns"]
        )
        lines.append(f"Table: {table} ({info['row_count']} rows, {info['column_count']} columns)")
        lines.append(f"  Columns: {cols}")
        if info["foreign_keys"]:
            for fk in info["foreign_keys"]:
                lines.append(f"  FK: {fk['columns']} → {fk['ref_table']}.{fk['ref_columns']}")
        if info["sample_rows"]:
            sample = info["sample_rows"][0]
            sample_str = ", ".join(f"{k}={repr(v)}" for k, v in list(sample.items())[:4])
            lines.append(f"  Sample: {sample_str}")
        lines.append("")
    return "\n".join(lines)


# ── SQL generation ────────────────────────────────────────────────────────────

def generate_sql_for_db(session_id: str, question: str) -> Tuple[str, str]:
    conn = get_connection(session_id)
    if not conn:
        return "", "No database connected."

    schema = conn["schema"]
    tables = list(schema.keys())

    if not tables:
        return "", "No tables found in database."

    # Handle schema overview questions without SQL
    q_lower = question.lower()
    schema_keywords = ["how many columns", "how many rows", "what tables", "describe", "schema", "structure", "overview"]
    if any(kw in q_lower for kw in schema_keywords) and "in" not in q_lower:
        # These are answered by get_schema_summary, not SQL
        # But still generate a valid SQL as fallback
        pass

    # Always try smart rule-based first — it knows exact table names
    try:
        sql = _rule_based_fallback(question, schema)
        _validate_sql(sql, schema)
        logger.info("Rule-based SQL generated", sql=sql[:150])
        return sql, ""
    except Exception:
        pass

    # LLM fallback with exact table names injected
    schema_text = _schema_to_prompt(schema)
    table_list  = ", ".join(f'"{t}"' for t in tables)

    system = f"""You are a PostgreSQL expert.
The database has EXACTLY these tables: {table_list}
Generate ONE valid SELECT query using ONLY those table names.
Prefer specific columns over SELECT * unless the user explicitly asks for every column.
For ranking questions, include the main label column plus the requested metric column.
Output raw SQL only — no markdown, no explanation."""

    user = f"""Schema:
{schema_text}

Question: {question}

SQL (use only tables: {table_list}):"""

    try:
        raw = call_llm(system, user)
        sql = clean_sql_output(raw)

        uses_real_table = any(t.lower() in sql.lower() for t in tables)
        if not sql.upper().strip().startswith("SELECT") or not uses_real_table:
            sql = _rule_based_fallback(question, schema)

        _validate_sql(sql, schema)
        return sql, ""

    except Exception as e:
        logger.error("SQL generation failed", error=str(e))
        return "", f"Could not generate SQL: {str(e)}"


def _validate_sql(query: str, schema: Dict) -> None:
    if not query or not query.strip():
        raise ValueError("Empty query")

    clean = query.strip()

    if not re.match(r"^\s*SELECT\b", clean, re.IGNORECASE):
        raise ValueError("Only SELECT queries are allowed.")

    for kw in FORBIDDEN_KEYWORDS:
        if re.search(r'\b' + re.escape(kw) + r'\b', clean, re.IGNORECASE):
            raise ValueError(f"Forbidden operation detected: {kw}")

    if len(clean) > 3000:
        raise ValueError("Query too long")


def _rule_based_fallback(question: str, schema: Dict) -> str:
    """Smart rule-based SQL — always uses correct table names."""
    q = question.lower()
    tables = list(schema.keys())
    if not tables:
        return "SELECT 1"

    # Find most relevant table
    best_table = tables[0]
    for table in tables:
        if table.lower() in q:
            best_table = table
            break

    t = f'"{best_table}"'
    cols = schema[best_table]["columns"]
    col_names  = [c["name"] for c in cols]
    num_cols   = [c["name"] for c in cols if any(
        x in c["type"].lower() for x in ["int","float","numeric","decimal","double","real","money","bigint"]
    )]
    text_cols  = [c["name"] for c in cols if c["name"] not in num_cols]
    date_cols  = [c["name"] for c in cols if any(
        x in c["name"].lower() for x in ["date","time","year","month","day"]
    )]

    def tc(col): return f'"{col}"'

    label_col = choose_label_column(question, [{name: None for name in col_names}]) if col_names else None
    metric_col = choose_metric_column(question, [{name: 0 for name in num_cols}] if num_cols else [])

    def select_projection(metric: Optional[str] = None) -> str:
        projection: List[str] = []
        if label_col and label_col in col_names:
            projection.append(tc(label_col))
        elif text_cols:
            projection.append(tc(text_cols[0]))

        target_metric = metric if metric in col_names else None
        if target_metric:
            projection.append(tc(target_metric))

        for date_col in date_cols[:1]:
            if date_col not in projection:
                projection.append(tc(date_col))

        if not projection:
            projection = [tc(col_names[0])]
            if len(col_names) > 1:
                projection.append(tc(col_names[1]))

        return ", ".join(dict.fromkeys(projection))

    # Schema overview queries — return summary per table
    if any(w in q for w in ["how many columns", "columns in", "structure of", "describe"]):
        col_list = ", ".join(f"'{c['name']} {c['type']}'" for c in cols)
        return f"SELECT {tc(col_names[0])} FROM {t} LIMIT 1"

    # COUNT queries
    if any(w in q for w in ["how many","count","total number","number of"]):
        if text_cols and any(w in q for w in ["each","per","by","group","breakdown"]):
            return f'SELECT {tc(text_cols[0])}, COUNT(*) AS total FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY total DESC'
        return f'SELECT COUNT(*) AS total_rows FROM {t}'

    # AVERAGE queries
    if any(w in q for w in ["average","avg","mean"]):
        for nc in num_cols:
            if nc.lower() in q:
                if text_cols:
                    return f'SELECT {tc(text_cols[0])}, ROUND(AVG({tc(nc)}::numeric), 2) AS avg_{nc} FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY avg_{nc} DESC'
                return f'SELECT ROUND(AVG({tc(nc)}::numeric), 2) AS avg_{nc} FROM {t}'
        if num_cols:
            if text_cols:
                return f'SELECT {tc(text_cols[0])}, ROUND(AVG({tc(num_cols[0])}::numeric), 2) AS average FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY average DESC'
            return f'SELECT ROUND(AVG({tc(num_cols[0])}::numeric), 2) AS average FROM {t}'

    # SUM / TOTAL queries
    if any(w in q for w in ["sum","total","cost","expenditure"]):
        for nc in num_cols:
            if nc.lower() in q or any(w in q for w in ["salary","cost","budget","revenue","amount","bonus"]):
                if text_cols:
                    return f'SELECT {tc(text_cols[0])}, ROUND(SUM({tc(nc)}::numeric), 2) AS total_{nc} FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY total_{nc} DESC'
                return f'SELECT ROUND(SUM({tc(nc)}::numeric), 2) AS total FROM {t}'
        if num_cols:
            if text_cols:
                return f'SELECT {tc(text_cols[0])}, ROUND(SUM({tc(num_cols[0])}::numeric), 2) AS total FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY total DESC'

    # MAX / TOP queries
    if any(w in q for w in ["highest","maximum","max","top","most","largest","best"]):
        limit = 10
        for w in q.split():
            if w.isdigit():
                limit = int(w)
                break
        if num_cols:
            for nc in num_cols:
                if nc.lower() in q:
                    return f'SELECT {select_projection(nc)} FROM {t} ORDER BY {tc(nc)} DESC LIMIT {limit}'
            return f'SELECT {select_projection(metric_col or num_cols[0])} FROM {t} ORDER BY {tc(metric_col or num_cols[0])} DESC LIMIT {limit}'

    # MIN / LOWEST queries
    if any(w in q for w in ["lowest","minimum","min","least","smallest","worst","bottom"]):
        limit = 10
        if num_cols:
            return f'SELECT {select_projection(metric_col or num_cols[0])} FROM {t} ORDER BY {tc(metric_col or num_cols[0])} ASC LIMIT {limit}'

    # DISTINCT / UNIQUE
    if any(w in q for w in ["distinct","unique","different","variety"]):
        if text_cols:
            return f'SELECT DISTINCT {tc(text_cols[0])}, COUNT(*) AS count FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY count DESC'

    # GROUP BY
    if any(w in q for w in ["group","grouped","by department","by city","by status","per department"]):
        if text_cols and num_cols:
            return f'SELECT {tc(text_cols[0])}, COUNT(*) AS total, ROUND(AVG({tc(num_cols[0])}::numeric),2) AS average FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY total DESC'
        if text_cols:
            return f'SELECT {tc(text_cols[0])}, COUNT(*) AS total FROM {t} GROUP BY {tc(text_cols[0])} ORDER BY total DESC'

    # FILTER queries (WHERE)
    for col in col_names:
        if col.lower() in q:
            words = q.split()
            for i, w in enumerate(words):
                if w == col.lower() and i + 1 < len(words):
                    val = words[i + 1].strip("?.,")
                    return f"SELECT {select_projection(metric_col)} FROM {t} WHERE {tc(col)} ILIKE '%{val}%' LIMIT 50"

    # JOIN queries
    if any(w in q for w in ["join","joined","together","combined","with"]):
        all_tables = list(schema.keys())
        if len(all_tables) >= 2:
            t2 = all_tables[1]
            t1_cols = [c["name"] for c in schema[all_tables[0]]["columns"]]
            t2_cols = [c["name"] for c in schema[t2]["columns"]]
            # Find potential join column
            common = [c for c in t1_cols if c in t2_cols]
            fks = schema[all_tables[0]].get("foreign_keys", [])
            if fks:
                fk = fks[0]
                join_col = fk["columns"][0]
                ref_col  = fk["ref_columns"][0]
                return (
                    f'SELECT a.*, b.* FROM "{all_tables[0]}" a '
                    f'JOIN "{t2}" b ON a."{join_col}" = b."{ref_col}" LIMIT 20'
                )
            elif common:
                jc = common[0]
                return (
                    f'SELECT a.*, b.* FROM "{all_tables[0]}" a '
                    f'JOIN "{t2}" b ON a."{jc}" = b."{jc}" LIMIT 20'
                )

    # Default — show all
    default_projection = ", ".join(tc(col) for col in col_names[: min(4, len(col_names))])
    return f'SELECT {default_projection} FROM {t} LIMIT 20'


# ── SQL Execution ─────────────────────────────────────────────────────────────

def execute_sql_on_db(session_id: str, sql: str) -> Tuple[List[Dict], str]:
    """Execute SQL on connected database. Returns (rows, error_message)"""
    conn = get_connection(session_id)
    if not conn:
        return [], "No database connected"

    try:
        _validate_sql(sql, conn["schema"])
        engine = conn["engine"]
        with engine.connect() as connection:
            result = connection.execute(text(sql))
            columns = list(result.keys())
            rows = [
                {col: make_json_safe(v) for col, v in zip(columns, row)}
                for row in result.fetchmany(500)
            ]
        logger.info("SQL executed on user DB", rows=len(rows))
        return rows, ""
    except ValueError as e:
        return [], str(e)
    except Exception as e:
        logger.error("SQL execution failed", error=str(e))
        return [], f"Execution error: {str(e)}"


# ── Natural language answer ───────────────────────────────────────────────────

NL_SYSTEM = """You are a helpful data analyst assistant.
Given a user question and database query results, write a clear, informative answer.
Rules:
- Give a direct, specific answer in 2-4 sentences
- Mention exact numbers, values, and names from the results
- If there are multiple rows, summarize the key insight (e.g. top item, totals, ranges)
- Do NOT mention SQL, queries, or technical terms
- If no results, explain clearly that no data matched"""

NL_USER = """Question: {question}

Query results ({count} rows):
{data}

Answer (mention specific values from the results):"""


def generate_nl_answer(question: str, rows: List[Dict]) -> str:
    if not rows:
        return "The query returned no results. This may mean no data matches your criteria."

    data_str = build_results_preview(rows, limit=8)

    try:
        answer = call_llm(
            NL_SYSTEM,
            NL_USER.format(question=question, count=len(rows), data=data_str),
            max_new_tokens=200,
        )
        result = answer.strip()
        return result if result and not answer_is_low_quality(result) else _fallback_answer(question, rows)
    except Exception as e:
        logger.warning("NL answer failed", error=str(e))
        return _fallback_answer(question, rows)


def _fallback_answer(question: str, rows: List[Dict]) -> str:
    return build_tabular_fallback_answer(question, rows)


# ── Chart recommendation ──────────────────────────────────────────────────────

def recommend_chart(question: str, rows: List[Dict], sql: str = "") -> Dict:
    return build_chart_spec(question, rows, sql=sql)
