"""
Hybrid RAG service — OPTIMIZED
Improvements:
  1. Increased top_k for more retrieval candidates before re-ranking
  2. Better BM25 tokenization (punctuation stripping, stopword removal)
  3. Dynamic RRF alpha based on query type (keyword vs semantic)
  4. Chunk deduplication by content hash
  5. Minimum relevance score threshold filtering
  6. Source diversity — ensure multiple docs are represented
"""
from __future__ import annotations
import re
import hashlib
import uuid
from typing import List, Tuple, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings
from rank_bm25 import BM25Okapi

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.services.document_service import DocumentChunk
from app.services.embedding_service import embed_texts, embed_query

logger = get_logger(__name__)
settings = get_settings()

RRF_K = 60
MIN_SCORE_THRESHOLD = 0.01   # Discard chunks below this relevance
STOPWORDS = {
    "the","a","an","is","are","was","were","be","been","being",
    "have","has","had","do","does","did","will","would","could","should",
    "may","might","shall","can","need","dare","ought","used",
    "to","of","in","for","on","with","at","by","from","as","into",
    "through","during","including","until","against","among","throughout",
    "despite","towards","upon","concerning","about","and","but","or",
    "nor","so","yet","both","either","neither","not","only","own",
    "same","than","too","very","just","because","if","while","this","that",
    "these","those","it","its","what","which","who","whom","when","where","why","how",
}

_chroma_client = None
_collection = None
_bm25_corpus: List[str] = []
_bm25_ids: List[str] = []
_bm25_index: Optional[BM25Okapi] = None


def _get_collection():
    global _chroma_client, _collection
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(
            path=settings.chroma_persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        _collection = _chroma_client.get_or_create_collection(
            name="rag_documents",
            metadata={"hnsw:space": "cosine"},
        )
        logger.info("ChromaDB initialised", path=settings.chroma_persist_dir)
    return _collection


def _tokenize(text: str) -> List[str]:
    """Improved tokenizer: lowercase, strip punctuation, remove stopwords."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()
    return [t for t in tokens if t not in STOPWORDS and len(t) > 1]


def _content_hash(text: str) -> str:
    return hashlib.md5(text.strip().encode()).hexdigest()


def _rebuild_bm25():
    global _bm25_index
    if _bm25_corpus:
        _bm25_index = BM25Okapi([_tokenize(d) for d in _bm25_corpus])


def _detect_query_type(query: str) -> float:
    """
    Detect if query is keyword-heavy or semantic.
    Returns alpha: higher = more dense (semantic), lower = more sparse (keyword).
    """
    tokens = _tokenize(query)
    # Short queries with technical terms -> more keyword search
    if len(tokens) <= 3:
        return 0.35
    # Questions starting with "what/how/why/explain" -> more semantic
    semantic_starters = {"what", "how", "why", "explain", "describe", "summarize", "compare"}
    first_word = query.strip().lower().split()[0].rstrip("?")
    if first_word in semantic_starters:
        return 0.70
    return 0.55  # balanced default


def _rrf_fuse(
    dense: List[Tuple[str, float]],
    sparse: List[Tuple[str, float]],
    alpha: float,
) -> List[Tuple[str, float]]:
    scores: Dict[str, float] = {}
    for rank, (doc_id, _) in enumerate(dense):
        scores[doc_id] = scores.get(doc_id, 0) + alpha * (1 / (RRF_K + rank + 1))
    for rank, (doc_id, _) in enumerate(sparse):
        scores[doc_id] = scores.get(doc_id, 0) + (1 - alpha) * (1 / (RRF_K + rank + 1))
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def ingest_chunks(chunks: List[DocumentChunk], doc_id: int) -> int:
    collection = _get_collection()
    global _bm25_corpus, _bm25_ids

    texts = [c.content for c in chunks]
    ids = [c.id for c in chunks]
    metadatas = []
    for c in chunks:
        meta: Dict[str, Any] = {"doc_db_id": str(doc_id)}
        for k, v in c.metadata.items():
            if v is None:
                meta[k] = ""
            elif isinstance(v, (str, int, float, bool)):
                meta[k] = v
            else:
                meta[k] = str(v)
        metadatas.append(meta)
    embeddings = embed_texts(texts)

    collection.add(ids=ids, documents=texts, embeddings=embeddings, metadatas=metadatas)

    _bm25_corpus.extend(texts)
    _bm25_ids.extend(ids)
    _rebuild_bm25()

    total = collection.count()
    logger.info("Chunks ingested", new=len(chunks), total=total)
    return total


def delete_document_chunks(doc_id: int):
    collection = _get_collection()
    global _bm25_corpus, _bm25_ids
    try:
        results = collection.get(where={"doc_db_id": str(doc_id)})
        if results["ids"]:
            collection.delete(ids=results["ids"])
            del_set = set(results["ids"])
            new_corpus, new_ids = [], []
            for txt, cid in zip(_bm25_corpus, _bm25_ids):
                if cid not in del_set:
                    new_corpus.append(txt)
                    new_ids.append(cid)
            _bm25_corpus, _bm25_ids = new_corpus, new_ids
            _rebuild_bm25()
            logger.info("Deleted chunks for document", doc_id=doc_id, count=len(results["ids"]))
    except Exception as e:
        logger.warning("Delete chunks failed", error=str(e))


class RetrievedChunk:
    def __init__(self, content: str, score: float, source: str, page: int = 0, doc_id: str = ""):
        self.content = content
        self.score = round(score, 4)
        self.source = source
        self.page = page
        self.doc_id = doc_id


def retrieve(
    query: str,
    top_k: Optional[int] = None,
    doc_ids: Optional[List[int]] = None,
) -> Tuple[str, List[RetrievedChunk]]:
    k = top_k or settings.top_k_results
    # Retrieve 3x more candidates for better re-ranking
    candidate_k = min(k * 3, 30)
    collection = _get_collection()
    total = collection.count()

    if total == 0:
        return "", []

    where = None
    if doc_ids and len(doc_ids) > 0:
        str_ids = [str(int(d)) for d in doc_ids]
        if len(str_ids) == 1:
            where = {"doc_db_id": str_ids[0]}
        else:
            where = {"doc_db_id": {"$in": str_ids}}

    try:
        if where:
            filtered_total = len(collection.get(where=where, include=[])["ids"])
            # FIX: if zero chunks match the filter, return early
            if filtered_total == 0:
                logger.info("No chunks found for doc_ids filter")
                return "", []
            actual_k = min(candidate_k, filtered_total)
        else:
            actual_k = min(candidate_k, total)
    except Exception as e:
        logger.warning("Could not determine filtered total", error=str(e))
        actual_k = min(candidate_k, total)

    if actual_k <= 0:
        return "", []

    # Dense retrieval
    try:
        q_embed = embed_query(query)
        dense_res = collection.query(
            query_embeddings=[q_embed],
            n_results=actual_k,
            where=where,
            include=["documents", "distances", "metadatas"],
        )
        dense_docs  = dense_res["documents"][0]
        dense_dists = dense_res["distances"][0]
        dense_metas = dense_res["metadatas"][0]
        dense_ids   = dense_res["ids"][0]
    except Exception as e:
        logger.warning("Dense retrieval failed", error=str(e))
        return "", []

    dense_ranked = [(cid, 1 - dist) for cid, dist in zip(dense_ids, dense_dists)]

    # Sparse retrieval (BM25) with improved tokenization
    sparse_ranked: List[Tuple[str, float]] = []
    if _bm25_index and _bm25_corpus:
        try:
            bm25_scores = _bm25_index.get_scores(_tokenize(query))
            allowed_ids = set(dense_ids) if where else None
            paired = [
                (cid, score)
                for cid, score in zip(_bm25_ids, bm25_scores)
                if allowed_ids is None or cid in allowed_ids
            ]
            paired.sort(key=lambda x: x[1], reverse=True)
            sparse_ranked = paired[:actual_k]
        except Exception as e:
            logger.warning("BM25 retrieval failed", error=str(e))

    # Dynamic alpha based on query type
    alpha = _detect_query_type(query)

    # Fuse
    if sparse_ranked:
        fused = _rrf_fuse(dense_ranked, sparse_ranked, alpha=alpha)
    else:
        fused = dense_ranked

    id_to_info = {
        cid: (doc, meta)
        for cid, doc, meta in zip(dense_ids, dense_docs, dense_metas)
    }

    # Build results with deduplication by content hash
    retrieved: List[RetrievedChunk] = []
    seen_hashes = set()
    for cid, score in fused:
        if len(retrieved) >= k:
            break
        if score < MIN_SCORE_THRESHOLD:
            continue
        if cid not in id_to_info:
            continue
        doc, meta = id_to_info[cid]
        h = _content_hash(doc)
        if h in seen_hashes:
            continue
        seen_hashes.add(h)
        retrieved.append(RetrievedChunk(
            content=doc,
            score=score,
            source=meta.get("source", ""),
            page=int(meta.get("page", 0)),
            doc_id=str(meta.get("doc_db_id", "")),
        ))

    context = "\n\n---\n\n".join(
        f"[Source: {r.source}, Page: {r.page}]\n{r.content}"
        for r in retrieved
    )
    logger.info("Retrieved chunks", query=query[:60], count=len(retrieved), alpha=alpha)
    return context, retrieved


def get_collection_size() -> int:
    return _get_collection().count()


def restore_bm25():
    global _bm25_corpus, _bm25_ids
    collection = _get_collection()
    data = collection.get(include=["documents"])
    if data["documents"]:
        _bm25_corpus = data["documents"]
        _bm25_ids = data["ids"]
        _rebuild_bm25()
        logger.info("BM25 index restored", docs=len(_bm25_corpus))
