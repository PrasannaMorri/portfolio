"""
Hybrid RAG service hardened for real-world failures.

Key improvements:
  1. Chroma is automatically repaired from relational chunk storage when empty.
  2. Retrieval can fall back to database-backed lexical ranking if vector search fails.
  3. BM25 now stays in sync with upserts instead of drifting over time.
  4. Sparse-only hits are preserved instead of being dropped during fusion.
  5. Broad "summarize this document" style questions use overview retrieval.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

import chromadb
from chromadb.config import Settings as ChromaSettings
from rank_bm25 import BM25Okapi

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.services.document_service import DocumentChunk
from app.services.embedding_service import embed_query, embed_texts

logger = get_logger(__name__)
settings = get_settings()

RRF_K = 60
MIN_SCORE_THRESHOLD = 0.01
MAX_CANDIDATE_MULTIPLIER = 4
MAX_CANDIDATES = 40
DB_FALLBACK_SCAN_LIMIT = 200

STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could", "should",
    "may", "might", "shall", "can", "need", "dare", "ought", "used",
    "to", "of", "in", "for", "on", "with", "at", "by", "from", "as", "into",
    "through", "during", "including", "until", "against", "among", "throughout",
    "despite", "towards", "upon", "concerning", "about", "and", "but", "or",
    "nor", "so", "yet", "both", "either", "neither", "not", "only", "own",
    "same", "than", "too", "very", "just", "because", "if", "while", "this", "that",
    "these", "those", "it", "its", "what", "which", "who", "whom", "when", "where", "why", "how",
}
OVERVIEW_PATTERNS = (
    "summarize",
    "summary",
    "overview",
    "main points",
    "key points",
    "what does this",
    "what is this",
    "what does that",
    "tell me about",
    "document about",
    "pdf about",
    "report about",
)

_chroma_client = None
_collection = None
_bm25_text_by_id: Dict[str, str] = {}
_bm25_corpus: List[str] = []
_bm25_ids: List[str] = []
_bm25_index: Optional[BM25Okapi] = None


def _get_collection():
    global _chroma_client, _collection
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(
            path=settings.chroma_persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        _collection = _chroma_client.get_or_create_collection(
            name="rag_documents",
            metadata={"hnsw:space": "cosine"},
        )
        logger.info("ChromaDB initialised", path=settings.chroma_persist_dir)
    return _collection


def _tokenize(text: str) -> List[str]:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()
    return [token for token in tokens if token not in STOPWORDS and len(token) > 1]


def _content_hash(text: str) -> str:
    return hashlib.md5(text.strip().encode("utf-8")).hexdigest()


def _stable_chunk_id(doc_id: int, chunk_index: int, content: str) -> str:
    digest = _content_hash(content)[:12]
    return f"doc-{doc_id}-chunk-{chunk_index}-{digest}"


def _rebuild_bm25():
    global _bm25_index, _bm25_corpus, _bm25_ids
    if not _bm25_text_by_id:
        _bm25_ids = []
        _bm25_corpus = []
        _bm25_index = None
        return

    _bm25_ids = list(_bm25_text_by_id.keys())
    _bm25_corpus = [_bm25_text_by_id[chunk_id] for chunk_id in _bm25_ids]
    _bm25_index = BM25Okapi([_tokenize(text) for text in _bm25_corpus])


def _upsert_bm25_entries(records: Iterable[Dict[str, Any]]) -> None:
    updated = False
    for record in records:
        chunk_id = record["id"]
        text = record["document"]
        if _bm25_text_by_id.get(chunk_id) != text:
            _bm25_text_by_id[chunk_id] = text
            updated = True
    if updated:
        _rebuild_bm25()


def _delete_bm25_entries(chunk_ids: Iterable[str]) -> None:
    updated = False
    for chunk_id in chunk_ids:
        if chunk_id in _bm25_text_by_id:
            _bm25_text_by_id.pop(chunk_id, None)
            updated = True
    if updated:
        _rebuild_bm25()


def _detect_query_type(query: str) -> float:
    tokens = _tokenize(query)
    if len(tokens) <= 3:
        return 0.35

    semantic_starters = {"what", "how", "why", "explain", "describe", "summarize", "compare"}
    first_word = query.strip().lower().split()[0].rstrip("?") if query.strip() else ""
    if first_word in semantic_starters:
        return 0.70
    return settings.hybrid_alpha


def _is_overview_query(query: str) -> bool:
    lowered = " ".join(query.lower().split())
    if any(pattern in lowered for pattern in OVERVIEW_PATTERNS):
        return True
    return len(_tokenize(query)) <= 2 and any(word in lowered for word in ("pdf", "doc", "document", "file", "report"))


def _rrf_fuse(
    dense: List[Tuple[str, float]],
    sparse: List[Tuple[str, float]],
    alpha: float,
) -> List[Tuple[str, float]]:
    scores: Dict[str, float] = {}
    for rank, (chunk_id, _) in enumerate(dense):
        scores[chunk_id] = scores.get(chunk_id, 0.0) + alpha * (1 / (RRF_K + rank + 1))
    for rank, (chunk_id, _) in enumerate(sparse):
        scores[chunk_id] = scores.get(chunk_id, 0.0) + (1 - alpha) * (1 / (RRF_K + rank + 1))
    return sorted(scores.items(), key=lambda item: item[1], reverse=True)


def _coerce_metadata_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def _chunk_records_for_upload(chunks: List[DocumentChunk], doc_id: int) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    for chunk in chunks:
        metadata: Dict[str, Any] = {"doc_db_id": str(doc_id)}
        for key, value in chunk.metadata.items():
            metadata[key] = _coerce_metadata_value(value)
        records.append({
            "id": chunk.id,
            "document": chunk.content,
            "metadata": metadata,
        })
    return records


def _upsert_records(records: List[Dict[str, Any]]) -> int:
    if not records:
        return _get_collection().count()

    collection = _get_collection()
    batch_size = max(1, settings.rag_repair_batch_size)

    for start in range(0, len(records), batch_size):
        batch = records[start:start + batch_size]
        texts = [record["document"] for record in batch]
        embeddings = embed_texts(texts)
        collection.upsert(
            ids=[record["id"] for record in batch],
            documents=texts,
            embeddings=embeddings,
            metadatas=[record["metadata"] for record in batch],
        )
        _upsert_bm25_entries(batch)

    total = collection.count()
    logger.info("Chunks upserted", batch_count=len(records), total=total)
    return total


def ingest_chunks(chunks: List[DocumentChunk], doc_id: int) -> int:
    return _upsert_records(_chunk_records_for_upload(chunks, doc_id))


def delete_document_chunks(doc_id: int):
    collection = _get_collection()
    try:
        results = collection.get(where={"doc_db_id": str(doc_id)})
        chunk_ids = results.get("ids", []) or []
        if chunk_ids:
            collection.delete(ids=chunk_ids)
            _delete_bm25_entries(chunk_ids)
            logger.info("Deleted chunks for document", doc_id=doc_id, count=len(chunk_ids))
    except Exception as exc:
        logger.warning("Delete chunks failed", error=str(exc))


class RetrievedChunk:
    def __init__(self, content: str, score: float, source: str, page: int = 0, doc_id: str = ""):
        self.content = content
        self.score = round(score, 4)
        self.source = source
        self.page = page
        self.doc_id = doc_id


def _load_db_chunk_rows(
    doc_ids: Optional[List[int]] = None,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    try:
        from app.db.database import get_db_session
        from app.db.models import Document, DocumentChunk as DbDocumentChunk

        with get_db_session() as session:
            query = (
                session.query(DbDocumentChunk, Document.filename)
                .join(Document, Document.id == DbDocumentChunk.document_id)
                .order_by(DbDocumentChunk.document_id.asc(), DbDocumentChunk.chunk_index.asc())
            )
            if doc_ids:
                query = query.filter(DbDocumentChunk.document_id.in_(doc_ids))
            if limit:
                query = query.limit(limit)

            rows = []
            for db_chunk, filename in query.all():
                rows.append({
                    "document_id": int(db_chunk.document_id),
                    "chunk_index": int(db_chunk.chunk_index or 0),
                    "content": db_chunk.content,
                    "page": int(db_chunk.page_number or 0),
                    "source": filename or f"document-{db_chunk.document_id}",
                    "chroma_id": db_chunk.chroma_id
                    or _stable_chunk_id(int(db_chunk.document_id), int(db_chunk.chunk_index or 0), db_chunk.content),
                })
            return rows
    except Exception as exc:
        logger.warning("Database chunk load failed", error=str(exc))
        return []


def _db_rows_to_records(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    for row in rows:
        records.append({
            "id": row["chroma_id"],
            "document": row["content"],
            "metadata": {
                "doc_db_id": str(row["document_id"]),
                "source": row["source"],
                "page": row["page"],
                "chunk_index": row["chunk_index"],
            },
        })
    return records


def _repair_vector_store(doc_ids: Optional[List[int]] = None) -> int:
    rows = _load_db_chunk_rows(doc_ids=doc_ids)
    if not rows:
        return 0

    total = _upsert_records(_db_rows_to_records(rows))
    logger.info(
        "Vector store repaired from database",
        repaired_chunks=len(rows),
        total_chunks=total,
        doc_ids=doc_ids or [],
    )
    return len(rows)


def rebuild_vector_store(doc_ids: Optional[List[int]] = None) -> Dict[str, int]:
    collection = _get_collection()
    if doc_ids:
        for doc_id in doc_ids:
            delete_document_chunks(int(doc_id))
    else:
        existing_ids = collection.get().get("ids", [])
        if existing_ids:
            collection.delete(ids=existing_ids)
        _bm25_text_by_id.clear()
        _rebuild_bm25()

    rebuilt = _repair_vector_store(doc_ids=doc_ids)
    return {
        "reindexed_chunks": rebuilt,
        "total_chunks": collection.count(),
    }


def _collection_chunk_ids(where: Optional[Dict[str, Any]] = None) -> List[str]:
    try:
        results = _get_collection().get(where=where)
        return results.get("ids", []) or []
    except Exception as exc:
        logger.warning("Collection id lookup failed", error=str(exc))
        return []


def _fetch_chunk_info(chunk_ids: List[str]) -> Dict[str, Tuple[str, Dict[str, Any]]]:
    if not chunk_ids:
        return {}

    try:
        data = _get_collection().get(ids=chunk_ids, include=["documents", "metadatas"])
    except Exception as exc:
        logger.warning("Chunk metadata fetch failed", error=str(exc))
        return {}

    info: Dict[str, Tuple[str, Dict[str, Any]]] = {}
    ids = data.get("ids", []) or []
    docs = data.get("documents", []) or []
    metas = data.get("metadatas", []) or []
    for chunk_id, document, metadata in zip(ids, docs, metas):
        info[chunk_id] = (document, metadata or {})
    return info


def _normalize_dense_score(distance: float) -> float:
    return max(0.0, 1.0 - float(distance))


def _query_overlap_bonus(query: str, content: str, metadata: Dict[str, Any], prefer_overview: bool) -> float:
    query_tokens = set(_tokenize(query))
    if not query_tokens:
        return 0.05 if prefer_overview else 0.0

    content_tokens = set(_tokenize(content[:2000]))
    if not content_tokens:
        return 0.0

    overlap = len(query_tokens & content_tokens)
    coverage = overlap / max(1, len(query_tokens))
    bonus = coverage * 0.12
    if query.lower() in content.lower():
        bonus += 0.08
    if prefer_overview and int(metadata.get("chunk_index", 99) or 99) <= 1:
        bonus += 0.05
    return bonus


def _chunk_quality_adjustment(content: str) -> float:
    lowered = " ".join(content.lower().split())
    if "table of contents" in lowered or "list of figures" in lowered or "list of tables" in lowered:
        return -0.08
    alpha_chars = sum(ch.isalpha() for ch in content)
    if alpha_chars == 0:
        return -0.1
    uppercase_ratio = sum(ch.isupper() for ch in content if ch.isalpha()) / alpha_chars
    if uppercase_ratio > 0.55 and len(content.split()) < 80:
        return -0.05
    return 0.0


def _database_fallback_retrieve(
    query: str,
    k: int,
    doc_ids: Optional[List[int]] = None,
    prefer_overview: bool = False,
) -> List[RetrievedChunk]:
    scan_limit = max(DB_FALLBACK_SCAN_LIMIT, k * 10)
    rows = _load_db_chunk_rows(doc_ids=doc_ids, limit=scan_limit)
    if not rows:
        return []

    query_tokens = set(_tokenize(query))
    scored_rows: List[Tuple[float, Dict[str, Any]]] = []
    for row in rows:
        content = row["content"]
        content_tokens = set(_tokenize(content[:2000]))
        overlap = len(query_tokens & content_tokens)
        coverage = overlap / max(1, len(query_tokens)) if query_tokens else 0.0
        density = overlap / max(1, len(content_tokens)) if content_tokens else 0.0
        phrase_bonus = 0.08 if query.lower() in content.lower() else 0.0
        early_chunk_bonus = 0.08 if row["chunk_index"] <= 1 else 0.0
        score = coverage * 0.7 + density * 0.2 + phrase_bonus + _chunk_quality_adjustment(content)
        if prefer_overview:
            score += early_chunk_bonus
        scored_rows.append((score, row))

    scored_rows.sort(key=lambda item: (-item[0], item[1]["document_id"], item[1]["chunk_index"]))

    if not any(score > 0 for score, _ in scored_rows):
        scored_rows = [(0.05 if row["chunk_index"] <= 1 else 0.0, row) for row in rows]
        scored_rows.sort(key=lambda item: (-item[0], item[1]["document_id"], item[1]["chunk_index"]))

    retrieved: List[RetrievedChunk] = []
    seen_hashes = set()
    for score, row in scored_rows:
        if len(retrieved) >= k:
            break
        content_hash = _content_hash(row["content"])
        if content_hash in seen_hashes:
            continue
        seen_hashes.add(content_hash)
        retrieved.append(RetrievedChunk(
            content=row["content"],
            score=max(score, MIN_SCORE_THRESHOLD),
            source=row["source"],
            page=row["page"],
            doc_id=str(row["document_id"]),
        ))

    logger.info("Database fallback retrieval used", count=len(retrieved), doc_ids=doc_ids or [])
    return retrieved


def _build_context(retrieved: List[RetrievedChunk]) -> str:
    return "\n\n---\n\n".join(
        f"[Source: {chunk.source}, Page: {chunk.page}]\n{chunk.content}"
        for chunk in retrieved
    )


def retrieve(
    query: str,
    top_k: Optional[int] = None,
    doc_ids: Optional[List[int]] = None,
) -> Tuple[str, List[RetrievedChunk]]:
    k = top_k or settings.top_k_results
    candidate_k = min(k * MAX_CANDIDATE_MULTIPLIER, MAX_CANDIDATES)
    prefer_overview = _is_overview_query(query)
    collection = _get_collection()
    total = collection.count()

    if total == 0:
        _repair_vector_store(doc_ids=doc_ids)
        total = collection.count()
        if total == 0:
            fallback = _database_fallback_retrieve(query, k, doc_ids=doc_ids, prefer_overview=prefer_overview)
            return _build_context(fallback), fallback

    if doc_ids and prefer_overview:
        overview_chunks = _database_fallback_retrieve(
            query,
            k=max(k, settings.overview_chunk_count),
            doc_ids=doc_ids,
            prefer_overview=True,
        )
        if overview_chunks:
            return _build_context(overview_chunks[:k]), overview_chunks[:k]

    where = None
    allowed_chunk_ids: Optional[List[str]] = None
    if doc_ids:
        str_ids = [str(int(doc_id)) for doc_id in doc_ids]
        where = {"doc_db_id": str_ids[0]} if len(str_ids) == 1 else {"doc_db_id": {"$in": str_ids}}
        allowed_chunk_ids = _collection_chunk_ids(where)
        if not allowed_chunk_ids:
            _repair_vector_store(doc_ids=doc_ids)
            allowed_chunk_ids = _collection_chunk_ids(where)
        if not allowed_chunk_ids:
            fallback = _database_fallback_retrieve(query, k, doc_ids=doc_ids, prefer_overview=prefer_overview)
            return _build_context(fallback), fallback
        actual_k = min(candidate_k, len(allowed_chunk_ids))
    else:
        actual_k = min(candidate_k, total)

    if actual_k <= 0:
        return "", []

    try:
        q_embed = embed_query(query)
        dense_res = collection.query(
            query_embeddings=[q_embed],
            n_results=actual_k,
            where=where,
            include=["documents", "distances", "metadatas"],
        )
    except Exception as exc:
        logger.warning("Dense retrieval failed", error=str(exc))
        fallback = _database_fallback_retrieve(query, k, doc_ids=doc_ids, prefer_overview=prefer_overview)
        return _build_context(fallback), fallback

    dense_docs = dense_res.get("documents", [[]])[0] or []
    dense_dists = dense_res.get("distances", [[]])[0] or []
    dense_metas = dense_res.get("metadatas", [[]])[0] or []
    dense_ids = dense_res.get("ids", [[]])[0] or []
    dense_ranked = [(chunk_id, _normalize_dense_score(distance)) for chunk_id, distance in zip(dense_ids, dense_dists)]

    sparse_ranked: List[Tuple[str, float]] = []
    if _bm25_index and _bm25_corpus:
        try:
            bm25_scores = _bm25_index.get_scores(_tokenize(query))
            allowed_set = set(allowed_chunk_ids) if allowed_chunk_ids is not None else None
            paired = [
                (chunk_id, float(score))
                for chunk_id, score in zip(_bm25_ids, bm25_scores)
                if allowed_set is None or chunk_id in allowed_set
            ]
            paired.sort(key=lambda item: item[1], reverse=True)
            sparse_ranked = paired[:actual_k]
        except Exception as exc:
            logger.warning("BM25 retrieval failed", error=str(exc))

    alpha = _detect_query_type(query)
    fused = _rrf_fuse(dense_ranked, sparse_ranked, alpha=alpha) if sparse_ranked else dense_ranked
    id_to_info = {
        chunk_id: (document, metadata or {})
        for chunk_id, document, metadata in zip(dense_ids, dense_docs, dense_metas)
    }

    missing_ids = [chunk_id for chunk_id, _ in fused if chunk_id not in id_to_info]
    if missing_ids:
        id_to_info.update(_fetch_chunk_info(missing_ids[:actual_k]))

    rescored: List[Tuple[float, str, str, Dict[str, Any]]] = []
    for chunk_id, score in fused:
        info = id_to_info.get(chunk_id)
        if not info:
            continue
        document, metadata = info
        rescored.append((
            score + _query_overlap_bonus(query, document, metadata, prefer_overview) + _chunk_quality_adjustment(document),
            chunk_id,
            document,
            metadata,
        ))
    rescored.sort(key=lambda item: item[0], reverse=True)

    retrieved: List[RetrievedChunk] = []
    seen_hashes = set()
    for score, _, document, metadata in rescored:
        if len(retrieved) >= k:
            break
        if score < MIN_SCORE_THRESHOLD:
            continue
        document_hash = _content_hash(document)
        if document_hash in seen_hashes:
            continue
        seen_hashes.add(document_hash)
        retrieved.append(RetrievedChunk(
            content=document,
            score=score,
            source=str(metadata.get("source", "")),
            page=int(metadata.get("page", 0) or 0),
            doc_id=str(metadata.get("doc_db_id", "")),
        ))

    if not retrieved:
        retrieved = _database_fallback_retrieve(query, k, doc_ids=doc_ids, prefer_overview=prefer_overview)

    context = _build_context(retrieved)
    logger.info("Retrieved chunks", query=query[:60], count=len(retrieved), alpha=alpha)
    return context, retrieved


def get_collection_size() -> int:
    return _get_collection().count()


def restore_bm25():
    collection = _get_collection()
    data = collection.get(include=["documents"])
    documents = data.get("documents", []) or []
    ids = data.get("ids", []) or []

    if not documents:
        repaired = _repair_vector_store()
        if repaired:
            data = collection.get(include=["documents"])
            documents = data.get("documents", []) or []
            ids = data.get("ids", []) or []

    if documents:
        _bm25_text_by_id.clear()
        for chunk_id, document in zip(ids, documents):
            _bm25_text_by_id[chunk_id] = document
        _rebuild_bm25()
        logger.info("BM25 index restored", docs=len(_bm25_corpus))
