"""
Helpers for turning SQL result rows into readable summaries and chart specs.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
import math
import re
from statistics import mean
from typing import Any, Dict, List, Optional


LABEL_PREFERENCES = (
    "name", "title", "label", "department", "category", "project", "user",
    "employee", "team", "group", "type", "status", "region", "city", "country",
)
NUMERIC_ID_PATTERNS = ("id", "rank", "index", "row_num", "row_number")


def make_json_safe(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return None if math.isnan(value) or math.isinf(value) else value
    if isinstance(value, Decimal):
        try:
            return int(value) if value == value.to_integral_value() else float(value)
        except Exception:
            return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return str(value)


def _humanize(column: str) -> str:
    return column.replace("_", " ").strip()


def _question_tokens(question: str) -> set[str]:
    return set(re.findall(r"[a-z0-9_]+", question.lower()))


def _column_tokens(column: str) -> set[str]:
    return set(re.findall(r"[a-z0-9_]+", column.lower())) | set(column.lower().split("_"))


def _to_float(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, Decimal):
        return float(value)

    text = str(value).strip()
    if not text:
        return None
    text = text.replace(",", "")
    if text.endswith("%"):
        text = text[:-1]
    if text.startswith("$"):
        text = text[1:]
    try:
        return float(text)
    except ValueError:
        return None


def _is_numeric_column(rows: List[Dict[str, Any]], column: str) -> bool:
    sample = 0
    numeric = 0
    for row in rows[:12]:
        if column not in row:
            continue
        sample += 1
        if _to_float(row.get(column)) is not None:
            numeric += 1
    return sample > 0 and numeric >= max(1, math.ceil(sample * 0.7))


def classify_columns(rows: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    if not rows:
        return {"all": [], "numeric": [], "text": [], "date": []}

    columns = list(rows[0].keys())
    numeric_cols = [column for column in columns if _is_numeric_column(rows, column)]
    text_cols = [column for column in columns if column not in numeric_cols]
    date_cols = [
        column for column in columns
        if any(token in column.lower() for token in ("date", "time", "month", "year", "day", "week"))
    ]
    return {"all": columns, "numeric": numeric_cols, "text": text_cols, "date": date_cols}


def choose_metric_column(question: str, rows: List[Dict[str, Any]]) -> Optional[str]:
    columns = classify_columns(rows)
    question_tokens = _question_tokens(question)
    best_column = None
    best_score = float("-inf")

    for column in columns["numeric"]:
        score = 0.0
        lower = column.lower()
        tokens = _column_tokens(column)
        overlap = len(tokens & question_tokens)
        score += overlap * 4

        if lower in question.lower():
            score += 6
        if any(lower == pattern or lower.endswith(f"_{pattern}") for pattern in NUMERIC_ID_PATTERNS):
            score -= 5
        if any(keyword in lower for keyword in ("count", "total", "sum", "avg", "average", "budget", "salary", "amount", "score", "revenue")):
            score += 2

        if score > best_score:
            best_score = score
            best_column = column

    return best_column or (columns["numeric"][0] if columns["numeric"] else None)


def choose_label_column(question: str, rows: List[Dict[str, Any]]) -> Optional[str]:
    columns = classify_columns(rows)
    question_tokens = _question_tokens(question)
    best_column = None
    best_score = float("-inf")

    candidates = columns["text"][:] or []
    if not candidates and "all" in columns and columns["all"]:
        for column in columns["all"]:
            if any(token in column.lower() for token in LABEL_PREFERENCES):
                candidates.append(column)
        if not candidates and columns["all"]:
            candidates.append(columns["all"][0])

    for column in candidates:
        lower = column.lower()
        tokens = _column_tokens(column)
        score = len(tokens & question_tokens) * 3
        if lower in question.lower():
            score += 5
        if any(pref in lower for pref in LABEL_PREFERENCES):
            score += 4
        if lower.endswith("_id") or lower == "id":
            score -= 2
        if score > best_score:
            best_score = score
            best_column = column

    return best_column or (candidates[0] if candidates else None)


def format_value(value: Any) -> str:
    safe = make_json_safe(value)
    if safe is None:
        return "none"
    if isinstance(safe, int):
        return f"{safe:,}"
    if isinstance(safe, float):
        if safe.is_integer():
            return f"{int(safe):,}"
        return f"{safe:,.2f}"
    return str(safe)


def build_results_preview(rows: List[Dict[str, Any]], limit: int = 8) -> str:
    preview_rows = rows[:limit]
    lines = []
    for row in preview_rows:
        parts = [f"{_humanize(key)}: {format_value(value)}" for key, value in row.items()]
        lines.append(", ".join(parts))
    if len(rows) > limit:
        lines.append(f"... and {len(rows) - limit} more rows")
    return "\n".join(lines)


def answer_is_low_quality(answer: str) -> bool:
    text = (answer or "").strip()
    if len(text) < 30:
        return True
    colon_count = text.count(":")
    period_count = text.count(".")
    underscore_count = text.count("_")
    if underscore_count >= 3:
        return True
    if colon_count >= 6 and period_count <= 1:
        return True
    if text.count(",") >= 8 and period_count == 0:
        return True
    return False


def build_tabular_fallback_answer(question: str, rows: List[Dict[str, Any]]) -> str:
    if not rows:
        return "No matching rows were found for that question."

    columns = classify_columns(rows)
    metric_col = choose_metric_column(question, rows)
    label_col = choose_label_column(question, rows)
    question_lower = question.lower()

    if len(rows) == 1 and len(rows[0]) == 1:
        key, value = next(iter(rows[0].items()))
        return f"The {_humanize(key)} is {format_value(value)}."

    if metric_col:
        numeric_values = [
            _to_float(row.get(metric_col))
            for row in rows
            if _to_float(row.get(metric_col)) is not None
        ]
    else:
        numeric_values = []

    if len(rows) == 1:
        row = rows[0]
        details = []
        if label_col and row.get(label_col) is not None:
            details.append(str(row.get(label_col)))
        for key, value in list(row.items())[:4]:
            if key == label_col:
                continue
            details.append(f"{_humanize(key)} {format_value(value)}")
        return "The matching result is " + ", ".join(details) + "."

    if metric_col and label_col and numeric_values:
        first = rows[0]
        top_label = first.get(label_col)
        top_value = first.get(metric_col)
        low_value = min(numeric_values)
        high_value = max(numeric_values)
        avg_value = mean(numeric_values)

        leading = []
        for row in rows[:3]:
            label = row.get(label_col)
            value = row.get(metric_col)
            if label is None or value is None:
                continue
            leading.append(f"{label} ({format_value(value)})")

        if any(word in question_lower for word in ("top", "highest", "most", "largest", "best", "max")):
            sentence = f"{top_label} has the highest {_humanize(metric_col)} at {format_value(top_value)}."
        elif any(word in question_lower for word in ("lowest", "least", "smallest", "minimum", "min", "bottom")):
            sentence = f"{top_label} is the lowest returned result with {_humanize(metric_col)} at {format_value(top_value)}."
        else:
            sentence = f"The results are led by {top_label} with {_humanize(metric_col)} of {format_value(top_value)}."

        sentence += f" Across {len(numeric_values)} rows, {_humanize(metric_col)} ranges from {format_value(low_value)} to {format_value(high_value)} and averages {format_value(avg_value)}."
        if leading:
            sentence += f" The leading entries are {', '.join(leading)}."
        return sentence

    if metric_col and numeric_values:
        low_value = min(numeric_values)
        high_value = max(numeric_values)
        avg_value = mean(numeric_values)
        return (
            f"I found {len(rows)} rows. {_humanize(metric_col).capitalize()} ranges from "
            f"{format_value(low_value)} to {format_value(high_value)}, with an average of {format_value(avg_value)}."
        )

    if label_col:
        labels = [str(row.get(label_col)) for row in rows[:5] if row.get(label_col) is not None]
        return f"I found {len(rows)} matching rows. The leading entries are {', '.join(labels)}."

    first_row = ", ".join(f"{_humanize(key)} {format_value(value)}" for key, value in list(rows[0].items())[:4])
    return f"I found {len(rows)} matching rows. The first row is {first_row}."


def recommend_chart(question: str, rows: List[Dict[str, Any]], sql: str = "") -> Dict[str, Any]:
    if not rows:
        return {"type": "none", "data": []}

    columns = classify_columns(rows)
    all_cols = columns["all"]
    numeric_cols = columns["numeric"]
    date_cols = columns["date"]
    metric_col = choose_metric_column(question, rows)
    label_col = choose_label_column(question, rows)
    title = question.strip().rstrip("?") or "Query result"
    question_lower = question.lower()

    if len(rows) == 1 and len(all_cols) == 1:
        return {
            "type": "single_value",
            "value": make_json_safe(next(iter(rows[0].values()))),
            "label": all_cols[0],
            "title": title,
            "data": rows,
        }

    if date_cols and metric_col:
        return {"type": "line", "x_col": date_cols[0], "y_col": metric_col, "title": title, "data": rows}

    if label_col and metric_col:
        positive_values = [
            _to_float(row.get(metric_col))
            for row in rows
            if _to_float(row.get(metric_col)) is not None
        ]
        pie_like = (
            len(rows) <= 7
            and positive_values
            and all(value >= 0 for value in positive_values)
            and any(word in question_lower for word in ("share", "distribution", "breakdown", "proportion", "percent"))
        )
        if pie_like:
            return {"type": "pie", "x_col": label_col, "y_col": metric_col, "title": title, "data": rows}

        horizontal = (
            len(rows) > 5
            or max(len(str(row.get(label_col, ""))) for row in rows[:10]) > 16
            or any(word in question_lower for word in ("top", "highest", "lowest", "largest", "smallest"))
            or "order by" in sql.lower()
        )
        return {
            "type": "bar",
            "x_col": metric_col if horizontal else label_col,
            "y_col": label_col if horizontal else metric_col,
            "orientation": "h" if horizontal else "v",
            "title": title,
            "data": rows,
        }

    if len(numeric_cols) >= 2 and len(rows) <= 100:
        return {
            "type": "scatter",
            "x_col": numeric_cols[0],
            "y_col": metric_col or numeric_cols[1],
            "title": title,
            "data": rows,
        }

    return {"type": "table", "title": title, "data": rows}
