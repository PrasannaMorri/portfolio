"""
Text2SQL — OPTIMIZED with DAIL-SQL style prompt engineering.
Improvements:
  1. Dynamic schema injection from live DB (not hardcoded)
  2. Better SQL generation prompt with dialect hints
  3. SQL post-processing and formatting
  4. Natural language answer generation from results
  5. Chart type auto-recommendation
"""
from __future__ import annotations
import re
from typing import Any, List, Dict, Optional, Tuple
from sqlalchemy import text, inspect
from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.db.database import get_db_session, get_engine
from app.services.llm_service import call_llm, clean_sql_output
from app.services.tabular_presenter import (
    answer_is_low_quality,
    build_results_preview,
    build_tabular_fallback_answer,
    make_json_safe,
    recommend_chart,
)

logger = get_logger(__name__)
settings = get_settings()

# ── Schema (built dynamically or fallback to static) ──────────────────────────
_STATIC_SCHEMA = """
Table: employees
  id SERIAL PK | name VARCHAR | department VARCHAR
  salary NUMERIC | hire_date DATE | status VARCHAR (active/inactive)

Table: projects
  id SERIAL PK | name VARCHAR | department VARCHAR
  budget NUMERIC | start_date DATE | end_date DATE | status VARCHAR (active/completed)
"""

EXAMPLE_QA_PAIRS = [
    ("How many employees are there?", "SELECT COUNT(*) AS total_employees FROM employees"),
    ("List all active employees", "SELECT id, name, department, salary FROM employees WHERE status = 'active' ORDER BY name"),
    ("Average salary by department", "SELECT department, ROUND(AVG(salary), 2) AS avg_salary FROM employees GROUP BY department ORDER BY avg_salary DESC"),
    ("Show all active projects", "SELECT id, name, department, budget, start_date FROM projects WHERE status = 'active' ORDER BY start_date"),
    ("Total budget per department", "SELECT department, SUM(budget) AS total_budget FROM projects GROUP BY department ORDER BY total_budget DESC"),
    ("Top 5 highest paid employees", "SELECT name, department, salary FROM employees ORDER BY salary DESC LIMIT 5"),
    ("How many employees per department?", "SELECT department, COUNT(*) AS employee_count FROM employees GROUP BY department ORDER BY employee_count DESC"),
    ("Which projects are over budget?", "SELECT name, department, budget FROM projects WHERE budget > (SELECT AVG(budget) FROM projects) ORDER BY budget DESC"),
]

SYSTEM_SQL = """You are a PostgreSQL SQL expert. Generate ONE valid, optimized SELECT query.

STRICT RULES:
- Output ONLY the raw SQL query. No explanations. No markdown. No code fences. No comments.
- Use ONLY tables and columns from the schema below.
- Always use column aliases for clarity (e.g. COUNT(*) AS total).
- For aggregations, always include ORDER BY to make results meaningful.
- Use LIMIT 100 on queries that could return many rows.
- Prefer specific column names over SELECT *.
- Use ROUND() for decimal values.
- For date comparisons use DATE() function."""

USER_SQL = """DATABASE SCHEMA:
{schema}

EXAMPLE QUESTION-SQL PAIRS (for reference):
{examples}

USER QUESTION: {question}

SQL QUERY (SELECT only, raw SQL, no formatting):"""

ANSWER_SYSTEM = """You are a data analyst explaining SQL query results to a non-technical user.
Given a question and the query results, provide a clear, insightful natural language answer.
- Start with a direct answer to the question.
- Highlight the most important/surprising findings.
- Use specific numbers from the results.
- Keep it to 2-4 sentences.
- Do NOT mention SQL, queries, or technical terms."""

ANSWER_USER = """Question: {question}

Query results ({row_count} rows):
{results_preview}

Natural language answer:"""

FORBIDDEN = ["drop","delete","update","insert","alter","truncate","create","grant","revoke","--","/*","xp_","pg_sleep","waitfor"]
ALLOWED_TABLES = {"employees", "projects"}


def _get_live_schema() -> str:
    """Extract schema from live database, fallback to static."""
    try:
        engine = get_engine()
        inspector = inspect(engine)
        lines = []
        for table in inspector.get_table_names():
            cols = inspector.get_columns(table)
            pk_cols = {c["name"] for c in inspector.get_pk_constraint(table).get("constrained_columns", [])}
            col_descs = []
            for c in cols:
                desc = f"{c['name']} {str(c['type'])}"
                if c["name"] in pk_cols:
                    desc += " PK"
                if not c.get("nullable", True):
                    desc += " NOT NULL"
                col_descs.append(desc)
            lines.append(f"Table: {table}\n  " + "\n  ".join(col_descs))
        return "\n\n".join(lines) if lines else _STATIC_SCHEMA
    except Exception as e:
        logger.warning("Could not extract live schema, using static", error=str(e))
        return _STATIC_SCHEMA


def validate_sql(query: str) -> None:
    if not query or not query.strip():
        raise ValueError("Empty query generated")
    clean = query.strip()
    if not re.match(r"^\s*SELECT\b", clean, re.IGNORECASE):
        raise ValueError("Only SELECT queries are allowed")
    lower = clean.lower()
    for word in FORBIDDEN:
        if word in lower:
            raise ValueError(f"Forbidden operation detected: {word}")
    tables = re.findall(r"\b(?:FROM|JOIN)\s+([a-zA-Z_]\w*)", clean, re.IGNORECASE)
    unknown = set(t.lower() for t in tables) - ALLOWED_TABLES
    if unknown:
        raise ValueError(f"Unknown tables referenced: {unknown}")


def generate_sql(question: str, context: str = "") -> str:
    schema = _get_live_schema()
    examples_text = "\n\n".join(f"Q: {q}\nSQL: {s}" for q, s in EXAMPLE_QA_PAIRS)
    user_prompt = USER_SQL.format(schema=schema, examples=examples_text, question=question)

    raw = call_llm(SYSTEM_SQL, user_prompt, max_new_tokens=300)
    sql = clean_sql_output(raw)

    if not sql or not sql.upper().strip().startswith("SELECT"):
        logger.warning("LLM returned bad SQL, falling back to rule-based", raw=raw[:100])
        sql = _rule_based_sql(question)

    # Post-process: add LIMIT if missing on potentially large queries
    if "LIMIT" not in sql.upper() and any(w in sql.upper() for w in ["SELECT *", "SELECT id,"]):
        sql = sql.rstrip(";") + " LIMIT 100"

    validate_sql(sql)
    logger.info("SQL generated", sql=sql[:150])
    return sql


def _rule_based_sql(question: str) -> str:
    """Improved rule-based fallback with more patterns."""
    q = question.lower()

    if "how many" in q or "count" in q:
        if "department" in q and "employee" in q:
            return "SELECT department, COUNT(*) AS employee_count FROM employees GROUP BY department ORDER BY employee_count DESC"
        if "active" in q and "employee" in q:
            return "SELECT COUNT(*) AS active_employees FROM employees WHERE status = 'active'"
        if "employee" in q:
            return "SELECT COUNT(*) AS total_employees FROM employees"
        if "project" in q:
            return "SELECT COUNT(*) AS total_projects FROM projects"

    if "average" in q or "avg" in q:
        if "salary" in q:
            return "SELECT department, ROUND(AVG(salary), 2) AS avg_salary FROM employees GROUP BY department ORDER BY avg_salary DESC"
        if "budget" in q:
            return "SELECT department, ROUND(AVG(budget), 2) AS avg_budget FROM projects GROUP BY department"

    if "highest" in q or "top" in q or "most" in q:
        if "salary" in q or "paid" in q:
            return "SELECT name, department, salary FROM employees ORDER BY salary DESC LIMIT 10"
        if "budget" in q:
            return "SELECT name, department, budget FROM projects ORDER BY budget DESC LIMIT 10"

    if "lowest" in q or "least" in q or "minimum" in q:
        if "salary" in q:
            return "SELECT name, department, salary FROM employees ORDER BY salary ASC LIMIT 10"

    if "department" in q and "budget" in q:
        return "SELECT department, SUM(budget) AS total_budget FROM projects GROUP BY department ORDER BY total_budget DESC"

    if "active" in q and "employee" in q:
        return "SELECT id, name, department, salary FROM employees WHERE status = 'active' ORDER BY name LIMIT 50"
    if "inactive" in q and "employee" in q:
        return "SELECT id, name, department, salary FROM employees WHERE status = 'inactive' ORDER BY name LIMIT 50"

    if "active" in q and "project" in q:
        return "SELECT id, name, department, budget FROM projects WHERE status = 'active' ORDER BY budget DESC"

    if "hire" in q or "hired" in q:
        return "SELECT name, department, hire_date FROM employees ORDER BY hire_date DESC LIMIT 20"

    if "employee" in q:
        return "SELECT id, name, department, salary, status FROM employees ORDER BY name LIMIT 20"
    if "project" in q:
        return "SELECT id, name, department, budget, status FROM projects ORDER BY budget DESC LIMIT 20"

    return "SELECT id, name, department, salary FROM employees ORDER BY salary DESC LIMIT 10"


def execute_sql(query: str) -> List[Dict[str, Any]]:
    validate_sql(query)
    with get_db_session() as session:
        result = session.execute(text(query))
        columns = list(result.keys())
        rows = [
            {column: make_json_safe(value) for column, value in zip(columns, row)}
            for row in result.fetchall()
        ]
    logger.info("SQL executed", rows=len(rows))
    return rows


def generate_nl_answer(question: str, rows: List[Dict[str, Any]], sql: str) -> str:
    """Generate a natural language answer from SQL results."""
    if not rows:
        return "The query returned no results for your question."

    results_preview = build_results_preview(rows, limit=8)

    try:
        answer = call_llm(
            ANSWER_SYSTEM,
            ANSWER_USER.format(
                question=question,
                row_count=len(rows),
                results_preview=results_preview,
            ),
            max_new_tokens=200,
        )
        result = answer.strip()
        if result and not answer_is_low_quality(result):
            return result
    except Exception as e:
        logger.warning("NL answer generation failed", error=str(e))

    return build_tabular_fallback_answer(question, rows)


def recommend_chart_type(rows: List[Dict[str, Any]], sql: str) -> Optional[str]:
    """Auto-recommend chart type based on result shape."""
    chart = recommend_chart("Query result", rows, sql=sql)
    chart_type = chart.get("type")
    return chart_type if isinstance(chart_type, str) else None
