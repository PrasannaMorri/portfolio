"""
Answer generation with source citations — OPTIMIZED
Key improvements:
  1. Larger, structured context window (8000 chars)
  2. Chain-of-thought prompting for accuracy
  3. Confidence scoring and source deduplication
  4. Graceful fallback with chunk excerpts
  5. Separate prompts for factual vs analytical questions
"""
from __future__ import annotations
import re
from typing import List, Dict
from app.services.llm_service import call_llm
from app.services.rag_service_v2 import RetrievedChunk
from app.core.logging_config import get_logger

logger = get_logger(__name__)

# ── Prompts ───────────────────────────────────────────────────────────────────

QA_SYSTEM = """You are an expert document analyst and question-answering assistant.
Your job is to provide precise, well-structured answers based strictly on provided document context.

RULES:
1. Answer ONLY using the provided context — never use prior knowledge or assumptions.
2. Cite your sources using the format: [Source: <filename>, Page <N>].
3. If multiple chunks address the question, synthesize them into one coherent, complete answer.
4. If the answer requires a number, date, or proper name — quote it exactly from the context.
5. If the context does NOT contain the answer, respond with exactly:
   "The uploaded documents do not contain information about this topic."
6. Never mention internal systems (ChromaDB, embeddings, SQL, RAG).
7. Structure your answer in clear paragraphs. Use bullet points only for lists of items.
8. Keep answers between 4-8 sentences when the user asks for an explanation, summary, overview, or details."""

QA_USER = """DOCUMENT CONTEXT (ordered by relevance):
{context}

USER QUESTION: {question}

ANSWER:"""

OVERVIEW_SYSTEM = """You are an expert document analyst.
Write a concise overview using only the provided document excerpts.

RULES:
1. Start with one sentence explaining what the document is about.
2. Then give 3-5 short bullet points covering the main topics or findings.
3. Cite each sentence or bullet with [Source: <filename>, Page <N>].
4. Do not invent details that are not present in the context.
5. If the excerpts are insufficient, say so clearly."""

OVERVIEW_USER = """DOCUMENT EXCERPTS:
{context}

USER REQUEST: {question}

DOCUMENT OVERVIEW:"""

SUMMARY_SYSTEM = """You are a professional document summarizer.
Produce a well-structured, factual summary of the document content below.
Structure: Opening sentence (document type/purpose) -> Key topics -> Notable facts/figures -> Conclusion.
Keep under 200 words. Use clear, professional language."""

SUMMARY_USER = """DOCUMENT CONTENT:
{content}

SUMMARY:"""

EXTRACTION_SYSTEM = """You are an expert at extracting structured information from documents.
Extract ALL key facts and organize them clearly.
Format: use "Category: value" with bullet points.
Categories to look for: Names, Dates, Numbers/Statistics, Locations, Organizations, Key Terms, Actions/Events."""

EXTRACTION_USER = """DOCUMENT CONTENT:
{content}

EXTRACTED KEY INFORMATION:"""

FOLLOWUP_SYSTEM = """You are an intelligent assistant. Based on an answer just given about a document,
suggest 3 specific follow-up questions the user might want to ask next.
Make them specific and relevant to the actual content of the answer.
Format: Return exactly 3 questions, one per line, no numbering, no bullets."""

FOLLOWUP_USER = """Answer that was given: {answer}

Suggest 3 follow-up questions:"""

OVERVIEW_PATTERNS = (
    "summarize",
    "summary",
    "overview",
    "main points",
    "key points",
    "what does this",
    "what is this",
    "tell me about",
    "document about",
    "pdf about",
    "report about",
)


def _build_rich_context(chunks: List[RetrievedChunk], max_chars: int = 8000) -> str:
    """Build a rich context string with source labels and relevance ordering."""
    parts = []
    total = 0
    filtered_chunks = [chunk for chunk in chunks if not _is_low_signal_chunk(chunk.content)] or chunks

    for i, chunk in enumerate(filtered_chunks):
        source_label = f"[Source: {chunk.source}, Page {chunk.page}] (Relevance: {chunk.score:.2f})"
        entry = f"--- Chunk {i+1} {source_label} ---\n{chunk.content}"
        entry_len = len(entry)

        if total + entry_len > max_chars:
            if i == 0:
                entry = entry[:max_chars]
                parts.append(entry)
            break

        parts.append(entry)
        total += entry_len

    return "\n\n".join(parts)


def _split_sentences(text: str) -> List[str]:
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [part.strip() for part in parts if part.strip()]


def _is_low_signal_chunk(text: str) -> bool:
    lowered = " ".join(text.lower().split())
    if "table of contents" in lowered or "list of figures" in lowered or "list of tables" in lowered:
        return True
    if lowered.startswith("references") and len(lowered.split()) < 30:
        return True
    alpha_chars = sum(ch.isalpha() for ch in text)
    if alpha_chars == 0:
        return True
    uppercase_ratio = sum(ch.isupper() for ch in text if ch.isalpha()) / alpha_chars
    return uppercase_ratio > 0.55 and len(text.split()) < 80


def _chunk_citation(chunk: RetrievedChunk) -> str:
    return f"[Source: {chunk.source}, Page {chunk.page}]"


def _extractive_fallback(question: str, chunks: List[RetrievedChunk], max_points: int = 4) -> str:
    filtered = [chunk for chunk in chunks if not _is_low_signal_chunk(chunk.content)] or chunks
    query_tokens = set(re.findall(r"[a-z0-9]+", question.lower()))
    candidates = []

    for chunk in filtered[:4]:
        for sentence in _split_sentences(chunk.content):
            if len(sentence) < 30:
                continue
            sentence_tokens = set(re.findall(r"[a-z0-9]+", sentence.lower()))
            overlap = len(query_tokens & sentence_tokens)
            score = overlap + chunk.score * 10
            candidates.append((score, sentence, chunk))

    candidates.sort(key=lambda item: item[0], reverse=True)

    picked = []
    seen = set()
    for _, sentence, chunk in candidates:
        normalized = sentence.lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        picked.append(f"{sentence} {_chunk_citation(chunk)}")
        if len(picked) >= max_points:
            break

    if not picked:
        top = filtered[0]
        return f"{top.content[:320].strip()} {_chunk_citation(top)}"

    if _is_overview_question(question):
        bullets = "\n".join(f"- {point}" for point in picked)
        return f"This document is mainly about the topics covered in the retrieved sections.\n\n{bullets}"

    first = picked[0]
    rest = "\n".join(f"- {point}" for point in picked[1:])
    if rest:
        return f"{first}\n\nAdditional relevant details:\n{rest}"
    return first


def _answer_is_weak(answer: str, question: str) -> bool:
    text = (answer or "").strip()
    if len(text) < 40:
        return True
    if "[Source:" not in text:
        return True
    if _is_overview_question(question) and len(text.split()) < 35:
        return True
    return False


def _is_overview_question(question: str) -> bool:
    lowered = " ".join(question.lower().split())
    if any(pattern in lowered for pattern in OVERVIEW_PATTERNS):
        return True
    tokens = [token for token in lowered.replace("?", " ").split() if token not in {"what", "does", "tell", "me", "about", "the", "this", "that"}]
    return len(tokens) <= 2 and any(word in lowered for word in ("pdf", "doc", "document", "file", "report"))


def generate_answer(question: str, context: str, chunks: List[RetrievedChunk]) -> str:
    """Generate an accurate, cited answer using extended context."""
    if not context or not chunks:
        return "No documents are available. Please upload documents first, then ask your question."

    try:
        rich_context = _build_rich_context(chunks, max_chars=8000)
        is_overview = _is_overview_question(question)
        answer = call_llm(
            OVERVIEW_SYSTEM if is_overview else QA_SYSTEM,
            (OVERVIEW_USER if is_overview else QA_USER).format(context=rich_context, question=question),
            max_new_tokens=650 if is_overview else 700,
        )
        result = answer.strip()

        if _answer_is_weak(result, question):
            return _fallback_answer(question, chunks)

        return result

    except Exception as e:
        logger.warning("Answer generation failed", error=str(e))
        return _fallback_answer(question, chunks)


def _fallback_answer(question: str, chunks: List[RetrievedChunk]) -> str:
    """Construct a detailed, cited answer when the LLM fails or responds weakly."""
    if not chunks:
        return "Could not generate an answer. Please try rephrasing your question."
    return _extractive_fallback(question, chunks)


def generate_summary(content: str) -> str:
    """Generate a structured document summary."""
    try:
        summary = call_llm(
            SUMMARY_SYSTEM,
            SUMMARY_USER.format(content=content[:5000]),
            max_new_tokens=400,
        )
        result = summary.strip()
        if not result:
            words = content.split()
            return " ".join(words[:100]) + "..." if len(words) > 100 else content
        return result
    except Exception as e:
        logger.warning("Summary generation failed", error=str(e))
        words = content.split()
        return " ".join(words[:100]) + "..." if len(words) > 100 else content


def extract_key_info(content: str) -> str:
    """Extract structured key information from document content."""
    try:
        info = call_llm(
            EXTRACTION_SYSTEM,
            EXTRACTION_USER.format(content=content[:5000]),
            max_new_tokens=400,
        )
        return info.strip()
    except Exception as e:
        logger.warning("Extraction failed", error=str(e))
        return "Could not extract key information from the document."


def generate_followup_questions(answer: str) -> List[str]:
    """Generate contextual follow-up questions based on an answer."""
    try:
        result = call_llm(
            FOLLOWUP_SYSTEM,
            FOLLOWUP_USER.format(answer=answer[:1500]),
            max_new_tokens=200,
        )
        questions = [q.strip() for q in result.strip().split("\n") if q.strip() and "?" in q]
        return questions[:3]
    except Exception as e:
        logger.warning("Follow-up question generation failed", error=str(e))
        return []


def get_unique_sources(chunks: List[RetrievedChunk]) -> List[Dict]:
    """Return deduplicated list of sources with page numbers."""
    seen = {}
    for chunk in chunks:
        key = chunk.source
        if key not in seen:
            seen[key] = {"source": chunk.source, "pages": set(), "score": chunk.score}
        seen[key]["pages"].add(chunk.page)

    result = []
    for src_info in seen.values():
        pages = sorted(src_info["pages"])
        result.append({
            "source": src_info["source"],
            "pages": pages,
            "score": round(src_info["score"], 3),
        })
    return sorted(result, key=lambda x: x["score"], reverse=True)
