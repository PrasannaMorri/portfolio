"""
Shared LLM service.
Supports local HuggingFace inference plus OpenAI-compatible providers such as
OpenAI and Groq.
"""
from __future__ import annotations

import re
from typing import Dict, Tuple

from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import get_settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)
settings = get_settings()

_hf_pipeline = None
_remote_clients: Dict[Tuple[str, str], object] = {}


def _get_hf_pipeline():
    global _hf_pipeline
    if _hf_pipeline is None:
        from transformers import pipeline

        model = settings.hf_model_name
        device = 0 if settings.hf_device == "cuda" else -1
        is_seq2seq = any(x in model.lower() for x in ["t5", "bart", "flan"])
        task = "text2text-generation" if is_seq2seq else "text-generation"
        logger.info("Loading HuggingFace model", model=model, task=task)
        _hf_pipeline = pipeline(task=task, model=model, device=device, trust_remote_code=True)
        logger.info("Model loaded successfully")
    return _hf_pipeline


def _get_remote_client(api_key: str, base_url: str = ""):
    if not api_key:
        raise ValueError("LLM backend is configured for a remote provider, but the API key is missing.")

    cache_key = (api_key, base_url or "")
    client = _remote_clients.get(cache_key)
    if client is not None:
        return client

    from openai import OpenAI

    kwargs = {
        "api_key": api_key,
        "timeout": settings.llm_request_timeout_seconds,
    }
    if base_url:
        kwargs["base_url"] = base_url

    client = OpenAI(**kwargs)
    _remote_clients[cache_key] = client
    return client


def _remote_backend_config(backend: str) -> Tuple[object, str, float]:
    if backend == "openai":
        return (
            _get_remote_client(settings.openai_api_key, settings.openai_base_url),
            settings.openai_model,
            settings.openai_temperature,
        )

    if backend == "groq":
        return (
            _get_remote_client(settings.groq_api_key, settings.groq_base_url),
            settings.groq_model,
            max(settings.groq_temperature, 0.0001),
        )

    raise ValueError(f"Unsupported remote backend: {backend}")


def _coerce_message_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(item.get("text", ""))
        return "\n".join(part for part in parts if part).strip()
    return str(content or "")


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
def call_llm(system_prompt: str, user_prompt: str, max_new_tokens: int = None) -> str:
    backend = settings.llm_backend.lower().strip()
    tokens = max_new_tokens or settings.hf_max_new_tokens

    if backend in {"openai", "groq"}:
        client, model, temperature = _remote_backend_config(backend)
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
            max_tokens=tokens,
        )
        message = response.choices[0].message.content if response.choices else ""
        return _coerce_message_text(message).strip()

    if backend != "huggingface":
        raise ValueError(f"Unsupported llm_backend: {settings.llm_backend}")

    pipe = _get_hf_pipeline()
    combined = f"{system_prompt}\n\n{user_prompt}"
    result = pipe(
        combined,
        max_new_tokens=tokens,
        temperature=settings.hf_temperature,
        do_sample=settings.hf_temperature > 0,
        clean_up_tokenization_spaces=True,
    )
    if isinstance(result, list) and result:
        text = result[0].get("generated_text", "") or result[0].get("text", "")
    else:
        text = str(result)

    if text.startswith(combined):
        text = text[len(combined):]
    return text.strip()


def clean_sql_output(raw: str) -> str:
    raw = re.sub(r"```(?:sql)?", "", raw, flags=re.IGNORECASE).strip("` \n")
    raw = raw.split(";")[0].strip()
    return raw
