from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi import Request

from app.api.routes import router
from app.core.config import get_settings
from app.core.logging_config import setup_logging, get_logger
from app.db.database import engine
from app.db.seed import seed
from app.services.rag_service_v2 import restore_bm25

setup_logging()
logger = get_logger(__name__)
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting RAG System", env=settings.app_env)
    try:
        seed()
    except Exception as e:
        logger.warning("Seed skipped", error=str(e))
    try:
        restore_bm25()
    except Exception as e:
        logger.warning("BM25 restore skipped", error=str(e))
    logger.info("RAG System ready")
    yield
    engine.dispose()
    logger.info("Shutdown complete")


app = FastAPI(
    title="General Purpose RAG System",
    description=(
        "Upload any document (PDF, CSV, TXT, DOCX) and ask questions in plain English.\n\n"
        "**Default users:** `admin/admin123` · `user/user123`\n\n"
        "Authenticate at `/auth/token` then click the Authorize button."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception", path=request.url.path, error=str(exc))
    return JSONResponse(status_code=500, content={"detail": "An unexpected error occurred."})


app.include_router(router)

# Register DB Chat routes
from app.api.db_chat_routes import router as db_chat_router
app.include_router(db_chat_router)
