"""
Run this script from inside the text_to_sql_project directory:
  python patch_files.py

It patches 3 files in-place to fix:
1. "object of type 'int' has no len()" in RAG query
2. Missing /db-chat/schema-summary route (404)
3. Improve DB schema display (columns + rows per table)
"""
import os, sys, shutil

BASE = os.path.dirname(os.path.abspath(__file__))

def write(rel_path, content):
    full = os.path.join(BASE, rel_path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    # backup
    if os.path.exists(full):
        shutil.copy2(full, full + ".bak")
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"  ✅ Patched: {rel_path}")

# ─────────────────────────────────────────────────────────────────────────────
RAG_SERVICE = '''"""
Hybrid RAG service:
  Dense  : ChromaDB + SentenceTransformers (cosine similarity)
  Sparse : BM25 (keyword matching)
  Fusion : Reciprocal Rank Fusion (RRF)
"""
from __future__ import annotations
import uuid
from typing import List, Tuple, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings
from rank_bm25 import BM25Okapi

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.services.document_service import DocumentChunk
from app.services.embedding_service import embed_texts, embed_query

logger = get_logger(__name__)
settings = get_settings()

RRF_K = 60

_chroma_client = None
_collection = None
_bm25_corpus: List[str] = []
_bm25_ids: List[str] = []
_bm25_index: Optional[BM25Okapi] = None


def _get_collection():
    global _chroma_client, _collection
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(
            path=settings.chroma_persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        _collection = _chroma_client.get_or_create_collection(
            name="rag_documents",
            metadata={"hnsw:space": "cosine"},
        )
        logger.info("ChromaDB initialised", path=settings.chroma_persist_dir)
    return _collection


def _tokenize(text: str) -> List[str]:
    return text.lower().split()


def _rebuild_bm25():
    global _bm25_index
    if _bm25_corpus:
        _bm25_index = BM25Okapi([_tokenize(d) for d in _bm25_corpus])


def _rrf_fuse(
    dense: List[Tuple[str, float]],
    sparse: List[Tuple[str, float]],
    alpha: float,
) -> List[Tuple[str, float]]:
    scores: Dict[str, float] = {}
    for rank, (doc_id, _) in enumerate(dense):
        scores[doc_id] = scores.get(doc_id, 0) + alpha * (1 / (RRF_K + rank + 1))
    for rank, (doc_id, _) in enumerate(sparse):
        scores[doc_id] = scores.get(doc_id, 0) + (1 - alpha) * (1 / (RRF_K + rank + 1))
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def ingest_chunks(chunks: List[DocumentChunk], doc_id: int) -> int:
    collection = _get_collection()
    global _bm25_corpus, _bm25_ids

    texts = [c.content for c in chunks]
    ids   = [c.id for c in chunks]

    # ChromaDB metadata: all values must be str | int | float | bool — NO None
    metadatas = []
    for c in chunks:
        meta: Dict[str, Any] = {"doc_db_id": str(doc_id)}
        for k, v in c.metadata.items():
            if v is None:
                meta[k] = ""
            elif isinstance(v, (str, int, float, bool)):
                meta[k] = v
            else:
                meta[k] = str(v)
        metadatas.append(meta)

    embeddings = embed_texts(texts)
    collection.add(ids=ids, documents=texts, embeddings=embeddings, metadatas=metadatas)

    _bm25_corpus.extend(texts)
    _bm25_ids.extend(ids)
    _rebuild_bm25()

    total = collection.count()
    logger.info("Chunks ingested", new=len(chunks), total=total)
    return total


def delete_document_chunks(doc_id: int):
    collection = _get_collection()
    global _bm25_corpus, _bm25_ids
    try:
        results = collection.get(where={"doc_db_id": str(doc_id)})
        if results["ids"]:
            collection.delete(ids=results["ids"])
            del_set = set(results["ids"])
            new_corpus, new_ids = [], []
            for txt, cid in zip(_bm25_corpus, _bm25_ids):
                if cid not in del_set:
                    new_corpus.append(txt)
                    new_ids.append(cid)
            _bm25_corpus, _bm25_ids = new_corpus, new_ids
            _rebuild_bm25()
            logger.info("Deleted chunks for document", doc_id=doc_id, count=len(results["ids"]))
    except Exception as e:
        logger.warning("Delete chunks failed", error=str(e))


class RetrievedChunk:
    def __init__(self, content: str, score: float, source: str, page: int = 0, doc_id: str = ""):
        self.content = content
        self.score   = round(score, 4)
        self.source  = source
        self.page    = page
        self.doc_id  = doc_id


def retrieve(
    query: str,
    top_k: Optional[int] = None,
    doc_ids: Optional[List[int]] = None,
) -> Tuple[str, List[RetrievedChunk]]:
    k          = top_k or settings.top_k_results
    collection = _get_collection()
    total      = collection.count()

    if total == 0:
        return "", []

    # Build ChromaDB where filter safely
    where: Optional[Dict] = None
    if doc_ids and len(doc_ids) > 0:
        str_ids = [str(int(d)) for d in doc_ids]
        where   = {"doc_db_id": str_ids[0]} if len(str_ids) == 1 else {"doc_db_id": {"$in": str_ids}}

    # Count how many docs match the filter to avoid n_results > available
    try:
        if where is not None:
            matched_ids = collection.get(where=where, include=[])["ids"]
            available   = len(matched_ids) if isinstance(matched_ids, list) else 0
        else:
            available = total
    except Exception:
        available = total

    if available == 0:
        return "", []

    actual_k = max(1, min(k, available))

    # ── Dense retrieval ───────────────────────────────────────────────────────
    try:
        q_embed   = embed_query(query)
        dense_res = collection.query(
            query_embeddings=[q_embed],
            n_results=actual_k,
            where=where,
            include=["documents", "distances", "metadatas"],
        )
        dense_docs  = dense_res["documents"][0]
        dense_dists = dense_res["distances"][0]
        dense_metas = dense_res["metadatas"][0]
        dense_ids   = dense_res["ids"][0]
    except Exception as e:
        logger.warning("Dense retrieval failed", error=str(e))
        return "", []

    dense_ranked = [(cid, 1 - dist) for cid, dist in zip(dense_ids, dense_dists)]

    # ── Sparse retrieval (BM25) ───────────────────────────────────────────────
    sparse_ranked: List[Tuple[str, float]] = []
    if _bm25_index and _bm25_corpus:
        try:
            bm25_scores = _bm25_index.get_scores(_tokenize(query))
            allowed     = set(dense_ids) if where is not None else None
            paired = [
                (cid, score)
                for cid, score in zip(_bm25_ids, bm25_scores)
                if allowed is None or cid in allowed
            ]
            paired.sort(key=lambda x: x[1], reverse=True)
            sparse_ranked = paired[:actual_k]
        except Exception as e:
            logger.warning("BM25 retrieval failed", error=str(e))

    # ── Fuse ──────────────────────────────────────────────────────────────────
    fused = _rrf_fuse(dense_ranked, sparse_ranked, alpha=settings.hybrid_alpha) if sparse_ranked else dense_ranked

    # ── Build result ──────────────────────────────────────────────────────────
    id_to_info = {
        cid: (doc, meta)
        for cid, doc, meta in zip(dense_ids, dense_docs, dense_metas)
    }

    retrieved: List[RetrievedChunk] = []
    for cid, score in fused[:k]:
        if cid in id_to_info:
            doc, meta = id_to_info[cid]
            retrieved.append(RetrievedChunk(
                content=doc,
                score=score,
                source=str(meta.get("source", "")),
                page=int(meta.get("page", 0)),
                doc_id=str(meta.get("doc_db_id", "")),
            ))

    context = "\\n\\n---\\n\\n".join(
        f"[Source: {r.source}, Page: {r.page}]\\n{r.content}"
        for r in retrieved
    )
    logger.info("Retrieved chunks", query=query[:60], count=len(retrieved))
    return context, retrieved


def get_collection_size() -> int:
    return _get_collection().count()


def restore_bm25():
    global _bm25_corpus, _bm25_ids
    collection = _get_collection()
    data = collection.get(include=["documents"])
    if data["documents"]:
        _bm25_corpus = data["documents"]
        _bm25_ids    = data["ids"]
        _rebuild_bm25()
        logger.info("BM25 index restored", docs=len(_bm25_corpus))
'''

# ─────────────────────────────────────────────────────────────────────────────
ANSWER_SERVICE = '''"""
Answer generation with source citations.
Uses retrieved chunks as grounding context.
"""
from __future__ import annotations
from typing import List
from app.services.llm_service import call_llm
from app.services.rag_service_v2 import RetrievedChunk
from app.core.logging_config import get_logger

logger = get_logger(__name__)

QA_SYSTEM = """You are a precise and helpful document assistant.
Answer the user\'s question using ONLY the provided context from the uploaded documents.

Rules:
- Give a clear, complete answer (3-6 sentences) based strictly on the context
- Always cite which document/source and page number the answer comes from
- If multiple sources mention the topic, synthesize them into one coherent answer
- If the answer is not in the context, say exactly: "I could not find this information in the uploaded documents."
- Do NOT make up information or use outside knowledge
- Do NOT mention SQL, databases, ChromaDB, or any technical internals"""

QA_USER = """Context from uploaded documents:
{context}

User\'s question: {question}

Answer (be specific, cite sources like \\"According to [filename], page X...\\"):"""

SUMMARY_SYSTEM = """You are a professional document summarizer.
Create a clear, structured summary of the provided document content.
Include: main topics, key facts, important figures/dates if present.
Keep it under 200 words."""

SUMMARY_USER = """Document content:
{content}

Summary:"""

EXTRACTION_SYSTEM = """You are an information extraction expert.
Extract key structured information from the document.
Format as bullet points: • Key: Value
Extract: names, dates, numbers, locations, important terms."""

EXTRACTION_USER = """Document content:
{content}

Key information:"""


def generate_answer(question: str, context: str, chunks: List[RetrievedChunk]) -> str:
    if not context or not chunks:
        return "No documents found. Please upload documents first, then ask your question."
    try:
        trimmed_context = context[:4000] if len(context) > 4000 else context
        answer = call_llm(
            QA_SYSTEM,
            QA_USER.format(context=trimmed_context, question=question),
            max_new_tokens=400,
        )
        result = answer.strip()
        return result if result else f"Based on the documents: {chunks[0].content[:300]}..."
    except Exception as e:
        logger.warning("Answer generation failed", error=str(e))
        if chunks:
            return f"Based on the documents: {chunks[0].content[:300]}..."
        return "Could not generate answer."


def generate_summary(content: str) -> str:
    try:
        summary = call_llm(SUMMARY_SYSTEM, SUMMARY_USER.format(content=content[:3000]), max_new_tokens=300)
        return summary.strip()
    except Exception as e:
        logger.warning("Summary generation failed", error=str(e))
        words = content.split()
        return " ".join(words[:100]) + "..." if len(words) > 100 else content


def extract_key_info(content: str) -> str:
    try:
        info = call_llm(EXTRACTION_SYSTEM, EXTRACTION_USER.format(content=content[:3000]), max_new_tokens=250)
        return info.strip()
    except Exception as e:
        logger.warning("Extraction failed", error=str(e))
        return "Could not extract key information."
'''

# ─────────────────────────────────────────────────────────────────────────────
DB_CHAT_ROUTES = open(os.path.join(BASE, "app/api/db_chat_routes.py")).read()

# Inject schema-summary route if missing
if "/schema-summary" not in DB_CHAT_ROUTES:
    inject = """

@router.get("/schema-summary")
async def get_schema_summary_route(current_user: dict = Depends(get_current_user)):
    \"\"\"Get human-readable schema summary: tables, columns, rows per table.\"\"\"
    from app.services.database_chat_service import get_schema_summary, is_connected
    session_id = _session_id(current_user)
    if not is_connected(session_id):
        raise HTTPException(status_code=400, detail="No database connected.")
    summary = get_schema_summary(session_id)
    return {"summary": summary}

"""
    # Insert before the /query route
    DB_CHAT_ROUTES = DB_CHAT_ROUTES.replace(
        '@router.post("/query"',
        inject + '@router.post("/query"'
    )
    print("  ✅ Injected /schema-summary route into db_chat_routes.py")
else:
    print("  ℹ️  /schema-summary already present in db_chat_routes.py")

# Also patch get_schema to return total_columns and total_rows
if "total_columns" not in DB_CHAT_ROUTES:
    OLD = '''    return {
        "database": conn["database"],
        "db_type": conn["db_type"],
        "schema": conn["schema"],
        "table_count": len(conn["schema"]),
        "tables": list(conn["schema"].keys()),
    }'''
    NEW = '''    schema = conn["schema"]
    total_cols = sum(len(t.get("columns", [])) for t in schema.values())
    total_rows = sum(t.get("row_count", 0) for t in schema.values())
    return {
        "database": conn["database"],
        "db_type": conn["db_type"],
        "schema": schema,
        "table_count": len(schema),
        "total_columns": total_cols,
        "total_rows": total_rows,
        "tables": list(schema.keys()),
    }'''
    DB_CHAT_ROUTES = DB_CHAT_ROUTES.replace(OLD, NEW)

# Patch /status to return total_columns and total_rows
if "total_columns" not in DB_CHAT_ROUTES or DB_CHAT_ROUTES.count("total_columns") < 2:
    OLD2 = '''    return {
        "connected": True,
        "database": conn["database"],
        "db_type": conn["db_type"],
        "table_count": len(conn["schema"]),
        "tables": list(conn["schema"].keys()),
    }'''
    NEW2 = '''    schema = conn["schema"]
    total_cols = sum(len(t.get("columns", [])) for t in schema.values())
    total_rows = sum(t.get("row_count", 0) for t in schema.values())
    return {
        "connected": True,
        "database": conn["database"],
        "db_type": conn["db_type"],
        "table_count": len(schema),
        "total_columns": total_cols,
        "total_rows": total_rows,
        "tables": list(schema.keys()),
    }'''
    DB_CHAT_ROUTES = DB_CHAT_ROUTES.replace(OLD2, NEW2)

# ─────────────────────────────────────────────────────────────────────────────
DB_CHAT_SERVICE = open(os.path.join(BASE, "app/services/database_chat_service.py")).read()

# Inject get_schema_summary if missing
if "def get_schema_summary" not in DB_CHAT_SERVICE:
    SUMMARY_FN = '''

def get_schema_summary(session_id: str) -> str:
    """Return human-readable schema: tables, columns per table, rows per table."""
    conn = get_connection(session_id)
    if not conn:
        return "No database connected."
    schema = conn["schema"]
    if not schema:
        return "No tables found."

    total_tables = len(schema)
    total_cols   = sum(len(t.get("columns", [])) for t in schema.values())
    total_rows   = sum(t.get("row_count", 0) for t in schema.values())

    lines = [
        f"Database: {conn[\'database\']} ({conn[\'db_type\'].upper()})",
        f"Overview: {total_tables} tables · {total_cols} total columns · {total_rows:,} total rows",
        "",
    ]
    for tname, tinfo in schema.items():
        n_cols   = len(tinfo.get("columns", []))
        n_rows   = tinfo.get("row_count", 0)
        col_list = ", ".join(c["name"] for c in tinfo.get("columns", []))
        lines.append(f"• {tname}: {n_rows:,} rows × {n_cols} columns")
        lines.append(f"  Columns: {col_list}")
        fks = tinfo.get("foreign_keys", [])
        for fk in fks:
            lines.append(f"  FK: {fk[\'columns\']} → {fk[\'ref_table\']}.{fk[\'ref_columns\']}")
    return "\\n".join(lines)

'''
    # Insert after disconnect_database
    DB_CHAT_SERVICE = DB_CHAT_SERVICE.replace(
        "def get_connection(",
        SUMMARY_FN + "def get_connection("
    )
    print("  ✅ Injected get_schema_summary() into database_chat_service.py")

# Patch generate_nl_answer to be more informative
OLD_NL = '''    if len(rows) == 1 and len(rows[0]) == 1:
        val = list(rows[0].values())[0]
        key = list(rows[0].keys())[0]
        data_str = f"{key} = {val}"
    elif len(rows) <= 10:
        data_str = "\\n".join(
            ", ".join(f"{k}: {v}" for k, v in row.items()) for row in rows
        )
    else:
        data_str = "\\n".join(
            ", ".join(f"{k}: {v}" for k, v in row.items()) for row in rows[:5]
        )
        data_str += f"\\n... ({len(rows)} total rows)"'''
NEW_NL = '''    if len(rows) == 1 and len(rows[0]) == 1:
        val = list(rows[0].values())[0]
        key = list(rows[0].keys())[0]
        data_str = f"{key} = {val}"
    elif len(rows) <= 15:
        data_str = "\\n".join(
            ", ".join(f"{k}: {v}" for k, v in row.items()) for row in rows
        )
    else:
        data_str = "\\n".join(
            ", ".join(f"{k}: {v}" for k, v in row.items()) for row in rows[:8]
        )
        data_str += f"\\n... ({len(rows)} total rows)"'''
DB_CHAT_SERVICE = DB_CHAT_SERVICE.replace(OLD_NL, NEW_NL)

# ─────────────────────────────────────────────────────────────────────────────
print("\\nPatching files...")
write("app/services/rag_service.py",          RAG_SERVICE)
write("app/services/answer_service.py",       ANSWER_SERVICE)
write("app/api/db_chat_routes.py",            DB_CHAT_ROUTES)
write("app/services/database_chat_service.py", DB_CHAT_SERVICE)

print("""
✅ All patches applied!

Next steps:
  1. Restart your FastAPI server:   uvicorn app.main:app --reload
  2. Restart your Streamlit app:    streamlit run frontend/app.py
  3. Re-upload your documents (the ChromaDB store may need re-indexing
     if the metadata was corrupt from the old bug)
""")
