from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from app.core.config import get_settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)
settings = get_settings()


def _build_engine():
    url = settings.database_url
    is_sqlite = url.startswith("sqlite")
    if is_sqlite:
        engine = create_engine(
            url,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
    else:
        engine = create_engine(
            url,
            pool_size=10,
            max_overflow=20,
            pool_pre_ping=True,
            pool_recycle=3600,
            connect_args={"connect_timeout": 10, "application_name": "rag_system"},
        )
    safe_url = url.split("@")[-1] if "@" in url else url
    logger.info("Database engine created", url=safe_url)
    return engine


engine = _build_engine()
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


@contextmanager
def get_db_session():
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def check_db_connection():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        logger.error("DB connection failed", error=str(e))
        return False

def get_engine():
    """Return the SQLAlchemy engine (creates it if not yet created)."""
    from sqlalchemy import create_engine as _create_engine
    from app.core.config import get_settings
    settings = get_settings()
    return _create_engine(settings.database_url, pool_pre_ping=True)
