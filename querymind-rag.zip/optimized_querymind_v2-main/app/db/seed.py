"""Create tables and seed sample SQL data. Run: python -m app.db.seed"""
from sqlalchemy import text
from app.db.database import engine, Base
from app.db.models import Document, DocumentChunk, QueryHistory
from app.core.logging_config import get_logger, setup_logging

setup_logging()
logger = get_logger(__name__)

SAMPLE_DATA = """
CREATE TABLE IF NOT EXISTS employees (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    department  VARCHAR(100),
    salary      NUMERIC(10,2),
    hire_date   DATE,
    status      VARCHAR(20) DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS projects (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    department  VARCHAR(100),
    budget      NUMERIC(12,2),
    start_date  DATE,
    end_date    DATE,
    status      VARCHAR(20) DEFAULT 'active'
);

INSERT INTO employees (name, department, salary, hire_date, status) VALUES
  ('Alice Johnson',  'Engineering',  95000, '2020-03-15', 'active'),
  ('Bob Smith',      'Marketing',    72000, '2019-07-01', 'active'),
  ('Carol White',    'Engineering',  88000, '2021-01-10', 'active'),
  ('David Brown',    'HR',           65000, '2018-05-20', 'active'),
  ('Eve Davis',      'Engineering', 102000, '2017-11-30', 'active'),
  ('Frank Miller',   'Marketing',    78000, '2022-02-14', 'active'),
  ('Grace Wilson',   'Finance',      91000, '2020-09-05', 'active'),
  ('Henry Moore',    'Engineering',  97000, '2019-04-22', 'inactive'),
  ('Iris Taylor',    'HR',           61000, '2023-01-15', 'active'),
  ('Jack Anderson',  'Finance',      85000, '2021-08-30', 'active')
ON CONFLICT DO NOTHING;

INSERT INTO projects (name, department, budget, start_date, end_date, status) VALUES
  ('AI Platform',       'Engineering', 500000, '2024-01-01', '2024-12-31', 'active'),
  ('Brand Refresh',     'Marketing',   120000, '2024-03-01', '2024-06-30', 'completed'),
  ('HR Portal',         'HR',           80000, '2024-02-01', '2024-08-31', 'active'),
  ('Finance Dashboard', 'Finance',     200000, '2024-01-15', '2024-09-30', 'active'),
  ('Mobile App',        'Engineering', 350000, '2024-04-01', '2025-03-31', 'active')
ON CONFLICT DO NOTHING;
"""


def seed():
    Base.metadata.create_all(bind=engine)
    with engine.connect() as conn:
        conn.execute(text(SAMPLE_DATA))
        conn.commit()
    logger.info("Database tables created and seeded successfully")


if __name__ == "__main__":
    seed()
