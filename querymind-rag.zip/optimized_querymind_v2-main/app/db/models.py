from sqlalchemy import Column, Integer, String, Text, DateTime, Float, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.database import Base


class Document(Base):
    __tablename__ = "documents"
    id          = Column(Integer, primary_key=True, index=True)
    filename    = Column(String(255), nullable=False)
    file_type   = Column(String(20), nullable=False)   # pdf, csv, txt, docx
    file_size   = Column(Integer)
    file_path   = Column(String(500))
    status      = Column(String(20), default="processing")  # processing, ready, failed
    chunk_count = Column(Integer, default=0)
    summary     = Column(Text)
    uploaded_by = Column(String(100))
    created_at  = Column(DateTime, default=datetime.utcnow)
    chunks      = relationship("DocumentChunk", back_populates="document", cascade="all, delete")


class DocumentChunk(Base):
    __tablename__ = "document_chunks"
    id          = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content     = Column(Text, nullable=False)
    page_number = Column(Integer)
    chroma_id   = Column(String(100))
    document    = relationship("Document", back_populates="chunks")


class QueryHistory(Base):
    __tablename__ = "query_history"
    id           = Column(Integer, primary_key=True, index=True)
    question     = Column(Text, nullable=False)
    answer       = Column(Text)
    query_type   = Column(String(20))   # rag, sql, summary
    sql_query    = Column(Text)
    doc_ids      = Column(String(500))
    latency_ms   = Column(Float)
    username     = Column(String(100))
    created_at   = Column(DateTime, default=datetime.utcnow)
