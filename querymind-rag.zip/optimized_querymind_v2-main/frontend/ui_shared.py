from __future__ import annotations

import html
from datetime import datetime
from typing import Iterable, Mapping

import streamlit as st


ACCENT_PALETTE = [
    "#73A6FF",
    "#48D4C4",
    "#9CB8FF",
    "#F0B46D",
    "#5EC4FF",
    "#A7F3D0",
    "#C8D5FF",
]

PLOTLY_THEME = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(7, 17, 31, 0.0)",
    font=dict(family="IBM Plex Sans", color="#DCE8FF", size=12),
    colorway=ACCENT_PALETTE,
    margin=dict(l=32, r=24, t=56, b=32),
    legend=dict(
        bgcolor="rgba(7, 17, 31, 0.0)",
        bordercolor="rgba(148, 163, 184, 0.18)",
        borderwidth=0,
        font=dict(color="#B7C7E4", size=11),
    ),
    title_font=dict(size=16, color="#F6FAFF"),
)


def escape_text(value: object) -> str:
    return html.escape("" if value is None else str(value))


def inject_styles() -> None:
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');

        :root {
            --qm-bg: #050d18;
            --qm-bg-elevated: rgba(8, 19, 35, 0.82);
            --qm-bg-muted: rgba(10, 24, 42, 0.68);
            --qm-border: rgba(156, 184, 255, 0.18);
            --qm-border-strong: rgba(115, 166, 255, 0.32);
            --qm-text: #EEF5FF;
            --qm-text-soft: #B5C6E2;
            --qm-text-muted: #7E95B7;
            --qm-accent: #73A6FF;
            --qm-accent-2: #48D4C4;
            --qm-warm: #F0B46D;
            --qm-success: #7BE0AF;
            --qm-danger: #FF8E8E;
            --qm-shadow: 0 22px 60px rgba(2, 8, 18, 0.42);
            --qm-radius: 18px;
        }

        html, body, [class*="css"] {
            font-family: 'IBM Plex Sans', sans-serif;
        }

        body {
            background: var(--qm-bg);
            color: var(--qm-text);
        }

        .stApp {
            background:
                radial-gradient(circle at top left, rgba(115, 166, 255, 0.16), transparent 28%),
                radial-gradient(circle at top right, rgba(72, 212, 196, 0.12), transparent 24%),
                linear-gradient(180deg, #08111d 0%, #060d18 44%, #040913 100%);
        }

        .block-container {
            padding-top: 2.2rem;
            padding-bottom: 3rem;
            max-width: 1320px;
        }

        section[data-testid="stSidebar"] {
            background:
                radial-gradient(circle at top, rgba(115, 166, 255, 0.08), transparent 32%),
                linear-gradient(180deg, rgba(6, 15, 28, 0.98) 0%, rgba(4, 10, 20, 0.98) 100%);
            border-right: 1px solid var(--qm-border);
        }

        section[data-testid="stSidebar"] .block-container {
            padding-top: 1.25rem;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Space Grotesk', sans-serif !important;
            color: var(--qm-text) !important;
            letter-spacing: -0.03em;
        }

        p, label, span, div {
            color: inherit;
        }

        a {
            color: var(--qm-accent);
        }

        hr {
            border-color: rgba(156, 184, 255, 0.1) !important;
            margin: 1.35rem 0 !important;
        }

        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(156, 184, 255, 0.22);
            border-radius: 999px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        .qm-brand {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 0 0 18px;
            margin-bottom: 10px;
            border-bottom: 1px solid rgba(156, 184, 255, 0.12);
        }

        .qm-brand-mark {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            display: grid;
            place-items: center;
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            font-size: 20px;
            color: #04101E;
            background: linear-gradient(135deg, var(--qm-accent) 0%, var(--qm-accent-2) 100%);
            box-shadow: 0 14px 28px rgba(66, 130, 246, 0.28);
        }

        .qm-brand-copy {
            min-width: 0;
        }

        .qm-brand-title {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--qm-text);
            letter-spacing: -0.03em;
        }

        .qm-brand-subtitle {
            margin-top: 2px;
            font-size: 0.76rem;
            color: var(--qm-text-muted);
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }

        .qm-eyebrow {
            color: var(--qm-accent-2);
            text-transform: uppercase;
            letter-spacing: 0.16em;
            font-size: 0.74rem;
            font-weight: 700;
            margin-bottom: 0.55rem;
        }

        .qm-page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            margin-bottom: 1.4rem;
        }

        .qm-page-title {
            margin: 0;
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(1.9rem, 2.8vw, 2.65rem);
            font-weight: 700;
            color: var(--qm-text);
            letter-spacing: -0.04em;
        }

        .qm-page-subtitle {
            margin-top: 0.45rem;
            max-width: 760px;
            color: var(--qm-text-soft);
            line-height: 1.65;
            font-size: 0.98rem;
        }

        .qm-badge {
            align-self: flex-start;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 0.5rem 0.8rem;
            border-radius: 999px;
            background: rgba(115, 166, 255, 0.12);
            border: 1px solid rgba(115, 166, 255, 0.24);
            color: var(--qm-accent);
            font-size: 0.78rem;
            font-weight: 600;
            white-space: nowrap;
        }

        .qm-stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 14px;
            margin: 0 0 1.5rem;
        }

        .qm-stat-card {
            background: linear-gradient(180deg, rgba(11, 24, 42, 0.92) 0%, rgba(8, 17, 31, 0.92) 100%);
            border: 1px solid var(--qm-border);
            border-radius: 18px;
            padding: 1rem 1.05rem;
            box-shadow: var(--qm-shadow);
            backdrop-filter: blur(12px);
        }

        .qm-stat-card--accent {
            border-color: rgba(115, 166, 255, 0.28);
        }

        .qm-stat-card--success {
            border-color: rgba(123, 224, 175, 0.24);
        }

        .qm-stat-card--warm {
            border-color: rgba(240, 180, 109, 0.24);
        }

        .qm-stat-label {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.14em;
            color: var(--qm-text-muted);
            font-weight: 700;
        }

        .qm-stat-value {
            margin-top: 0.55rem;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.6rem;
            line-height: 1.1;
            color: var(--qm-text);
            font-weight: 700;
        }

        .qm-stat-detail {
            margin-top: 0.4rem;
            color: var(--qm-text-soft);
            font-size: 0.84rem;
            line-height: 1.4;
        }

        .qm-panel {
            background: linear-gradient(180deg, rgba(11, 24, 42, 0.9) 0%, rgba(8, 17, 31, 0.94) 100%);
            border: 1px solid var(--qm-border);
            border-radius: var(--qm-radius);
            padding: 1rem 1.1rem;
            margin-bottom: 1rem;
            box-shadow: var(--qm-shadow);
            backdrop-filter: blur(14px);
        }

        .qm-panel--accent {
            border-color: rgba(115, 166, 255, 0.3);
        }

        .qm-panel--success {
            border-color: rgba(123, 224, 175, 0.26);
        }

        .qm-panel--warning {
            border-color: rgba(240, 180, 109, 0.26);
        }

        .qm-panel-title {
            margin: 0;
            color: var(--qm-text);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: -0.03em;
        }

        .qm-panel-body {
            margin-top: 0.55rem;
            color: var(--qm-text-soft);
            line-height: 1.65;
            font-size: 0.92rem;
        }

        .qm-empty {
            border: 1px dashed rgba(156, 184, 255, 0.2);
            border-radius: var(--qm-radius);
            padding: 1.3rem 1.15rem;
            background: rgba(7, 17, 31, 0.54);
            color: var(--qm-text-soft);
            margin: 0.35rem 0 1rem;
        }

        .qm-empty-title {
            display: block;
            color: var(--qm-text);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
        }

        .qm-chip-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 0.9rem 0 1.1rem;
        }

        .qm-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 0.42rem 0.72rem;
            border-radius: 999px;
            background: rgba(115, 166, 255, 0.08);
            border: 1px solid rgba(115, 166, 255, 0.16);
            color: var(--qm-text-soft);
            font-size: 0.8rem;
        }

        .qm-chip strong {
            color: var(--qm-text);
            font-weight: 600;
        }

        .qm-chip--success {
            background: rgba(123, 224, 175, 0.08);
            border-color: rgba(123, 224, 175, 0.18);
        }

        .qm-chip--warning {
            background: rgba(240, 180, 109, 0.08);
            border-color: rgba(240, 180, 109, 0.18);
        }

        .qm-answer {
            background: linear-gradient(180deg, rgba(13, 28, 48, 0.95) 0%, rgba(8, 18, 31, 0.97) 100%);
            border: 1px solid rgba(115, 166, 255, 0.22);
            border-left: 4px solid var(--qm-accent);
            border-radius: 20px;
            padding: 1.2rem 1.25rem;
            margin: 0.6rem 0 0.3rem;
            box-shadow: var(--qm-shadow);
        }

        .qm-answer-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 0.34rem 0.62rem;
            border-radius: 999px;
            background: rgba(115, 166, 255, 0.12);
            color: var(--qm-accent);
            text-transform: uppercase;
            letter-spacing: 0.12em;
            font-size: 0.72rem;
            font-weight: 700;
        }

        .qm-answer-body {
            margin-top: 0.9rem;
            color: var(--qm-text);
            line-height: 1.72;
            font-size: 0.98rem;
            white-space: pre-wrap;
        }

        .qm-code {
            background: rgba(5, 13, 24, 0.92);
            border: 1px solid rgba(156, 184, 255, 0.16);
            border-radius: 16px;
            padding: 1rem 1rem;
            margin: 0.7rem 0;
            overflow-x: auto;
            font-family: 'IBM Plex Mono', monospace;
            color: #BFD4FF;
            line-height: 1.65;
            font-size: 0.84rem;
            white-space: pre-wrap;
        }

        .qm-evidence {
            background: rgba(7, 17, 31, 0.75);
            border: 1px solid rgba(156, 184, 255, 0.14);
            border-radius: 16px;
            padding: 0.9rem 1rem;
            margin: 0.7rem 0;
        }

        .qm-evidence-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 0.55rem;
            font-size: 0.82rem;
            color: var(--qm-text-soft);
        }

        .qm-evidence-source {
            font-family: 'IBM Plex Mono', monospace;
            color: #CFE0FF;
        }

        .qm-evidence-score {
            font-family: 'IBM Plex Mono', monospace;
            color: var(--qm-accent-2);
            font-size: 0.8rem;
        }

        .qm-evidence-text {
            color: var(--qm-text-soft);
            line-height: 1.65;
            font-size: 0.9rem;
        }

        .qm-feature-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-top: 1.4rem;
        }

        .qm-feature {
            background: linear-gradient(180deg, rgba(11, 24, 42, 0.92) 0%, rgba(7, 17, 31, 0.92) 100%);
            border: 1px solid var(--qm-border);
            border-radius: 20px;
            padding: 1.15rem;
            min-height: 170px;
            box-shadow: var(--qm-shadow);
        }

        .qm-feature-label {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 42px;
            height: 42px;
            padding: 0 0.75rem;
            border-radius: 12px;
            background: rgba(115, 166, 255, 0.12);
            color: var(--qm-accent);
            font-family: 'IBM Plex Mono', monospace;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .qm-feature-title {
            margin-top: 0.95rem;
            color: var(--qm-text);
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.02rem;
            font-weight: 700;
        }

        .qm-feature-copy {
            margin-top: 0.5rem;
            color: var(--qm-text-soft);
            font-size: 0.92rem;
            line-height: 1.65;
        }

        .qm-sidebar-note {
            background: rgba(8, 19, 35, 0.7);
            border: 1px solid rgba(156, 184, 255, 0.14);
            border-radius: 16px;
            padding: 0.95rem 1rem;
            margin-bottom: 0.95rem;
        }

        .qm-sidebar-title {
            margin: 0;
            color: var(--qm-text);
            font-size: 0.92rem;
            font-weight: 700;
        }

        .qm-sidebar-copy {
            margin-top: 0.45rem;
            color: var(--qm-text-soft);
            line-height: 1.55;
            font-size: 0.84rem;
        }

        .qm-sidebar-list {
            margin-top: 0.75rem;
            display: grid;
            gap: 8px;
        }

        .qm-sidebar-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            font-size: 0.82rem;
            color: var(--qm-text-soft);
        }

        .qm-sidebar-row strong {
            color: var(--qm-text);
            font-weight: 600;
        }

        .qm-kicker {
            margin-bottom: 0.55rem;
            color: var(--qm-text-muted);
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.14em;
            font-weight: 700;
        }

        div[data-testid="stMetric"] {
            background: linear-gradient(180deg, rgba(11, 24, 42, 0.84) 0%, rgba(8, 17, 31, 0.9) 100%);
            border: 1px solid rgba(156, 184, 255, 0.14);
            border-radius: 18px;
            padding: 1rem 1rem 0.9rem;
            box-shadow: var(--qm-shadow);
        }

        div[data-testid="stMetric"] label {
            color: var(--qm-text-muted) !important;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            font-size: 0.7rem !important;
        }

        div[data-testid="stMetricValue"] {
            font-family: 'Space Grotesk', sans-serif !important;
            color: var(--qm-text) !important;
            font-weight: 700 !important;
        }

        .stTabs [data-baseweb="tab-list"] {
            gap: 10px;
            border-bottom: 1px solid rgba(156, 184, 255, 0.12);
            padding-bottom: 0.2rem;
            margin-bottom: 0.25rem;
        }

        .stTabs [data-baseweb="tab"] {
            background: transparent !important;
            color: var(--qm-text-muted) !important;
            font-size: 0.88rem;
            font-weight: 600;
            padding: 0.65rem 0.95rem;
            border-radius: 999px;
            border: 1px solid transparent;
        }

        .stTabs [aria-selected="true"] {
            color: var(--qm-text) !important;
            background: rgba(115, 166, 255, 0.12) !important;
            border-color: rgba(115, 166, 255, 0.18) !important;
        }

        .stTabs [data-baseweb="tab-panel"] {
            padding-top: 1.2rem;
        }

        .stButton button,
        .stDownloadButton button,
        .stFormSubmitButton button {
            width: 100%;
            min-height: 2.9rem;
            border-radius: 14px;
            border: 1px solid rgba(115, 166, 255, 0.25);
            background: linear-gradient(135deg, rgba(115, 166, 255, 0.95) 0%, rgba(72, 212, 196, 0.92) 100%);
            color: #07111F;
            font-weight: 700;
            font-size: 0.92rem;
            letter-spacing: 0.01em;
            box-shadow: 0 16px 30px rgba(60, 128, 229, 0.24);
            transition: transform 120ms ease, box-shadow 120ms ease, opacity 120ms ease;
        }

        .stButton button:hover,
        .stDownloadButton button:hover,
        .stFormSubmitButton button:hover {
            transform: translateY(-1px);
            box-shadow: 0 20px 34px rgba(60, 128, 229, 0.28);
            opacity: 0.98;
        }

        .stButton button:disabled,
        .stDownloadButton button:disabled,
        .stFormSubmitButton button:disabled {
            background: rgba(115, 166, 255, 0.18);
            color: rgba(238, 245, 255, 0.5);
            border-color: rgba(115, 166, 255, 0.1);
            box-shadow: none;
        }

        .stTextInput input,
        .stTextArea textarea,
        .stSelectbox [data-baseweb="select"],
        .stMultiSelect [data-baseweb="select"],
        .stNumberInput input {
            background: rgba(7, 17, 31, 0.78) !important;
            border: 1px solid rgba(156, 184, 255, 0.16) !important;
            border-radius: 14px !important;
            color: var(--qm-text) !important;
        }

        .stTextInput input,
        .stNumberInput input {
            min-height: 2.9rem !important;
        }

        .stTextArea textarea {
            min-height: 7.5rem !important;
            line-height: 1.65 !important;
        }

        .stTextInput label,
        .stTextArea label,
        .stSelectbox label,
        .stMultiSelect label,
        .stSlider label,
        .stNumberInput label {
            color: var(--qm-text-soft) !important;
            font-size: 0.78rem !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            letter-spacing: 0.12em !important;
        }

        .stMultiSelect span[data-baseweb="tag"] {
            background: rgba(115, 166, 255, 0.12) !important;
            border-radius: 999px !important;
            color: var(--qm-text) !important;
            border: 1px solid rgba(115, 166, 255, 0.16) !important;
        }

        .stSlider [data-baseweb="slider"] [role="slider"] {
            background: var(--qm-accent) !important;
            border-color: var(--qm-accent) !important;
        }

        .stSlider [data-testid="stTickBar"] {
            background: rgba(156, 184, 255, 0.12);
        }

        div[data-testid="stFileUploader"] {
            background: rgba(8, 19, 35, 0.72);
            border: 1px dashed rgba(115, 166, 255, 0.28);
            border-radius: 18px;
            padding: 0.6rem 0.7rem;
        }

        div[data-testid="stFileUploader"] section {
            padding: 1rem 0.75rem !important;
        }

        .streamlit-expanderHeader {
            background: rgba(8, 19, 35, 0.72) !important;
            border: 1px solid rgba(156, 184, 255, 0.12) !important;
            border-radius: 16px !important;
            color: var(--qm-text) !important;
            font-size: 0.9rem !important;
            font-weight: 600 !important;
        }

        .streamlit-expanderContent {
            background: rgba(6, 13, 24, 0.24);
            border-radius: 0 0 16px 16px;
        }

        div[data-testid="stAlert"] {
            border-radius: 16px;
            border: 1px solid rgba(156, 184, 255, 0.14);
        }

        div[data-testid="stDataFrame"] {
            border: 1px solid rgba(156, 184, 255, 0.12);
            border-radius: 16px;
            overflow: hidden;
        }

        .stSpinner > div {
            border-top-color: var(--qm-accent) !important;
        }

        .stProgress > div > div {
            background: linear-gradient(90deg, var(--qm-accent), var(--qm-accent-2)) !important;
        }

        @media (max-width: 960px) {
            .qm-page-header {
                flex-direction: column;
            }

            .qm-feature-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_brand(title: str = "QueryMind", subtitle: str = "Workspace intelligence") -> None:
    st.markdown(
        f"""
        <div class="qm-brand">
            <div class="qm-brand-mark">Q</div>
            <div class="qm-brand-copy">
                <div class="qm-brand-title">{escape_text(title)}</div>
                <div class="qm-brand-subtitle">{escape_text(subtitle)}</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_page_header(
    title: str,
    subtitle: str,
    eyebrow: str | None = None,
    badge: str | None = None,
) -> None:
    eyebrow_html = f"<div class='qm-eyebrow'>{escape_text(eyebrow)}</div>" if eyebrow else ""
    badge_html = f"<div class='qm-badge'>{escape_text(badge)}</div>" if badge else ""
    st.markdown(
        f"""
        <div class="qm-page-header">
            <div>
                {eyebrow_html}
                <div class="qm-page-title">{escape_text(title)}</div>
                <div class="qm-page-subtitle">{escape_text(subtitle)}</div>
            </div>
            {badge_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_stat_cards(items: Iterable[Mapping[str, object]]) -> None:
    cards = []
    for item in items:
        label = escape_text(item.get("label", ""))
        value = escape_text(item.get("value", ""))
        detail = escape_text(item.get("detail", ""))
        tone = escape_text(item.get("tone", ""))
        tone_class = f" qm-stat-card--{tone}" if tone else ""
        detail_html = f"<div class='qm-stat-detail'>{detail}</div>" if detail else ""
        cards.append(
            (
                f"<div class='qm-stat-card{tone_class}'>"
                f"<div class='qm-stat-label'>{label}</div>"
                f"<div class='qm-stat-value'>{value}</div>"
                f"{detail_html}"
                "</div>"
            )
        )
    st.markdown(f"<div class='qm-stat-grid'>{''.join(cards)}</div>", unsafe_allow_html=True)


def render_panel(
    title: str,
    body: str,
    eyebrow: str | None = None,
    tone: str = "default",
    allow_html: bool = False,
) -> None:
    tone_class = ""
    if tone in {"accent", "success", "warning"}:
        tone_class = f" qm-panel--{tone}"
    eyebrow_html = f"<div class='qm-kicker'>{escape_text(eyebrow)}</div>" if eyebrow else ""
    body_html = body if allow_html else escape_text(body)
    st.markdown(
        f"""
        <div class="qm-panel{tone_class}">
            {eyebrow_html}
            <div class="qm-panel-title">{escape_text(title)}</div>
            <div class="qm-panel-body">{body_html}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_empty_state(title: str, body: str) -> None:
    st.markdown(
        f"""
        <div class="qm-empty">
            <span class="qm-empty-title">{escape_text(title)}</span>
            {escape_text(body)}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_answer(answer: str, badge: str) -> None:
    st.markdown(
        f"""
        <div class="qm-answer">
            <div class="qm-answer-badge">{escape_text(badge)}</div>
            <div class="qm-answer-body">{escape_text(answer)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_chip_row(items: Iterable[Mapping[str, object]]) -> None:
    chips = []
    for item in items:
        label = escape_text(item.get("label", ""))
        value = escape_text(item.get("value", ""))
        tone = escape_text(item.get("tone", ""))
        tone_class = f" qm-chip--{tone}" if tone else ""
        chips.append(
            f"<div class='qm-chip{tone_class}'>{label}<strong>{value}</strong></div>"
        )
    if chips:
        st.markdown(f"<div class='qm-chip-row'>{''.join(chips)}</div>", unsafe_allow_html=True)


def render_code_block(content: str) -> None:
    st.markdown(f"<div class='qm-code'>{escape_text(content)}</div>", unsafe_allow_html=True)


def render_evidence_card(source: str, detail: str, preview: str, score: float | None = None) -> None:
    score_html = ""
    if score is not None:
        score_html = f"<div class='qm-evidence-score'>score {score:.3f}</div>"
    st.markdown(
        f"""
        <div class="qm-evidence">
            <div class="qm-evidence-head">
                <div class="qm-evidence-source">{escape_text(source)}{escape_text(detail)}</div>
                {score_html}
            </div>
            <div class="qm-evidence-text">{escape_text(preview)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_feature_grid(items: Iterable[Mapping[str, object]]) -> None:
    cards = []
    for item in items:
        cards.append(
            (
                "<div class='qm-feature'>"
                f"<div class='qm-feature-label'>{escape_text(item.get('label', ''))}</div>"
                f"<div class='qm-feature-title'>{escape_text(item.get('title', ''))}</div>"
                f"<div class='qm-feature-copy'>{escape_text(item.get('body', ''))}</div>"
                "</div>"
            )
        )
    st.markdown(f"<div class='qm-feature-grid'>{''.join(cards)}</div>", unsafe_allow_html=True)


def render_sidebar_note(title: str, body: str, rows: Iterable[tuple[str, object]] | None = None) -> None:
    rows_html = ""
    if rows:
        row_items = []
        for label, value in rows:
            row_items.append(
                f"<div class='qm-sidebar-row'><span>{escape_text(label)}</span><strong>{escape_text(value)}</strong></div>"
            )
        rows_html = f"<div class='qm-sidebar-list'>{''.join(row_items)}</div>"
    st.markdown(
        f"""
        <div class="qm-sidebar-note">
            <div class="qm-sidebar-title">{escape_text(title)}</div>
            <div class="qm-sidebar-copy">{escape_text(body)}</div>
            {rows_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def format_timestamp(value: object) -> str:
    if not value:
        return "-"
    if isinstance(value, datetime):
        dt_value = value
    else:
        try:
            dt_value = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return str(value)
    return dt_value.strftime("%d %b %Y, %I:%M %p")
