from __future__ import annotations

from datetime import datetime

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

from ui_shared import (
    ACCENT_PALETTE,
    PLOTLY_THEME,
    format_timestamp,
    render_answer,
    render_chip_row,
    render_code_block,
    render_empty_state,
    render_page_header,
    render_panel,
    render_stat_cards,
)


API_BASE = "http://localhost:8000"


def headers() -> dict[str, str]:
    return {"Authorization": f"Bearer {st.session_state.token}"}


def response_error(response: requests.Response, fallback: str) -> str:
    try:
        payload = response.json()
        return payload.get("detail", fallback)
    except Exception:
        return fallback


def handle_auth_error(response: requests.Response) -> bool:
    if response.status_code == 401:
        st.session_state.token = None
        st.session_state.username = None
        st.session_state.auth_notice = "Your session expired. Please sign in again."
        st.rerun()
    return False


def apply_example(select_key: str, draft_key: str, blank_option: str) -> None:
    selected = st.session_state.get(select_key, blank_option)
    if selected != blank_option:
        st.session_state[draft_key] = selected


def api_connect_pg(host: str, port: int, database: str, username: str, password: str):
    try:
        response = requests.post(
            f"{API_BASE}/db-chat/connect",
            json={
                "db_type": "postgresql",
                "host": host,
                "port": port,
                "database": database,
                "username": username,
                "password": password,
            },
            headers=headers(),
            timeout=15,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_connect_sqlite(file_bytes: bytes, filename: str):
    try:
        response = requests.post(
            f"{API_BASE}/db-chat/connect-sqlite",
            files={"file": (filename, file_bytes)},
            headers=headers(),
            timeout=15,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_get_schema():
    try:
        response = requests.get(f"{API_BASE}/db-chat/schema", headers=headers(), timeout=10)
        handle_auth_error(response)
        return response.json() if response.status_code == 200 else None
    except Exception:
        return None


def api_get_schema_summary() -> str:
    try:
        response = requests.get(
            f"{API_BASE}/db-chat/schema-summary",
            headers=headers(),
            timeout=10,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json().get("summary", "")
        return ""
    except Exception:
        return ""


def api_nl_query(question: str):
    try:
        response = requests.post(
            f"{API_BASE}/db-chat/query",
            json={"question": question},
            headers=headers(),
            timeout=120,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_raw_sql(sql: str):
    try:
        response = requests.post(
            f"{API_BASE}/db-chat/sql",
            json={"sql": sql},
            headers=headers(),
            timeout=30,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_status():
    try:
        response = requests.get(f"{API_BASE}/db-chat/status", headers=headers(), timeout=5)
        handle_auth_error(response)
        return response.json() if response.status_code == 200 else {"connected": False}
    except Exception:
        return {"connected": False}


def api_disconnect() -> None:
    try:
        response = requests.post(f"{API_BASE}/db-chat/disconnect", headers=headers(), timeout=5)
        handle_auth_error(response)
    except Exception:
        pass


def generate_auto_examples(schema_data: dict[str, dict]) -> list[str]:
    tables = list(schema_data.keys())
    examples: list[str] = []
    if not tables:
        return examples

    first_table = tables[0]
    first_info = schema_data[first_table]
    columns = first_info.get("columns", [])
    numeric_columns = [
        column["name"]
        for column in columns
        if any(token in str(column.get("type", "")).lower() for token in ["int", "float", "num", "dec", "big"])
    ]
    text_columns = [column["name"] for column in columns if column["name"] not in numeric_columns]

    examples.append(f"How many rows are in {first_table}?")
    examples.append(f"Show the latest 10 rows from {first_table}")
    if text_columns:
        examples.append(f"Count {first_table} grouped by {text_columns[0]}")
    if numeric_columns:
        examples.append(f"What is the average {numeric_columns[0]} in {first_table}?")
        examples.append(f"Show the top 10 {first_table} by {numeric_columns[0]}")
    if len(tables) > 1:
        examples.append(f"Compare row counts across {tables[0]} and {tables[1]}")
    return examples[:6]


def is_schema_overview_question(question: str) -> bool:
    lowered = question.lower()
    overview_terms = [
        "schema",
        "structure",
        "what tables",
        "what columns",
        "database overview",
        "describe the database",
        "show the schema",
        "database summary",
    ]
    return any(term in lowered for term in overview_terms)


def numeric_columns(frame: pd.DataFrame) -> list[str]:
    return [column for column in frame.columns if pd.api.types.is_numeric_dtype(frame[column])]


def render_chart(chart: dict, key_suffix: str = "") -> None:
    chart_type = chart.get("type", "none")
    data = chart.get("data", [])
    title = chart.get("title", "Query result")

    if chart_type == "none" or not data:
        return

    frame = pd.DataFrame(data)
    if frame.empty:
        return

    if chart_type == "single_value":
        render_stat_cards(
            [
                {
                    "label": chart.get("label", "Result").replace("_", " "),
                    "value": chart.get("value", ""),
                    "detail": title,
                    "tone": "accent",
                }
            ]
        )
        return

    x_col = chart.get("x_col") or (frame.columns[0] if len(frame.columns) > 0 else None)
    y_col = chart.get("y_col") or (frame.columns[1] if len(frame.columns) > 1 else None)
    orientation = chart.get("orientation", "v")

    picker_col, plot_col = st.columns([1, 5])
    with picker_col:
        override = st.selectbox(
            "Chart",
            ["Auto", "Bar", "Line", "Pie", "Scatter", "Area"],
            key=f"dbchat_chart_type_{key_suffix}",
        )

    chart_type = chart_type if override == "Auto" else override.lower()

    with plot_col:
        try:
            if chart_type == "bar" and x_col and y_col:
                plot_frame = frame.sort_values(y_col, ascending=False) if y_col in frame.columns else frame
                if orientation == "h":
                    figure = px.bar(
                        plot_frame,
                        x=x_col,
                        y=y_col,
                        orientation="h",
                        color=y_col if len(plot_frame) <= 20 else None,
                        text=x_col if x_col in plot_frame.columns else None,
                        title=title,
                        color_discrete_sequence=ACCENT_PALETTE,
                    )
                else:
                    figure = px.bar(
                        plot_frame,
                        x=x_col,
                        y=y_col,
                        color=x_col if len(plot_frame) <= 20 else None,
                        text=y_col if y_col in plot_frame.columns else None,
                        title=title,
                        color_discrete_sequence=ACCENT_PALETTE,
                    )
                figure.update_traces(textposition="outside")
                figure.update_layout(**PLOTLY_THEME, showlegend=False)
            elif chart_type == "line" and x_col and y_col:
                figure = px.line(
                    frame,
                    x=x_col,
                    y=y_col,
                    markers=True,
                    title=title,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                figure.update_layout(**PLOTLY_THEME)
            elif chart_type == "pie" and x_col and y_col:
                figure = px.pie(
                    frame,
                    names=x_col,
                    values=y_col,
                    title=title,
                    hole=0.55,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                figure.update_layout(**PLOTLY_THEME)
            elif chart_type == "scatter" and x_col and y_col:
                figure = px.scatter(
                    frame,
                    x=x_col,
                    y=y_col,
                    title=title,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                figure.update_layout(**PLOTLY_THEME, showlegend=False)
            elif chart_type == "area" and x_col and y_col:
                figure = px.area(
                    frame,
                    x=x_col,
                    y=y_col,
                    title=title,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                figure.update_layout(**PLOTLY_THEME)
            else:
                st.dataframe(frame, use_container_width=True, hide_index=True)
                return

            st.plotly_chart(figure, use_container_width=True)
        except Exception:
            st.dataframe(frame, use_container_width=True, hide_index=True)


def render_connection_screen() -> None:
    render_page_header(
        "Connect a live database",
        "Attach PostgreSQL or a SQLite file, inspect the schema, and ask analytical questions without leaving the workspace.",
        eyebrow="DB Chat",
        badge="Read-only execution",
    )
    render_stat_cards(
        [
            {"label": "Connection types", "value": "2", "detail": "PostgreSQL and SQLite", "tone": "accent"},
            {"label": "Execution policy", "value": "SELECT", "detail": "Write operations are blocked", "tone": "warm"},
            {"label": "Best for", "value": "Ad hoc analysis", "detail": "Schema exploration and exports", "tone": "success"},
        ]
    )

    render_panel(
        "What to expect",
        "Once connected, the app reads the schema, suggests example questions, shows generated SQL, and lets you export result sets as CSV.",
        eyebrow="Workflow",
        tone="accent",
    )

    tab_pg, tab_sqlite = st.tabs(["PostgreSQL", "SQLite file"])

    with tab_pg:
        render_panel(
            "Connection details",
            "Use database credentials with read access. The app will profile tables and row counts after the connection succeeds.",
            eyebrow="PostgreSQL",
        )
        with st.form("dbchat_pg_connect_form"):
            host_col, port_col = st.columns(2)
            host = host_col.text_input("Host", value="localhost")
            port_text = port_col.text_input("Port", value="5432")
            database = st.text_input("Database name", placeholder="analytics")
            user_col, password_col = st.columns(2)
            username = user_col.text_input("Username", value="postgres")
            password = password_col.text_input("Password", type="password")
            submitted = st.form_submit_button("Connect PostgreSQL")

        if submitted:
            if not database.strip():
                st.error("Enter a database name before connecting.")
            else:
                try:
                    port = int(port_text)
                except ValueError:
                    st.error("Port must be a valid number.")
                else:
                    with st.spinner("Connecting and reading schema..."):
                        result, err = api_connect_pg(host.strip(), port, database.strip(), username.strip(), password)
                    if err:
                        st.error(f"Connection failed: {err}")
                    else:
                        st.session_state.db_connected = True
                        st.session_state.db_info = result
                        st.session_state.db_schema = result.get("schema", {})
                        st.success(f"Connected to {result.get('database', database)}.")
                        st.rerun()

    with tab_sqlite:
        render_panel(
            "SQLite upload",
            "Upload a .db, .sqlite, or .sqlite3 file to start querying immediately. This is useful for demos, local exports, and analysis snapshots.",
            eyebrow="SQLite",
        )
        sqlite_file = st.file_uploader(
            "SQLite database file",
            type=["db", "sqlite", "sqlite3"],
            key="dbchat_sqlite_uploader",
        )
        if sqlite_file:
            render_panel(
                sqlite_file.name,
                f"Ready to connect. File size: {sqlite_file.size / 1024:.1f} KB.",
                eyebrow="Selected file",
                tone="accent",
            )
            if st.button("Upload and connect", key="dbchat_sqlite_connect"):
                with st.spinner("Uploading database and reading schema..."):
                    result, err = api_connect_sqlite(sqlite_file.getvalue(), sqlite_file.name)
                if err:
                    st.error(f"Connection failed: {err}")
                else:
                    st.session_state.db_connected = True
                    st.session_state.db_info = result
                    st.session_state.db_schema = result.get("schema", {})
                    st.success(f"Connected to {result.get('database', sqlite_file.name)}.")
                    st.rerun()


def render_ask_tab() -> None:
    schema_payload = api_get_schema()
    if schema_payload:
        st.session_state.db_schema = schema_payload.get("schema", {})

    examples = generate_auto_examples(st.session_state.db_schema)
    blank_option = "Start from scratch"

    st.selectbox(
        "Suggested question",
        [blank_option] + examples,
        key="db_chat_example",
        on_change=apply_example,
        args=("db_chat_example", "db_chat_draft", blank_option),
    )

    question = st.text_area(
        "Question",
        key="db_chat_draft",
        height=120,
        placeholder="Example: Which department has the highest average salary?",
    )

    action_col, clear_col = st.columns([3, 1])
    with action_col:
        run_question = st.button(
            "Ask database",
            key="db_chat_run",
            disabled=not question.strip(),
        )
    with clear_col:
        clear_response = st.button("Clear", key="db_chat_clear")

    if clear_response:
        st.session_state.db_chat_last_result = None
        st.session_state.db_chat_last_summary = ""
        st.rerun()

    if run_question and question.strip():
        if is_schema_overview_question(question):
            summary = api_get_schema_summary()
            if summary:
                st.session_state.db_chat_last_result = None
                st.session_state.db_chat_last_summary = summary
            else:
                st.error("Schema summary is not available for this connection yet.")
        else:
            with st.spinner("Generating SQL and querying the database..."):
                result, err = api_nl_query(question)
            if err:
                st.error(f"Query failed: {err}")
            else:
                st.session_state.db_chat_last_summary = ""
                st.session_state.db_chat_last_result = result
                st.session_state.db_query_history.insert(
                    0,
                    {
                        "created_at": datetime.now().isoformat(timespec="seconds"),
                        "question": question,
                        "answer": result["answer"],
                        "sql": result["sql"],
                        "rows": result["row_count"],
                        "latency_ms": result["latency_ms"],
                        "chart": result["chart"],
                    },
                )

    summary = st.session_state.get("db_chat_last_summary", "")
    result = st.session_state.get("db_chat_last_result")

    if summary:
        render_panel("Schema overview", summary, eyebrow="Database summary", tone="accent")
    elif result:
        render_answer(result["answer"], "Database answer")
        render_chip_row(
            [
                {"label": "Latency", "value": f"{result['latency_ms']:.0f} ms"},
                {"label": "Rows", "value": result["row_count"], "tone": "success"},
                {"label": "Mode", "value": "Generated SQL", "tone": "accent"},
            ]
        )
        with st.expander("Generated SQL", expanded=True):
            render_code_block(result["sql"])

        if result["rows"]:
            render_chart(result["chart"], key_suffix="latest")
            with st.expander(f"Raw rows ({result['row_count']})", expanded=False):
                frame = pd.DataFrame(result["rows"])
                st.dataframe(frame, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download CSV",
                    frame.to_csv(index=False),
                    file_name=f"db_chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    key="dbchat_latest_download",
                )
        else:
            render_empty_state("No rows returned", "The query ran successfully but did not match any records.")
    else:
        render_empty_state(
            "No database answer yet",
            "Ask a question above to inspect the connected schema, review generated SQL, and export results.",
        )


def render_schema_tab() -> None:
    schema_data = st.session_state.get("db_schema", {})
    if not schema_data:
        schema_payload = api_get_schema()
        if schema_payload:
            schema_data = schema_payload.get("schema", {})
            st.session_state.db_schema = schema_data

    if not schema_data:
        render_empty_state("Schema unavailable", "Connect a database first to inspect tables, columns, and sample rows.")
        return

    total_columns = sum(info.get("column_count", len(info.get("columns", []))) for info in schema_data.values())
    total_rows = sum(info.get("row_count", 0) for info in schema_data.values())
    render_stat_cards(
        [
            {"label": "Tables", "value": len(schema_data), "detail": "Discovered in the connected database"},
            {"label": "Columns", "value": total_columns, "detail": "Across all profiled tables", "tone": "accent"},
            {"label": "Rows", "value": f"{total_rows:,}", "detail": "Estimated total rows", "tone": "success"},
        ]
    )

    filter_term = st.text_input(
        "Filter tables",
        key="db_schema_filter",
        placeholder="Search by table or column name",
    ).strip().lower()

    summary = api_get_schema_summary()
    if summary:
        with st.expander("Schema summary", expanded=False):
            render_code_block(summary)

    filtered_tables = []
    for table_name, table_info in schema_data.items():
        columns = table_info.get("columns", [])
        matches = not filter_term or filter_term in table_name.lower() or any(
            filter_term in column["name"].lower() for column in columns
        )
        if matches:
            filtered_tables.append((table_name, table_info))

    if not filtered_tables:
        render_empty_state("No matching tables", "Try a broader filter to inspect the available schema.")
        return

    for table_name, table_info in filtered_tables:
        row_count = table_info.get("row_count", 0)
        column_count = table_info.get("column_count", len(table_info.get("columns", [])))
        primary_keys = table_info.get("primary_keys", [])
        foreign_keys = table_info.get("foreign_keys", [])

        with st.expander(f"{table_name} · {row_count:,} rows · {column_count} columns", expanded=False):
            metric_cols = st.columns(4)
            metric_cols[0].metric("Rows", f"{row_count:,}")
            metric_cols[1].metric("Columns", column_count)
            metric_cols[2].metric("Primary keys", len(primary_keys))
            metric_cols[3].metric("Foreign keys", len(foreign_keys))

            rows = []
            for column in table_info.get("columns", []):
                related_fk = [
                    f"{fk['ref_table']}.{fk['ref_columns'][0]}"
                    for fk in foreign_keys
                    if column["name"] in fk["columns"]
                ]
                rows.append(
                    {
                        "Column": column["name"],
                        "Type": column.get("type", ""),
                        "Nullable": "Yes" if column.get("nullable") else "No",
                        "Primary key": "Yes" if column["name"] in primary_keys else "",
                        "Foreign key": related_fk[0] if related_fk else "",
                    }
                )

            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

            if foreign_keys:
                relationships = ", ".join(
                    f"{', '.join(fk['columns'])} -> {fk['ref_table']}.{', '.join(fk['ref_columns'])}"
                    for fk in foreign_keys
                )
                render_panel("Relationships", relationships, eyebrow="Foreign keys", tone="accent")

            if table_info.get("sample_rows"):
                st.caption("Sample rows")
                st.dataframe(
                    pd.DataFrame(table_info["sample_rows"]),
                    use_container_width=True,
                    hide_index=True,
                )


def render_history_tab() -> None:
    history = st.session_state.get("db_query_history", [])
    if not history:
        render_empty_state("No local history yet", "Recent DB chat results will appear here during this session.")
        return

    avg_latency = sum(item["latency_ms"] for item in history) / len(history)
    total_rows = sum(item["rows"] for item in history)
    render_stat_cards(
        [
            {"label": "Queries", "value": len(history), "detail": "Captured in this Streamlit session"},
            {"label": "Average latency", "value": f"{avg_latency:.0f} ms", "detail": "End-to-end response time", "tone": "accent"},
            {"label": "Rows returned", "value": total_rows, "detail": "Across all successful queries", "tone": "success"},
        ]
    )

    search = st.text_input(
        "Filter query history",
        key="db_history_search",
        placeholder="Search by question text",
    ).strip().lower()

    action_col, _ = st.columns([1, 5])
    with action_col:
        if st.button("Clear local history", key="db_history_clear"):
            st.session_state.db_query_history = []
            st.rerun()

    if len(history) > 1:
        history_frame = pd.DataFrame(history[::-1])
        latency_figure = px.line(
            history_frame,
            y="latency_ms",
            markers=True,
            title="DB chat latency",
            color_discrete_sequence=[ACCENT_PALETTE[0]],
        )
        latency_figure.update_layout(**PLOTLY_THEME, showlegend=False)
        st.plotly_chart(latency_figure, use_container_width=True)

    filtered_history = [
        item for item in history if not search or search in item["question"].lower()
    ]

    if not filtered_history:
        render_empty_state("No matching queries", "Adjust the search term to review your local DB chat history.")
        return

    for index, item in enumerate(filtered_history):
        label = f"{format_timestamp(item.get('created_at'))} · {item['question'][:90]}"
        with st.expander(label, expanded=False):
            render_answer(item["answer"], "Saved answer")
            render_chip_row(
                [
                    {"label": "Rows", "value": item["rows"], "tone": "success"},
                    {"label": "Latency", "value": f"{item['latency_ms']:.0f} ms"},
                ]
            )
            render_code_block(item["sql"])
            if item.get("chart") and item["chart"].get("type") not in {None, "none"}:
                render_chart(item["chart"], key_suffix=f"history_{index}")


def render_raw_sql_tab() -> None:
    render_panel(
        "Execution policy",
        "Only SELECT queries are allowed here. The backend rejects write operations and other unsafe statements.",
        eyebrow="Safety",
        tone="warning",
    )

    tables = sorted(st.session_state.get("db_schema", {}).keys())
    blank_option = "Write your own"
    quick_queries = [f'SELECT * FROM "{table}" LIMIT 10' for table in tables]

    st.selectbox(
        "Quick start",
        [blank_option] + quick_queries,
        key="db_raw_example",
        on_change=apply_example,
        args=("db_raw_example", "db_raw_sql", blank_option),
    )

    raw_sql = st.text_area(
        "SQL",
        key="db_raw_sql",
        height=140,
        placeholder='SELECT * FROM "your_table" LIMIT 10',
    )

    action_col, clear_col = st.columns([3, 1])
    with action_col:
        run_sql = st.button(
            "Execute SQL",
            key="db_raw_run",
            disabled=not raw_sql.strip(),
        )
    with clear_col:
        clear_sql = st.button("Clear", key="db_raw_clear")

    if clear_sql:
        st.session_state.db_raw_result = None
        st.session_state.db_raw_sql = ""
        st.rerun()

    if run_sql and raw_sql.strip():
        with st.spinner("Executing SQL..."):
            result, err = api_raw_sql(raw_sql)
        if err:
            st.error(f"Execution failed: {err}")
        else:
            st.session_state.db_raw_result = result

    result = st.session_state.get("db_raw_result")
    if not result:
        render_empty_state("No SQL result yet", "Run a SELECT query to inspect rows and export them as CSV.")
        return

    render_chip_row(
        [
            {"label": "Rows", "value": result["row_count"], "tone": "success"},
            {"label": "Mode", "value": "Raw SQL", "tone": "accent"},
        ]
    )
    render_code_block(result["sql"])

    if result["rows"]:
        frame = pd.DataFrame(result["rows"])
        st.dataframe(frame, use_container_width=True, hide_index=True)
        st.download_button(
            "Download CSV",
            frame.to_csv(index=False),
            file_name=f"db_raw_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            key="db_raw_download",
        )
    else:
        render_empty_state("No rows returned", "The SQL executed successfully but the result set was empty.")


def render_db_chat() -> None:
    for key, default in [
        ("db_connected", False),
        ("db_info", {}),
        ("db_query_history", []),
        ("db_schema", {}),
        ("db_chat_draft", ""),
        ("db_chat_example", "Start from scratch"),
        ("db_chat_last_result", None),
        ("db_chat_last_summary", ""),
        ("db_raw_example", "Write your own"),
        ("db_raw_sql", ""),
        ("db_raw_result", None),
    ]:
        if key not in st.session_state:
            st.session_state[key] = default

    status = api_status()
    st.session_state.db_connected = status.get("connected", False)

    if not st.session_state.db_connected:
        render_connection_screen()
        return

    st.session_state.db_info = status
    render_page_header(
        "Talk to your database",
        "Query the connected schema in plain English, inspect the generated SQL, and export result sets without leaving the app.",
        eyebrow="DB Chat",
        badge=status.get("database", "Connected"),
    )

    render_stat_cards(
        [
            {"label": "Database", "value": status.get("database", "-"), "detail": status.get("db_type", "").upper(), "tone": "accent"},
            {"label": "Tables", "value": status.get("table_count", 0), "detail": "Profiled from the active connection"},
            {"label": "Columns", "value": status.get("total_columns", 0), "detail": "Available to the SQL generator"},
            {"label": "Rows", "value": f"{status.get('total_rows', 0):,}", "detail": "Estimated total rows", "tone": "success"},
        ]
    )

    action_col, _ = st.columns([1, 5])
    with action_col:
        if st.button("Disconnect", key="dbchat_disconnect"):
            api_disconnect()
            st.session_state.db_connected = False
            st.session_state.db_info = {}
            st.session_state.db_schema = {}
            st.session_state.db_chat_last_result = None
            st.session_state.db_chat_last_summary = ""
            st.session_state.db_raw_result = None
            st.rerun()

    ask_tab, schema_tab, history_tab, raw_tab = st.tabs(
        ["Ask", "Schema", "History", "Raw SQL"]
    )

    with ask_tab:
        render_ask_tab()

    with schema_tab:
        render_schema_tab()

    with history_tab:
        render_history_tab()

    with raw_tab:
        render_raw_sql_tab()
