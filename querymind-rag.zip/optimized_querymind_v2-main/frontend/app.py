from __future__ import annotations

import re
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from db_chat_page import render_db_chat
from ui_shared import (
    ACCENT_PALETTE,
    PLOTLY_THEME,
    format_timestamp,
    inject_styles,
    render_answer,
    render_brand,
    render_chip_row,
    render_code_block,
    render_empty_state,
    render_evidence_card,
    render_feature_grid,
    render_page_header,
    render_panel,
    render_sidebar_note,
    render_stat_cards,
)


API_BASE = "http://localhost:8000"
BLANK_EXAMPLE = "Start from scratch"


st.set_page_config(
    page_title="QueryMind | Workspace Intelligence",
    page_icon="Q",
    layout="wide",
    initial_sidebar_state="expanded",
)
inject_styles()


for key, default in [
    ("token", None),
    ("username", None),
    ("auth_notice", None),
    ("query_mode", "auto"),
    ("top_k", 7),
    ("ask_draft", ""),
    ("ask_example", BLANK_EXAMPLE),
    ("ask_selected_docs", []),
    ("last_answer", None),
    ("doc_search", ""),
    ("db_draft", ""),
    ("db_example", BLANK_EXAMPLE),
    ("last_db_result", None),
]:
    if key not in st.session_state:
        st.session_state[key] = default


def response_error(response: requests.Response, fallback: str) -> str:
    try:
        payload = response.json()
        return payload.get("detail", fallback)
    except Exception:
        return fallback


def clear_auth_state(notice: str | None = None) -> None:
    st.session_state.token = None
    st.session_state.username = None
    st.session_state.last_answer = None
    st.session_state.last_db_result = None
    st.session_state.auth_notice = notice


def handle_auth_error(response: requests.Response) -> bool:
    if response.status_code == 401:
        clear_auth_state("Your session expired. Please sign in again.")
        st.rerun()
    return False


def hdr() -> dict[str, str]:
    return {"Authorization": f"Bearer {st.session_state.token}"}


def apply_example(select_key: str, draft_key: str, blank_option: str) -> None:
    selected = st.session_state.get(select_key, blank_option)
    if selected != blank_option:
        st.session_state[draft_key] = selected


def api_login(username: str, password: str):
    try:
        response = requests.post(
            f"{API_BASE}/auth/token",
            data={"username": username, "password": password},
            timeout=10,
        )
        if response.status_code == 200:
            return response.json()["access_token"], None
        return None, response_error(response, "Login failed")
    except Exception as exc:
        return None, str(exc)


def api_health():
    try:
        response = requests.get(f"{API_BASE}/health", timeout=5)
        return response.json() if response.status_code == 200 else None
    except Exception:
        return None


def api_upload(file_bytes: bytes, filename: str):
    try:
        response = requests.post(
            f"{API_BASE}/documents/upload",
            files={"file": (filename, file_bytes)},
            headers=hdr(),
            timeout=120,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_list_docs():
    try:
        response = requests.get(f"{API_BASE}/documents", headers=hdr(), timeout=10)
        handle_auth_error(response)
        return response.json() if response.status_code == 200 else []
    except Exception:
        return []


def api_delete_doc(doc_id: int) -> bool:
    try:
        response = requests.delete(f"{API_BASE}/documents/{doc_id}", headers=hdr(), timeout=10)
        handle_auth_error(response)
        return response.status_code == 200
    except Exception:
        return False


def api_query(question: str, mode: str, doc_ids: list[int] | None = None, top_k: int = 7):
    try:
        payload = {"question": question, "mode": mode, "top_k": top_k, "use_cache": True}
        if doc_ids:
            payload["doc_ids"] = doc_ids
        response = requests.post(
            f"{API_BASE}/query",
            json=payload,
            headers=hdr(),
            timeout=120,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, f"HTTP {response.status_code}")
    except Exception as exc:
        return None, str(exc)


def api_summarize(doc_id: int):
    try:
        response = requests.post(
            f"{API_BASE}/documents/summarize",
            json={"doc_id": doc_id},
            headers=hdr(),
            timeout=60,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, "Summarization failed")
    except Exception as exc:
        return None, str(exc)


def api_extract(doc_id: int):
    try:
        response = requests.post(
            f"{API_BASE}/documents/extract",
            json={"doc_id": doc_id},
            headers=hdr(),
            timeout=60,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, "Extraction failed")
    except Exception as exc:
        return None, str(exc)


def api_reindex(doc_ids: list[int] | None = None):
    try:
        payload = {"doc_ids": doc_ids or []}
        response = requests.post(
            f"{API_BASE}/documents/reindex",
            json=payload,
            headers=hdr(),
            timeout=180,
        )
        handle_auth_error(response)
        if response.status_code == 200:
            return response.json(), None
        return None, response_error(response, "Reindex failed")
    except Exception as exc:
        return None, str(exc)


def api_history():
    try:
        response = requests.get(f"{API_BASE}/history?limit=50", headers=hdr(), timeout=10)
        handle_auth_error(response)
        return response.json() if response.status_code == 200 else []
    except Exception:
        return []


def fmt_size(num_bytes: int) -> str:
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1024**2:
        return f"{num_bytes / 1024:.1f} KB"
    return f"{num_bytes / 1024**2:.1f} MB"


def file_type_label(file_type: str) -> str:
    return (file_type or "file").upper()


def numeric_columns(frame: pd.DataFrame) -> list[str]:
    return [column for column in frame.columns if pd.api.types.is_numeric_dtype(frame[column])]


def pick_chart_spec(frame: pd.DataFrame, question: str) -> dict | None:
    if frame.empty or len(frame) <= 1:
        return None

    question_lower = question.lower()
    number_columns = numeric_columns(frame)
    if not number_columns:
        return None

    date_columns = [
        column
        for column in frame.columns
        if pd.api.types.is_datetime64_any_dtype(frame[column])
        or any(token in column.lower() for token in ["date", "time", "month", "year", "day", "week"])
    ]
    category_columns = [column for column in frame.columns if column not in number_columns]

    def score_numeric(column: str) -> float:
        score = 0.0
        lowered = column.lower()
        if lowered in question_lower:
            score += 6
        score += len(set(re.findall(r"[a-z0-9_]+", lowered)) & set(re.findall(r"[a-z0-9_]+", question_lower))) * 3
        if any(token in lowered for token in ["count", "total", "sum", "avg", "average", "budget", "salary", "amount", "score", "revenue"]):
            score += 2
        if lowered in {"id", "rank", "index"} or lowered.endswith("_id"):
            score -= 4
        return score

    def score_category(column: str) -> float:
        score = 0.0
        lowered = column.lower()
        if lowered in question_lower:
            score += 5
        if any(token in lowered for token in ["name", "title", "label", "department", "category", "project", "user", "employee", "team", "status"]):
            score += 4
        if lowered == "id" or lowered.endswith("_id"):
            score -= 2
        return score

    metric_column = max(number_columns, key=score_numeric)
    category_column = max(category_columns, key=score_category) if category_columns else None

    if date_columns:
        return {"type": "Line", "x": date_columns[0], "y": metric_column, "orientation": "v"}

    if category_column:
        use_pie = (
            len(frame) <= 7
            and any(word in question_lower for word in ["share", "distribution", "breakdown", "proportion", "percent"])
        )
        orientation = "h" if (
            len(frame) > 5
            or any(word in question_lower for word in ["top", "highest", "lowest", "largest", "smallest"])
            or frame[category_column].astype(str).str.len().max() > 16
        ) else "v"
        return {
            "type": "Pie" if use_pie else "Bar",
            "x": category_column,
            "y": metric_column,
            "orientation": orientation,
        }

    if len(number_columns) >= 2:
        return {"type": "Scatter", "x": number_columns[0], "y": metric_column, "orientation": "v"}

    return None


def render_sidebar(health: dict | None) -> None:
    with st.sidebar:
        render_brand()

        if health:
            render_sidebar_note(
                "Platform status",
                f"{health.get('status', 'unknown').upper()} · version {health.get('version', '?')}",
                rows=[
                    ("Documents", health.get("document_count", 0)),
                    ("Indexed chunks", health.get("chunk_count", 0)),
                ],
            )
            services = health.get("services", {})
            if services:
                render_sidebar_note(
                    "Services",
                    "Live checks for the backend dependencies powering retrieval and analytics.",
                    rows=list(services.items()),
                )
        else:
            render_sidebar_note(
                "Platform status",
                "The API is unreachable right now. Sign-in and query actions will be unavailable until the backend is running.",
            )

        st.markdown("<div class='qm-kicker'>Authentication</div>", unsafe_allow_html=True)
        if not st.session_state.token:
            if st.session_state.auth_notice:
                st.warning(st.session_state.auth_notice)
            username = st.text_input("Username", value="user", key="sidebar_username")
            password = st.text_input("Password", type="password", value="user123", key="sidebar_password")
            if st.button("Sign in", key="sidebar_sign_in"):
                token, err = api_login(username, password)
                if token:
                    st.session_state.token = token
                    st.session_state.username = username
                    st.session_state.auth_notice = None
                    st.rerun()
                else:
                    st.error(err)
            render_sidebar_note(
                "Demo access",
                "Use the bundled demo account if you just want to explore the interface.",
                rows=[("Username", "user"), ("Password", "user123")],
            )
        else:
            render_sidebar_note(
                "Signed in",
                f"Active workspace session for {st.session_state.username}.",
                rows=[("User", st.session_state.username), ("Role", "Authenticated")],
            )
            if st.button("Sign out", key="sidebar_sign_out"):
                clear_auth_state()
                st.rerun()

            st.markdown("<div class='qm-kicker'>Query controls</div>", unsafe_allow_html=True)
            st.selectbox(
                "Routing mode",
                ["auto", "rag", "sql"],
                key="query_mode",
                help="Auto picks the route for you. RAG stays on documents. SQL routes directly to structured queries.",
            )
            st.slider(
                "Retrieval depth",
                min_value=3,
                max_value=15,
                key="top_k",
                help="Higher values search more chunks before generating the answer.",
            )
            render_sidebar_note(
                "Supported document formats",
                "Upload PDF, CSV, TXT, and DOCX files to build a searchable document library.",
            )


def render_dataframe_chart(frame: pd.DataFrame, key_prefix: str, title: str, question: str = "") -> None:
    spec = pick_chart_spec(frame, question or title)
    if not spec:
        return

    control_col, chart_col = st.columns([1, 5])
    with control_col:
        chart_options = []
        for option in [spec["type"], "Bar", "Line", "Pie", "Scatter"]:
            if option not in chart_options:
                chart_options.append(option)
        chart_type = st.selectbox(
            "Chart",
            chart_options,
            key=f"{key_prefix}_chart_type",
        )

    x_column = spec["x"]
    y_column = spec["y"]
    orientation = spec.get("orientation", "v")

    with chart_col:
        if chart_type == "Bar":
            plot_frame = frame.sort_values(y_column, ascending=False) if y_column in frame.columns else frame
            if orientation == "h":
                figure = px.bar(
                    plot_frame,
                    x=y_column,
                    y=x_column,
                    orientation="h",
                    color=x_column if len(plot_frame) <= 20 else None,
                    text=y_column,
                    title=title,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
            else:
                figure = px.bar(
                    plot_frame,
                    x=x_column,
                    y=y_column,
                    color=x_column if len(plot_frame) <= 20 else None,
                    text=y_column,
                    title=title,
                    color_discrete_sequence=ACCENT_PALETTE,
                )
            figure.update_traces(textposition="outside")
            figure.update_layout(**PLOTLY_THEME, showlegend=False)
        elif chart_type == "Line":
            figure = px.line(
                frame,
                x=x_column,
                y=y_column,
                markers=True,
                title=title,
                color_discrete_sequence=ACCENT_PALETTE,
            )
            figure.update_layout(**PLOTLY_THEME, showlegend=False)
        elif chart_type == "Pie":
            figure = px.pie(
                frame,
                names=x_column,
                values=y_column,
                title=title,
                hole=0.55,
                color_discrete_sequence=ACCENT_PALETTE,
            )
            figure.update_layout(**PLOTLY_THEME)
        else:
            figure = px.scatter(
                frame,
                x=x_column,
                y=y_column,
                title=title,
                color_discrete_sequence=ACCENT_PALETTE,
            )
            figure.update_layout(**PLOTLY_THEME, showlegend=False)

        st.plotly_chart(figure, use_container_width=True)


def render_query_result(result: dict, key_prefix: str) -> None:
    mode_label = str(result.get("mode", "answer")).upper()
    if result.get("cached"):
        mode_label = f"{mode_label} · CACHED"

    render_answer(result.get("answer", ""), mode_label)

    chips = [
        {"label": "Latency", "value": f"{result.get('latency_ms', 0):.0f} ms"},
        {
            "label": "Response",
            "value": "Cache" if result.get("cached") else "Live",
            "tone": "success" if result.get("cached") else "accent",
        },
    ]

    chunks = result.get("retrieved_chunks", []) or []
    if chunks:
        chips.append({"label": "Evidence", "value": f"{len(chunks)} chunks", "tone": "accent"})

    if result.get("sources"):
        for source in result["sources"][:3]:
            chips.append({"label": "Source", "value": source})

    render_chip_row(chips)

    if result.get("sql"):
        with st.expander("Generated SQL", expanded=False):
            render_code_block(result["sql"])

    if result.get("result"):
        frame = pd.DataFrame(result["result"])
        st.dataframe(frame, use_container_width=True, hide_index=True)
        render_dataframe_chart(
            frame,
            key_prefix=key_prefix,
            title="Query result overview",
            question=result.get("question", ""),
        )
        st.download_button(
            "Download CSV",
            frame.to_csv(index=False),
            file_name=f"{key_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            key=f"{key_prefix}_download",
        )

    if chunks:
        with st.expander(f"Evidence ({len(chunks)} chunks)", expanded=False):
            for chunk in chunks:
                preview = chunk.get("content", "")
                if len(preview) > 360:
                    preview = f"{preview[:360]}..."
                detail = f" · page {chunk.get('page', '-')}"
                render_evidence_card(
                    source=chunk.get("source", "source"),
                    detail=detail,
                    preview=preview,
                    score=float(chunk.get("score", 0) or 0),
                )


def render_login_gate(health: dict | None) -> None:
    document_count = health.get("document_count", 0) if health else 0
    chunk_count = health.get("chunk_count", 0) if health else 0

    render_page_header(
        "One workspace for documents and structured data",
        "Upload files, ask natural-language questions, run safe SQL, and keep a searchable record of the answers your team generated.",
        eyebrow="QueryMind",
        badge="Professional workspace",
    )
    render_stat_cards(
        [
            {"label": "Document formats", "value": "4", "detail": "PDF, CSV, TXT, and DOCX", "tone": "accent"},
            {"label": "Indexed documents", "value": document_count, "detail": "Currently available in the backend"},
            {"label": "Searchable chunks", "value": chunk_count, "detail": "Semantic retrieval units", "tone": "success"},
        ]
    )
    render_feature_grid(
        [
            {
                "label": "DOC",
                "title": "Cross-document answers",
                "body": "Route questions through retrieval-augmented generation and inspect the exact evidence used to craft each answer.",
            },
            {
                "label": "SQL",
                "title": "Safe analytics workflow",
                "body": "Run natural-language SQL against the sample dataset or connect a live database in the dedicated DB Chat workspace.",
            },
            {
                "label": "OPS",
                "title": "Operational visibility",
                "body": "Track latency, review query history, and keep document management close to the assistant instead of split across tools.",
            },
        ]
    )
    render_panel(
        "Sign in to continue",
        "Use the left sidebar to authenticate. The included demo account is user / user123 if you want to preview the experience quickly.",
        eyebrow="Access",
        tone="accent",
    )


def render_assistant_tab(docs: list[dict]) -> None:
    ready_docs = [doc for doc in docs if doc.get("status") == "ready"]
    total_chunks = sum(doc.get("chunk_count", 0) for doc in docs)

    render_page_header(
        "Ask across documents and data",
        "Use one input to search indexed files, route directly to SQL, or let the app pick the best path automatically.",
        eyebrow="Assistant",
        badge=f"{len(ready_docs)} ready docs",
    )
    render_chip_row(
        [
            {"label": "Indexed chunks", "value": total_chunks},
            {"label": "Mode", "value": st.session_state.query_mode.upper(), "tone": "success"},
            {"label": "Top K", "value": st.session_state.top_k},
        ]
    )

    examples = [
        "What are the main findings in the uploaded report?",
        "Summarize the latest document in three bullet points.",
        "What important dates are mentioned across the documents?",
        "How many employees are there?",
        "Average salary by department",
        "List all active projects",
    ]

    main_col, side_col = st.columns([2.2, 1])
    with side_col:
        render_panel(
            "Context and focus",
            "Limit the search to specific documents or leave the filter empty to search the full library.",
            eyebrow="Scope",
        )
        if ready_docs:
            options = [doc["filename"] for doc in ready_docs]
            st.multiselect(
                "Limit to documents",
                options=options,
                key="ask_selected_docs",
                help="Leave empty to search all ready documents.",
            )
        else:
            render_empty_state("No indexed documents", "Upload a document in the Library tab to enable document-grounded answers.")

        st.selectbox(
            "Suggested question",
            [BLANK_EXAMPLE] + examples,
            key="ask_example",
            on_change=apply_example,
            args=("ask_example", "ask_draft", BLANK_EXAMPLE),
        )

    with main_col:
        question = st.text_area(
            "Question",
            key="ask_draft",
            height=140,
            placeholder="Example: What are the key findings in the uploaded report?",
        )
        action_col, clear_col = st.columns([3, 1])
        with action_col:
            run_query = st.button(
                "Get answer",
                key="assistant_run",
                disabled=not question.strip(),
            )
        with clear_col:
            clear_query = st.button("Clear", key="assistant_clear")

        if clear_query:
            st.session_state.last_answer = None
            st.rerun()

        if run_query and question.strip():
            doc_lookup = {doc["filename"]: doc["id"] for doc in ready_docs}
            selected_doc_ids = [doc_lookup[name] for name in st.session_state.ask_selected_docs if name in doc_lookup]
            with st.spinner("Searching sources and generating the answer..."):
                result, err = api_query(
                    question=question,
                    mode=st.session_state.query_mode,
                    doc_ids=selected_doc_ids or None,
                    top_k=st.session_state.top_k,
                )
            if err:
                st.error(f"Query failed: {err}")
            else:
                st.session_state.last_answer = result

        if st.session_state.last_answer:
            render_query_result(st.session_state.last_answer, key_prefix="assistant_result")
        else:
            render_empty_state(
                "No answer yet",
                "Submit a question above to see the answer, sources, and any generated SQL in one place.",
            )


def render_library_tab(docs: list[dict]) -> None:
    total_chunks = sum(doc.get("chunk_count", 0) for doc in docs)
    ready_docs = [doc for doc in docs if doc.get("status") == "ready"]

    render_page_header(
        "Document library",
        "Ingest files, review summaries, and manage the indexed content available to the assistant.",
        eyebrow="Library",
        badge=f"{len(docs)} files",
    )
    render_stat_cards(
        [
            {"label": "Documents", "value": len(docs), "detail": "Uploaded to the current workspace"},
            {"label": "Ready", "value": len(ready_docs), "detail": "Searchable right now", "tone": "success"},
            {"label": "Indexed chunks", "value": total_chunks, "detail": "Used for retrieval", "tone": "accent"},
        ]
    )

    upload_col, library_col = st.columns([1, 1.7])

    with upload_col:
        render_panel(
            "Add a document",
            "Upload PDF, CSV, TXT, or DOCX files. The backend will parse, chunk, summarize, and index the content automatically.",
            eyebrow="Ingestion",
        )
        if docs and st.button("Repair search index", key="library_reindex"):
            with st.spinner("Rebuilding the vector index from stored chunks..."):
                result, err = api_reindex()
            if err:
                st.error(f"Reindex failed: {err}")
            else:
                st.success(
                    f"Reindexed {result.get('reindexed_chunks', 0)} chunks. "
                    f"Search store now has {result.get('total_chunks', 0)} chunks."
                )
                st.rerun()
        uploaded_file = st.file_uploader(
            "Upload document",
            type=["pdf", "csv", "txt", "docx"],
            key="library_uploader",
        )
        if uploaded_file:
            extension = uploaded_file.name.rsplit(".", 1)[-1].upper() if "." in uploaded_file.name else "FILE"
            render_panel(
                uploaded_file.name,
                f"{fmt_size(uploaded_file.size)} · {extension} ready to index",
                eyebrow="Selected file",
                tone="accent",
            )
            if st.button("Upload and index", key="library_upload"):
                with st.spinner(f"Indexing {uploaded_file.name}..."):
                    result, err = api_upload(uploaded_file.getvalue(), uploaded_file.name)
                if err:
                    st.error(f"Upload failed: {err}")
                else:
                    st.success(f"Indexed {result['chunk_count']} chunks from {uploaded_file.name}.")
                    st.rerun()

    with library_col:
        st.text_input(
            "Filter library",
            key="doc_search",
            placeholder="Search by filename or file type",
        )

        if not docs:
            render_empty_state("No documents uploaded", "Use the upload panel to add the first file to the workspace.")
        else:
            search = st.session_state.doc_search.strip().lower()
            filtered_docs = [
                doc
                for doc in docs
                if not search
                or search in doc["filename"].lower()
                or search in doc.get("file_type", "").lower()
            ]

            if not filtered_docs:
                render_empty_state("No matching documents", "Try a broader search term to see the available files.")

            for doc in filtered_docs:
                created = format_timestamp(doc.get("created_at"))
                label = f"{doc['filename']} · {file_type_label(doc.get('file_type', 'file'))} · {doc.get('chunk_count', 0)} chunks · {created}"
                with st.expander(label, expanded=False):
                    metrics = st.columns(4)
                    metrics[0].metric("Type", file_type_label(doc.get("file_type", "")))
                    metrics[1].metric("Size", fmt_size(doc.get("file_size", 0)))
                    metrics[2].metric("Status", doc.get("status", "-").title())
                    metrics[3].metric("Chunks", doc.get("chunk_count", 0))

                    if doc.get("summary"):
                        render_panel("Document summary", doc["summary"], eyebrow="Summary", tone="accent")

                    action_cols = st.columns(3)
                    with action_cols[0]:
                        if st.button("Summarize", key=f"doc_summary_{doc['id']}"):
                            with st.spinner("Generating summary..."):
                                result, err = api_summarize(doc["id"])
                            if err:
                                st.error(err)
                            else:
                                render_panel("Summary", result["summary"], eyebrow="Generated summary", tone="accent")
                    with action_cols[1]:
                        if st.button("Extract key info", key=f"doc_extract_{doc['id']}"):
                            with st.spinner("Extracting key information..."):
                                result, err = api_extract(doc["id"])
                            if err:
                                st.error(err)
                            else:
                                render_panel("Key information", result["key_info"], eyebrow="Extraction", tone="success")
                    with action_cols[2]:
                        if st.button("Delete", key=f"doc_delete_{doc['id']}"):
                            if api_delete_doc(doc["id"]):
                                st.success(f"Deleted {doc['filename']}.")
                                st.rerun()
                            else:
                                st.error("Delete failed.")

            if len(docs) > 1:
                type_counts: dict[str, int] = {}
                for doc in docs:
                    file_type = doc.get("file_type", "unknown")
                    type_counts[file_type] = type_counts.get(file_type, 0) + 1
                composition = pd.DataFrame(
                    list(type_counts.items()),
                    columns=["type", "count"],
                )
                figure = px.pie(
                    composition,
                    names="type",
                    values="count",
                    hole=0.58,
                    title="Document composition",
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                figure.update_layout(**PLOTLY_THEME)
                st.plotly_chart(figure, use_container_width=True)


def render_history_tab() -> None:
    history = api_history()

    render_page_header(
        "Query history",
        "Review recent assistant activity for the signed-in user, including response timing and any SQL generated by the platform.",
        eyebrow="History",
        badge="Server persisted",
    )

    if not history:
        render_empty_state("No history yet", "Run a few questions in the Assistant or SQL Workspace tabs to populate this view.")
        return

    avg_latency = sum(item.get("latency_ms", 0) for item in history) / len(history)
    sql_count = sum(1 for item in history if item.get("mode") == "sql")
    render_stat_cards(
        [
            {"label": "Queries", "value": len(history), "detail": "Stored for the current user"},
            {"label": "Average latency", "value": f"{avg_latency:.0f} ms", "detail": "Across the latest requests", "tone": "accent"},
            {"label": "SQL queries", "value": sql_count, "detail": "Requests routed through SQL", "tone": "success"},
        ]
    )

    render_panel(
        "History behavior",
        "History is stored on the backend per signed-in user. This view is searchable, but it does not currently expose a backend clear action.",
        eyebrow="Note",
    )

    if len(history) > 1:
        history_frame = pd.DataFrame(history)
        charts_col, mode_col = st.columns(2)
        with charts_col:
            latency_figure = px.line(
                history_frame.head(20)[::-1].reset_index(drop=True),
                y="latency_ms",
                markers=True,
                title="Response latency",
                color_discrete_sequence=[ACCENT_PALETTE[0]],
            )
            latency_figure.update_layout(**PLOTLY_THEME, showlegend=False)
            st.plotly_chart(latency_figure, use_container_width=True)
        with mode_col:
            if "mode" in history_frame.columns:
                mode_counts = history_frame["mode"].value_counts().reset_index()
                mode_counts.columns = ["mode", "count"]
                mode_figure = px.bar(
                    mode_counts,
                    x="mode",
                    y="count",
                    color="mode",
                    title="Queries by mode",
                    color_discrete_sequence=ACCENT_PALETTE,
                )
                mode_figure.update_layout(**PLOTLY_THEME, showlegend=False)
                st.plotly_chart(mode_figure, use_container_width=True)

    search = st.text_input(
        "Search history",
        placeholder="Filter by question text",
        key="history_search",
    ).strip().lower()

    filtered = [
        item for item in history if not search or search in item.get("question", "").lower()
    ]

    if not filtered:
        render_empty_state("No matching history", "Try a different search term to review stored queries.")
        return

    for item in filtered:
        created = format_timestamp(item.get("created_at"))
        label = f"{created} · {item['question'][:90]}"
        with st.expander(label, expanded=False):
            render_answer(item.get("answer", ""), str(item.get("mode", "answer")).upper())
            render_chip_row(
                [
                    {"label": "Latency", "value": f"{item.get('latency_ms', 0):.0f} ms"},
                    {"label": "Mode", "value": str(item.get("mode", "-")).upper(), "tone": "accent"},
                ]
            )
            if item.get("sql"):
                render_code_block(item["sql"])


def render_sql_workspace_tab() -> None:
    render_page_header(
        "Employees and projects analytics",
        "Run natural-language SQL against the packaged sample dataset and visualize the answer without writing queries by hand.",
        eyebrow="SQL Workspace",
        badge="Built-in dataset",
    )
    render_stat_cards(
        [
            {"label": "Tables", "value": "2", "detail": "employees and projects", "tone": "accent"},
            {"label": "Routing mode", "value": "SQL", "detail": "Always uses the SQL pathway"},
            {"label": "Exports", "value": "CSV", "detail": "Download tabular results", "tone": "success"},
        ]
    )

    examples = [
        "How many employees are there?",
        "What is the average salary by department?",
        "List all active projects with their budgets",
        "Which department has the most employees?",
        "Show the top 10 highest paid employees",
        "What is the total budget across all projects?",
        "How many active vs inactive employees are there?",
        "List all employees in the Engineering department",
        "What is the average project budget by department?",
    ]

    main_col, side_col = st.columns([2.2, 1])
    with side_col:
        render_panel(
            "Available tables",
            "employees: id, name, department, salary, hire_date, status<br>projects: id, name, department, budget, start_date, end_date, status",
            eyebrow="Schema reference",
            tone="accent",
            allow_html=True,
        )
        st.selectbox(
            "Suggested query",
            [BLANK_EXAMPLE] + examples,
            key="db_example",
            on_change=apply_example,
            args=("db_example", "db_draft", BLANK_EXAMPLE),
        )

    with main_col:
        db_question = st.text_area(
            "Question",
            key="db_draft",
            height=130,
            placeholder="Example: Which department has the highest average salary?",
        )
        action_col, clear_col = st.columns([3, 1])
        with action_col:
            run_sql_workspace = st.button(
                "Run query",
                key="sql_workspace_run",
                disabled=not db_question.strip(),
            )
        with clear_col:
            clear_sql_workspace = st.button("Clear", key="sql_workspace_clear")

        if clear_sql_workspace:
            st.session_state.last_db_result = None
            st.rerun()

        if run_sql_workspace and db_question.strip():
            with st.spinner("Generating SQL and fetching results..."):
                result, err = api_query(db_question, "sql")
            if err:
                st.error(f"Query failed: {err}")
            else:
                st.session_state.last_db_result = result

        if st.session_state.last_db_result:
            render_query_result(st.session_state.last_db_result, key_prefix="sql_workspace_result")
        else:
            render_empty_state(
                "No SQL result yet",
                "Run a natural-language query above to see the generated SQL, the result table, and a chart when the data supports it.",
            )


health = api_health()
render_sidebar(health)

if not st.session_state.token:
    render_login_gate(health)
    st.stop()

documents = api_list_docs()

assistant_tab, library_tab, history_tab, sql_tab, db_chat_tab = st.tabs(
    ["Assistant", "Library", "History", "SQL Workspace", "DB Chat"]
)

with assistant_tab:
    render_assistant_tab(documents)

with library_tab:
    render_library_tab(documents)

with history_tab:
    render_history_tab()

with sql_tab:
    render_sql_workspace_tab()

with db_chat_tab:
    render_db_chat()
